package com.flocmedia.photoeditor

import android.view.View

/**
 * What kind of thing an undo-history entry did. Reported to [OnHistoryListener].
 *
 * [APP] is every [EditorOperation] the consuming app records itself through
 * [PhotoEditor.recordOperation] (opacity, stretch, blend, ...) unless it overrides
 * [EditorOperation.kind].
 */
enum class GraphicOperationKind {
    ADD,
    DELETE,
    TRANSFORM,
    BRUSH_STROKE,
    MIRROR,
    REORDER,
    EDIT_TEXT,
    APP,
}

/**
 * GAME-838 slice 2: the history seam. Told about every entry that reaches the undo stack,
 * and about every undo and redo.
 *
 * Why: the app's draft is saved only when the app marks it dirty, and it used to do that
 * by hand after each edit -- so an edit that recorded an undo step but forgot the dirty
 * mark (reorder, blend, the sliders) was lost on reopen. Marking dirty from here ties the
 * two together: anything undoable is, by construction, also saved.
 *
 * Every callback runs AFTER the stacks are updated, so [PhotoEditorViewState.undoCount]
 * and [PhotoEditorViewState.redoCount] already include the change. A record made while an
 * undo or redo is replaying is ignored by the stack and is NOT reported.
 *
 * [view] is the graphic the entry touched when the library knows it: the graphic root for
 * add, delete, transform and reorder; the flipped image/text view for mirror; the text
 * view for an edit; the DrawingView for a stroke; null for an app entry.
 */
interface OnHistoryListener {
    fun onOperationRecorded(kind: GraphicOperationKind, view: View?)

    fun onUndone(kind: GraphicOperationKind, view: View?)

    fun onRedone(kind: GraphicOperationKind, view: View?)
}
