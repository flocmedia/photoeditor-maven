package com.flocmedia.photoeditor

import android.content.res.ColorStateList
import android.graphics.Paint
import android.widget.TextView
import androidx.annotation.ColorInt

/**
 * Drives the two-pass draw that puts an outline behind a [TextView]'s glyphs:
 * a STROKE pass in the outline colour, then the normal FILL pass on top.
 *
 * The passes themselves are `super.onDraw` calls, so they have to stay in the
 * view subclass -- a `TextView` subclass and an `EditText` subclass do not
 * share a supertype we can call through. What lives here is the fiddly part
 * they DO share: saving the paint, reconfiguring it, and putting every last
 * field back afterwards.
 *
 * ## Why the text colour is swapped rather than the paint colour
 *
 * [TextView.onDraw] does `mTextPaint.setColor(mCurTextColor)` on entry, every
 * single draw. Writing `paint.color` here would therefore be silently
 * discarded before a pixel is drawn. [TextView.setTextColor] is the only public
 * writer of `mCurTextColor`, so it is the only way in -- which is the whole
 * reason this class touches the view's colour state at all.
 *
 * ## Why callers must suppress invalidation
 *
 * `setTextColor` and `setShadowLayer` both call `invalidate()`. Called from
 * inside `onDraw`, that marks the view dirty again the instant it finishes
 * drawing, and it redraws forever -- a permanently animating view burning
 * frames for as long as it is on screen. Every caller MUST gate its
 * `invalidate` overrides while a pass is in flight; see the `isDrawingOutline`
 * flag in [OutlinedTextView].
 */
object GlyphOutlinePainter {

    /**
     * Everything the outline passes overwrite, captured before the first one.
     *
     * [textColours] is the whole [ColorStateList] and not the resolved
     * `currentTextColor` int on purpose: restoring the int would collapse a
     * multi-state list into a single colour permanently. Today every text item
     * in the editor carries a plain colour so it would look identical -- which
     * is exactly what would let it survive long enough to matter later.
     */
    class SavedTextPaintState internal constructor(
        internal val style: Paint.Style,
        internal val strokeWidth: Float,
        internal val strokeJoin: Paint.Join,
        internal val strokeCap: Paint.Cap,
        internal val isAntiAlias: Boolean,
        internal val shadowRadius: Float,
        internal val shadowDx: Float,
        internal val shadowDy: Float,
        @ColorInt internal val shadowColour: Int,
        internal val textColours: ColorStateList,
    )

    /**
     * Configures [textView] to draw the outline, and returns the state to hand
     * back to [restore].
     *
     * [outlineColour] must be derived from the view's colour BEFORE this call --
     * once it returns, `currentTextColor` is the outline colour, and deriving
     * from it then would produce the contrast of the outline against itself.
     */
    fun beginStrokePass(textView: TextView, @ColorInt outlineColour: Int): SavedTextPaintState {
        val paint = textView.paint
        val saved = SavedTextPaintState(
            style = paint.style,
            strokeWidth = paint.strokeWidth,
            strokeJoin = paint.strokeJoin,
            strokeCap = paint.strokeCap,
            isAntiAlias = paint.isAntiAlias,
            shadowRadius = textView.shadowRadius,
            shadowDx = textView.shadowDx,
            shadowDy = textView.shadowDy,
            shadowColour = textView.shadowColor,
            textColours = textView.textColors,
        )

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = TextOutlines.strokeWidthPx(textView.textSize)
        // ROUND on both, not the MITER default: a mitre spikes outward at sharp
        // glyph corners, and the display faces this app ships are full of them.
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeCap = Paint.Cap.ROUND
        // A stroke is a thin high-contrast edge along its entire length, so
        // aliasing shows up far more on it than on a filled glyph. Forced here
        // rather than assumed, because `TextStyleBuilder.withTextFlag` can
        // overwrite the paint's flags wholesale.
        paint.isAntiAlias = true
        textView.setTextColor(outlineColour)

        return saved
    }

    /**
     * Switches [textView] back to normal fill painting, ready for the second
     * `super.onDraw`.
     *
     * The shadow is dropped for that pass. A shadow layer belongs to the paint,
     * so leaving it on would draw it twice: once under the stroke, then again
     * under the fill -- and the second copy lands ON TOP of the stroke,
     * darkening the outline along the offset side. The outer silhouette is the
     * stroke, so the stroke is the pass that should cast it.
     */
    fun switchToFillPass(textView: TextView, saved: SavedTextPaintState) {
        val paint = textView.paint
        paint.style = saved.style
        paint.strokeWidth = saved.strokeWidth
        paint.strokeJoin = saved.strokeJoin
        paint.strokeCap = saved.strokeCap
        paint.isAntiAlias = saved.isAntiAlias
        textView.setTextColor(saved.textColours)
        textView.setShadowLayer(0f, 0f, 0f, 0)
    }

    /**
     * Puts [textView] back exactly as it was found. Idempotent, and safe to
     * call from a `finally` whether one pass ran or both.
     *
     * Calling this from a `finally` is not defensive style, it is required.
     * `currentTextColor` is read back out of the view by
     * `TextState.of` (the undo snapshot) and by `Text.updateView` (the change
     * callback into the host app). If a pass threw and left the outline colour
     * installed, the next snapshot would record black or white as the user's
     * chosen text colour and undo would "restore" it.
     */
    fun restore(textView: TextView, saved: SavedTextPaintState) {
        val paint = textView.paint
        paint.style = saved.style
        paint.strokeWidth = saved.strokeWidth
        paint.strokeJoin = saved.strokeJoin
        paint.strokeCap = saved.strokeCap
        paint.isAntiAlias = saved.isAntiAlias
        textView.setTextColor(saved.textColours)
        textView.setShadowLayer(saved.shadowRadius, saved.shadowDx, saved.shadowDy, saved.shadowColour)
    }
}
