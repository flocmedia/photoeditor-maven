package com.flocmedia.photoeditor.shape

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF

abstract class AbstractShape(protected val tag: String) : Shape {
    protected var path = Path()
    protected var left = 0f
    protected var top = 0f
    protected var right = 0f
    protected var bottom = 0f

    /**
     * GAME-1035: the raw input points, in order, recorded as the stroke is drawn.
     *
     * A committed stroke's geometry otherwise lives ONLY in the opaque [path]
     * (each point is folded in via quadTo/lineTo and discarded), and there is no
     * way to read a Path back below API 34. Keeping the points lets a stroke be
     * serialized and later REPLAYED through [Shape.startShape]/[Shape.moveShape]
     * to rebuild an identical, still-editable vector shape -- see
     * DrawingView.addRestoredStroke. Populated by DrawingView, not by the shapes
     * themselves, so drawing behaviour is unchanged.
     */
    val points = mutableListOf<PointF>()

    /**
     * GAME-1132: the event time (ms) of each recorded point, parallel to [points].
     *
     * Kept so a stroke's per-segment draw SPEED can be recovered -- BrushShape
     * tapers its width by velocity (distance / dt). A Path stores no time, and
     * [points] alone cannot tell a slow drag from a fast flick. Populated
     * alongside [points] by [recordPoint]; serialized with the stroke so a
     * restored draft re-derives the same widths. A stroke recorded before this
     * existed (or a shape that never records time) leaves this shorter/zero, and
     * BrushShape falls back to constant width.
     */
    val pointTimes = mutableListOf<Long>()

    /**
     * GAME-1035: whether this stroke ERASES (PorterDuff.CLEAR) rather than paints.
     * Recorded on the shape because a Paint's xfermode mode is not reliably
     * readable across API levels, and a restore must rebuild the CLEAR paint.
     */
    var isEraser: Boolean = false

    /** GAME-1035: the concrete shape's stable name, for (de)serialization. */
    val shapeName: String get() = tag

    /**
     * GAME-1035/1132: append a raw input point (see [points]) with its event
     * time (see [pointTimes]). [t] defaults to 0 for callers that have no time
     * base (older tests, non-brush replay) -- BrushShape then reads zero deltas
     * and draws at constant width, i.e. today's behaviour.
     */
    fun recordPoint(x: Float, y: Float, t: Long = 0L) {
        points.add(PointF(x, y))
        pointTimes.add(t)
    }

    override fun draw(canvas: Canvas, paint: Paint) {
        canvas.drawPath(path, paint)
    }

    private val bounds: RectF
        get() {
            val bounds = RectF()
            path.computeBounds(bounds, true)
            return bounds
        }

    fun hasBeenTapped(): Boolean {
        val bounds = bounds
        return bounds.top < TOUCH_TOLERANCE && bounds.bottom < TOUCH_TOLERANCE && bounds.left < TOUCH_TOLERANCE && bounds.right < TOUCH_TOLERANCE
    }

    override fun toString(): String {
        return tag +
                ": left: " + left +
                " - top: " + top +
                " - right: " + right +
                " - bottom: " + bottom
    }

    companion object {
        const val TOUCH_TOLERANCE = 4f
    }
}