package com.flocmedia.photoeditor

object ClickAreaUtils {
    private fun isFullyAlphaPixel(packedPixelValue: Int): Boolean {
        return (packedPixelValue shr 24 and 0xff) / 255.0f == 0.0f
    }

    // Checks if a pixel is opaque, and has at least one 100% alpha neighbor
    // Neighbors are above (top), below (bottom), left and right
    fun isEdgePixel(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        scaledImageBitmapPixels: IntArray
    ): Boolean {
        // Get the value of the pixel.  If alpha, is not an edge.
        val centerPixelIsAlpha = isFullyAlphaPixel(scaledImageBitmapPixels[y * width + x])
        if (centerPixelIsAlpha) {
            return false
        }

        // Check if the left neighbor pixel is alpha (with the center being opaque)
        val leftPixelX = x - 1
        if (leftPixelX >= 0 && isFullyAlphaPixel(scaledImageBitmapPixels[y * width + leftPixelX])) {
            return true
        }

        // Check if the right neighbor pixel is alpha (with the center being opaque)
        val rightPixelX = x + 1
        if (rightPixelX < width && isFullyAlphaPixel(scaledImageBitmapPixels[y * width + rightPixelX])) {
            return true
        }

        // Check if the top neighbor pixel is alpha (with the center being opaque)
        val topPixelY = y - 1
        if (topPixelY >= 0 && isFullyAlphaPixel(scaledImageBitmapPixels[topPixelY * width + x])) {
            return true
        }

        // Check if the bottom neighbor pixel is alpha (with the center being opaque)
        val bottomPixelY = y + 1
        return bottomPixelY < height && isFullyAlphaPixel(scaledImageBitmapPixels[bottomPixelY * width + x])
    }

    // Extracted from EditorTransparentCache.isOpaquePixelClicked's pure decision core (the part
    // after its View/MultiTouchListener-state early-outs) so the click-through decision itself
    // is directly testable, not just the edge-pixel helper above. Deliberately reimplements the
    // original's android.graphics.Rect-based intersection test as plain int math instead, to
    // keep this file Android-free and pure-JVM testable (matching isEdgePixel above) rather than
    // requiring Robolectric.
    //
    // Returns false if the click radius does not overlap the bitmap at all, or if the pixel at
    // its center is fully transparent; true if that center pixel has any non-zero alpha.
    fun isOpaquePixelWithinRadius(
        pixelMap: IntArray,
        bitmapWidth: Int,
        bitmapHeight: Int,
        eventX: Float,
        eventY: Float,
        scaleX: Float,
        scaleY: Float,
        clickRadius: Int
    ): Boolean {
        val scaledImageEventX = (eventX * scaleX).toInt()
        val scaledImageEventY = (eventY * scaleY).toInt()

        val clickLeft = scaledImageEventX - clickRadius
        val clickTop = scaledImageEventY - clickRadius
        val clickRight = scaledImageEventX + clickRadius
        val clickBottom = scaledImageEventY + clickRadius

        // Matches android.graphics.Rect.intersects' semantics: strict inequalities, so a click
        // area that only touches the bitmap's edge (zero-width/height overlap) does not count.
        val clickIntersectsBitmap =
            0 < clickRight && clickLeft < bitmapWidth && 0 < clickBottom && clickTop < bitmapHeight
        if (!clickIntersectsBitmap) {
            return false
        }

        val centerX = clickLeft + clickRadius
        val centerY = clickTop + clickRadius

        // If the click radius overlaps the bitmap but the exact center pixel falls outside the
        // flat pixelMap array's bounds, don't select -- matches the original's documented "hack"
        // (EditorTransparentCache.kt's TODO(cheng): Fix this hack later) for the upper bound.
        // The `centerIndex < 0` half is a deliberate addition, not a faithful copy: the original
        // only checked `>= pixelMap.size`, so a click near the top-left corner (e.g. a negative
        // scaledImageEventX/Y within clickRadius of 0) could produce a negative centerIndex and
        // throw ArrayIndexOutOfBoundsException uncaught -- a real, previously-unnoticed crash risk
        // surfaced while extracting this for testing. Failing safe (treat as "not clicked") is
        // consistent with the existing upper-bound guard's own intent.
        val centerIndex = centerY * bitmapWidth + centerX
        if (centerIndex < 0 || centerIndex >= pixelMap.size) {
            return false
        }

        val packedPixelValue = pixelMap[centerIndex]
        return (packedPixelValue shr 24 and 0xff) / 255.0f != 0.0f
    }
}