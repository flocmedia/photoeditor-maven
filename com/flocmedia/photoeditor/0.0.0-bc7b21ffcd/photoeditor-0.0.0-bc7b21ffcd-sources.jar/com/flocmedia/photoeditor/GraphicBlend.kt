package com.flocmedia.photoeditor

import android.view.View

/**
 * Public API for the per-graphic blend mode (GAME-703). The consuming app sets
 * and reads the mode here rather than touching the tag directly; the mode is
 * stored on the graphic's root view and consumed by [BlendableFrameLayout].
 *
 * Mirrors how alpha is a per-graphic property, except a blend has no native View
 * property, so it lives on a tag.
 */
object GraphicBlend {

    /** Set the blend mode on a placed graphic and re-composite the canvas. */
    fun set(rootView: View, mode: GraphicBlendMode) {
        rootView.setTag(R.id.blend_mode_tag, mode)
        // A tag change does not invalidate anything; the PARENT must redraw for
        // drawChild to re-run with the new mode.
        (rootView.parent as? View)?.invalidate()
        rootView.invalidate()
    }

    /** The graphic's blend mode, or NORMAL if none was set. */
    fun of(rootView: View?): GraphicBlendMode =
        rootView?.getTag(R.id.blend_mode_tag) as? GraphicBlendMode ?: GraphicBlendMode.NORMAL
}
