package com.flocmedia.photoeditor

/**
 * Whether a text item draws a contrasting outline around its glyphs.
 *
 * A one-field holder rather than a bare `Boolean` so it matches the shape of
 * [TextShadow] and [TextBorder] in [TextStyleBuilder], and so a later thickness
 * or explicit colour can be added here instead of as another entry in
 * [TextStyleBuilder.TextStyle].
 *
 * There is no colour field on purpose: the outline is black or white, whichever
 * contrasts with the text, resolved at draw time by [TextOutlines]. Carrying a
 * colour here would let it fall out of step with the text colour after an edit
 * or an undo.
 */
data class TextOutline(
    var enabled: Boolean
)
