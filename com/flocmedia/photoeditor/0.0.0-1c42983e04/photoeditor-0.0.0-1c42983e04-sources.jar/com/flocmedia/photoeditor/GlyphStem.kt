package com.flocmedia.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface

/**
 * Measures how thick a typeface's strokes are, as a fraction of its text size.
 *
 * GAME-786. [TextOutlines.STROKE_FRACTION] sizes the glyph outline from the TEXT
 * SIZE alone, which knows nothing about the face. A centred stroke eats inward
 * from both edges of a stem, so the fill that survives is `stem - stroke` -- and
 * measuring the nine faces this app ships showed that at 1/12 of the text size
 * the stroke is **wider than the stem on five of them**. Those render as pure
 * outline with no fill at all, including the blackletter default, which keeps
 * only 13%.
 *
 * Offline measurement of the shipped assets, median horizontal ink run-length of
 * "Hamburgefonstiv" rendered at 200px, as stem/textSize:
 *
 *     font_abc_3  0.035     font_abc_5  0.075     font_abc_1  0.100
 *     font_abc_4  0.050     font_abc_0  0.095     font_abc_8  0.100
 *     font_abc_6  0.055     font_abc_2  0.130     font_abc_7  0.060
 *
 * ## Why it rasterises
 *
 * Stem thickness is not exposed by any Android text API. `Typeface.getWeight()`
 * reports what the font DECLARES, which for these assets is unrelated to what
 * they draw -- and it needs API 28 against a minSdk of 21. Font metrics describe
 * vertical extents, not stroke weight. The only way to know how much ink a face
 * puts down is to put some down and look at it.
 *
 * One small offscreen render per typeface, cached forever after. The app ships
 * nine faces, so this is nine one-off renders for the life of the process, none
 * of them on a per-frame path.
 *
 * ## Why it can fail, and what happens then
 *
 * [NOT_MEASURABLE] is returned when the reference string rasterises to nothing.
 * That is not hypothetical: Robolectric's default shadows do not draw text, so
 * every JVM test in this repo takes that branch. Callers must fall back to the
 * size-only stroke, which is exactly the behaviour that shipped before this
 * class existed -- so a failed measurement degrades to the status quo rather
 * than to a broken outline.
 *
 * The consequence, stated plainly: **the measurement itself is verifiable only
 * on a device.** What is unit-tested here is the caching, the fallback, and the
 * arithmetic in [TextOutlines] that consumes the result.
 */
internal object GlyphStem {

    /** No stem could be measured. Callers fall back to the size-only stroke. */
    const val NOT_MEASURABLE = -1f

    /**
     * Letters with straight vertical stems, round bowls and a diagonal, so the
     * median run-length lands on the face's dominant stroke rather than on a
     * single unrepresentative letterform. The standard type-design pangram
     * fragment, used for exactly this reason.
     */
    private const val REFERENCE_TEXT = "Hamburgefonstiv"

    /**
     * Big enough that a hairline stem is several pixels wide and the median is
     * not quantised into uselessness -- at 128px the thinnest shipped face
     * measures ~4px. Fixed rather than the caller's size so the cached ratio is
     * a property of the typeface alone.
     */
    private const val REFERENCE_SIZE_PX = 128f

    private val ratioByTypeface = HashMap<Typeface?, Float>()

    /**
     * The stroke thickness of [paint]'s typeface as a fraction of its text size,
     * or [NOT_MEASURABLE].
     *
     * Cached on the Typeface, which is the only thing the answer depends on --
     * the ratio is scale-invariant, so a face measured once is measured for
     * every size it is ever drawn at.
     */
    @Synchronized
    fun ratioFor(paint: Paint): Float =
        ratioByTypeface.getOrPut(paint.typeface) { measureRatio(paint.typeface) }

    /**
     * The stem thickness in pixels for [paint] as currently configured, or
     * [NOT_MEASURABLE].
     */
    fun stemPxFor(paint: Paint): Float {
        val ratio = ratioFor(paint)
        return if (ratio == NOT_MEASURABLE || paint.textSize <= 0f) {
            NOT_MEASURABLE
        } else {
            ratio * paint.textSize
        }
    }

    /** Test seam. The cache is process-wide and would otherwise leak between cases. */
    @Synchronized
    internal fun clearCache() = ratioByTypeface.clear()

    private fun measureRatio(typeface: Typeface?): Float {
        val paint = Paint().apply {
            this.typeface = typeface
            textSize = REFERENCE_SIZE_PX
            style = Paint.Style.FILL
            // OFF deliberately. Anti-aliased edges put half-lit pixels either
            // side of every stem, which widens the measured run by a pixel or
            // two and biases thin faces upward -- the faces this exists to
            // protect.
            isAntiAlias = false
        }

        val bounds = Rect()
        paint.getTextBounds(REFERENCE_TEXT, 0, REFERENCE_TEXT.length, bounds)
        if (bounds.width() <= 0 || bounds.height() <= 0) return NOT_MEASURABLE

        val bitmap = try {
            Bitmap.createBitmap(bounds.width(), bounds.height(), Bitmap.Config.ALPHA_8)
        } catch (e: IllegalArgumentException) {
            return NOT_MEASURABLE
        }

        Canvas(bitmap).drawText(
            REFERENCE_TEXT,
            -bounds.left.toFloat(),
            -bounds.top.toFloat(),
            paint,
        )

        val runs = inkRunLengths(bitmap)
        bitmap.recycle()
        if (runs.isEmpty()) return NOT_MEASURABLE

        runs.sort()
        val median = runs[runs.size / 2]
        return if (median <= 0) NOT_MEASURABLE else median / REFERENCE_SIZE_PX
    }

    /**
     * Every horizontal run of ink, across every scanline.
     *
     * The MEDIAN of these is the stem: a run is one crossing of a stroke, so
     * the distribution is dominated by the face's ordinary stroke width. A mean
     * would be dragged by long runs across horizontal bars and serifs; a
     * minimum would find the thinnest hairline on the face.
     */
    private fun inkRunLengths(bitmap: Bitmap): MutableList<Int> {
        val width = bitmap.width
        val height = bitmap.height
        val row = IntArray(width)
        val runs = mutableListOf<Int>()

        for (y in 0 until height) {
            bitmap.getPixels(row, 0, width, 0, y, width, 1)
            var run = 0
            for (x in 0 until width) {
                // ALPHA_8 comes back through getPixels with the alpha in the
                // high byte and the colour bits zeroed.
                if ((row[x] ushr 24) > INK_THRESHOLD) {
                    run++
                } else {
                    if (run > 0) runs += run
                    run = 0
                }
            }
            if (run > 0) runs += run
        }
        return runs
    }

    /** Half-lit is not ink. Matches the offline measurement this was calibrated against. */
    private const val INK_THRESHOLD = 128
}
