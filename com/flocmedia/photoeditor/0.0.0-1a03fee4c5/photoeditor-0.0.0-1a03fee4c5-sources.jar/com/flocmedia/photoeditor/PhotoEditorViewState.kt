package com.flocmedia.photoeditor

import android.view.View
import java.util.*

/**
 * Tracked state of user-added views (stickers, emoji, text, etc)
 */
class PhotoEditorViewState {
    var currentSelectedView: View? = null
    private val addedViews: MutableList<View>
    private val redoViews: Stack<View>
    val multiTouchListenerByView: MutableMap<View, MultiTouchListener>
    fun clearCurrentSelectedView() {
        currentSelectedView = null
    }

    fun getAddedView(index: Int): View {
        return addedViews[index]
    }

    val addedViewsCount: Int
        get() = addedViews.size

    fun clearAddedViews() {
        addedViews.clear()
    }

    fun addAddedView(view: View) {
        addedViews.add(view)
    }

    /**
     * Restores [view] at its original layer position.
     *
     * Undo/redo needs this: the index IS the layer order, so re-adding an
     * undone view by appending would silently bring it to the front. The
     * coercion guards a stale index -- the list can be shorter than it was when
     * the operation was recorded if something below it was deleted meanwhile.
     */
    fun addAddedView(view: View, index: Int) {
        addedViews.add(index.coerceIn(0, addedViews.size), view)
    }

    /** Layer position of [view], or -1. Recorded when an operation is created. */
    fun indexOfAddedView(view: View): Int = addedViews.indexOf(view)

    fun removeAddedView(view: View) {
        addedViews.remove(view)
    }

    fun removeAddedView(index: Int): View {
        return addedViews.removeAt(index)
    }

    fun containsAddedView(view: View): Boolean {
        return addedViews.contains(view)
    }

    /**
     * Replaces a view in the current "added views" list.
     *
     * @param view The view to replace
     * @return true if the view was found and replaced, false if the view was not found
     */
    fun replaceAddedView(view: View): Boolean {
        val i = addedViews.indexOf(view)
        if (i > -1) {
            addedViews[i] = view
            return true
        }
        return false
    }

    // ---- current-graphics accessors (GAME-1087) ------------------------
    //
    // The canonical "what is on the canvas right now" queries, owned here so the
    // app no longer reconstructs them from the raw collections (it did this in
    // CanvasCensus, dedup + attached-filter by hand). Two DIFFERENT sets, because
    // the two source collections differ and callers rely on the difference:
    //  - graphicsOnCanvas(): the ATTACHED draggable graphics (stickers/text/emoji).
    //  - distinctAddedViews(): the DEDUPED live-scene list (includes the brush
    //    DrawingView, which addedViews holds once per stroke).

    /**
     * The live on-canvas graphics -- each once, still ATTACHED (parent != null).
     *
     * [multiTouchListenerByView] retains an undone graphic as a key with a NULL
     * parent (GraphicManager.undoView removes it from the canvas but not from the
     * map), so a walk of the raw key set would serialise a graphic the user
     * undid, or NPE on `(view.parent as ViewGroup)`. The keys are already unique
     * by identity (map semantics on a non-equals-overriding View), so no dedup is
     * needed -- only the attached filter.
     */
    fun graphicsOnCanvas(): List<View> =
        multiTouchListenerByView.keys.filter { it.parent != null }

    /**
     * [addedViews] with each instance ONCE, in reverse-added order.
     *
     * addedViews is the live scene but not a set: `DrawingView` is appended once
     * per stroke (`onViewAdd` per stroke, no dedup), so a per-view sum over the
     * raw list is n-squared -- 5 strokes counted as 25 (GAME-821). Identity, not
     * equals: two distinct graphics must never collapse into one.
     */
    fun distinctAddedViews(): List<View> {
        val seen = Collections.newSetFromMap(IdentityHashMap<View, Boolean>())
        val result = ArrayList<View>(addedViews.size)
        for (i in addedViews.indices.reversed()) {
            val view = addedViews[i]
            if (seen.add(view)) result.add(view)
        }
        return result
    }

    // ---- history -------------------------------------------------------
    //
    // Separate from addedViews on purpose. addedViews is the LIVE SCENE -- what
    // is on the canvas right now, and what save/export walk. These two stacks
    // are HISTORY. The old design conflated them by treating "the last added
    // view" as "the last thing the user did", which is only true if adding is
    // the only thing a user can do.

    private val undoOperations = kotlin.collections.ArrayDeque<EditorOperation>()
    private val redoOperations = kotlin.collections.ArrayDeque<EditorOperation>()

    /**
     * True while an [EditorOperation] is being replayed by undo or redo.
     *
     * Load-bearing now that operations can come from outside the library. An
     * app's undo will usually work by calling the same app code that performed
     * the action in the first place -- setting alpha, moving a child, resizing
     * a sticker -- and that code records. Without this, undoing an opacity
     * change would push a fresh entry describing the undo, so the stack would
     * grow as the user tried to walk back through it and Undo would never
     * reach the end.
     */
    private var isReplayingOperation = false

    internal fun replayingOperation(block: () -> Unit) {
        isReplayingOperation = true
        try {
            block()
        } finally {
            isReplayingOperation = false
        }
    }

    fun pushOperation(operation: EditorOperation) {
        // Replaying history is not itself a new action.
        if (isReplayingOperation) {
            return
        }
        undoOperations.addLast(operation)
        // A new action starts a new branch of history, so anything previously
        // undone is no longer redoable. Ported reasoning from upstream 8648773,
        // which fixed the same bug for the view stack.
        redoOperations.clear()
        // After the stacks change, so the listener reads the counts it is being told about.
        onHistoryListener?.onOperationRecorded(operation.kind, operation.graphic)
    }

    /**
     * GAME-838 slice 2: told about every recorded entry and every undo and redo. See
     * [OnHistoryListener]. Set through [PhotoEditor.setOnHistoryListener].
     */
    var onHistoryListener: OnHistoryListener? = null

    internal fun notifyUndone(operation: EditorOperation) {
        onHistoryListener?.onUndone(operation.kind, operation.graphic)
    }

    internal fun notifyRedone(operation: EditorOperation) {
        onHistoryListener?.onRedone(operation.kind, operation.graphic)
    }

    internal fun popUndoOperation(): EditorOperation? = undoOperations.removeLastOrNull()

    internal fun pushRedoOperation(operation: EditorOperation) = redoOperations.addLast(operation)

    internal fun popRedoOperation(): EditorOperation? = redoOperations.removeLastOrNull()

    internal fun pushUndoOperation(operation: EditorOperation) = undoOperations.addLast(operation)

    /** Whether [PhotoEditor.undo] would do anything. */
    val undoCount: Int get() = undoOperations.size

    /** Whether [PhotoEditor.redo] would do anything. */
    val redoCount: Int get() = redoOperations.size

    fun clearHistory() {
        undoOperations.clear()
        redoOperations.clear()
    }

    fun clearRedoViews() {
        redoViews.clear()
    }

    fun pushRedoView(view: View) {
        redoViews.push(view)
    }

    fun popRedoView(): View {
        return redoViews.pop()
    }

    val redoViewsCount: Int
        get() = redoViews.size

    fun getRedoView(index: Int): View {
        return redoViews[index]
    }

    init {
        addedViews = ArrayList()
        redoViews = Stack()
        multiTouchListenerByView = HashMap()
    }
}