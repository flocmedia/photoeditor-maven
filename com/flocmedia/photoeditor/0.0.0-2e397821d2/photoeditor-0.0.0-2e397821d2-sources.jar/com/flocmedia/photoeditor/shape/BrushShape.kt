package com.flocmedia.photoeditor.shape

import android.graphics.Canvas
import android.graphics.Paint
import android.util.Log
import kotlin.math.abs
import kotlin.math.hypot

class BrushShape : AbstractShape("BrushShape") {
    var offsetX = 0f
        private set
    var offsetY = 0f
        private set
    // GAME-1035: readable so the post-crop adjustCanvas transform can be serialized
    // with the stroke and re-applied on restore. `private set` keeps adjustCanvas
    // the only writer.
    var scaleX = 1f
        private set
    var scaleY = 1f
        private set

    fun adjustCanvas(newOffsetX: Float, newOffsetY: Float, newScaleX: Float, newScaleY: Float) {
        scaleX *= newScaleX
        scaleY *= newScaleY

        offsetX = newOffsetX
        offsetY = newOffsetY
    }

    override fun draw(canvas: Canvas, paint: Paint) {
        canvas.save()

        canvas.translate(offsetX, offsetY)
        canvas.scale(scaleX, scaleY)

        // GAME-1132: paint strokes taper by draw speed. Fall back to the single
        // constant-width Path for the eraser (its precision must not vary), for a
        // stroke with too few points to have a segment, or for one with no time
        // base (a legacy draft, times all 0) -- there velocity is undefined and
        // the old behaviour is exactly right.
        if (isEraser || points.size < 2 || pointTimes.size != points.size || !hasTimeBase()) {
            canvas.drawPath(path, paint)
        } else {
            val base = paint.strokeWidth
            var prevWidth = base
            for (i in 0 until points.size - 1) {
                val a = points[i]
                val b = points[i + 1]
                val dt = (pointTimes[i + 1] - pointTimes[i]).coerceAtLeast(0L)
                val dist = hypot((b.x - a.x).toDouble(), (b.y - a.y).toDouble()).toFloat()
                val velocity = if (dt > 0L) dist / dt else 0f
                val width = VelocityWidth.widthFor(base, velocity, prevWidth)
                prevWidth = width
                paint.strokeWidth = width
                canvas.drawLine(a.x, a.y, b.x, b.y, paint)
            }
            // Restore the nominal width: serialization reads paint.strokeWidth
            // back as the stroke's base (see EditImageActivity.serializeBrush).
            paint.strokeWidth = base
        }

        canvas.restore()
    }

    /** True once at least two recorded points have distinct, increasing times. */
    private fun hasTimeBase(): Boolean {
        for (i in 1 until pointTimes.size) {
            if (pointTimes[i] > pointTimes[i - 1]) return true
        }
        return false
    }

    override fun startShape(x: Float, y: Float) {
        Log.d(tag, "startShape@ $x,$y")
        path.moveTo(x, y)
        left = x
        top = y
    }

    override fun moveShape(x: Float, y: Float) {
        val dx = abs(x - left)
        val dy = abs(y - top)
        if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
            path.quadTo(left, top, (x + left) / 2, (y + top) / 2)
            left = x
            top = y
        }
    }

    override fun stopShape() {
        Log.d(tag, "stopShape")
    }
}