package com.flocmedia.photoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout

/**
 * Wraps the immediate parent of a graphic's CONTENT view (the sticker image or
 * the text). Composites any child carrying a [GraphicBlendMode] tag against the
 * layers already drawn beneath it (GAME-703) by wrapping the child's draw in a
 * [Canvas.saveLayer] whose paint carries the blend mode.
 *
 * It wraps only the content -- not the graphic root -- so a blended graphic does
 * NOT blend its selection border or resize handles (those are drawn outside this
 * layer). The content still composites against the photo, because this layer's
 * ancestors do not isolate: by the time the content draws, the canvas already
 * holds the photo.
 *
 * This one override reaches BOTH the live screen AND the `View.draw`-based export
 * (`PhotoSaverTask`), because drawChild runs in both. A blend-aware
 * [android.graphics.BlendMode] is alpha-correct, so the content's transparent
 * surround leaves the backdrop intact -- unlike PorterDuffXfermode, which erases
 * it. Blend is therefore API 29+ only; below that, and for NORMAL, the child is
 * drawn as-is.
 */
class BlendableFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    override fun drawChild(canvas: Canvas, child: View, drawingTime: Long): Boolean {
        // Blend (GAME-703): a BlendMode is alpha-aware but API 29+ only, so it
        // applies only from Q and never for NORMAL.
        val mode = child.getTag(R.id.blend_mode_tag) as? GraphicBlendMode
        val blend = if (mode != null && mode != GraphicBlendMode.NORMAL &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        ) {
            mode.toBlendMode()
        } else {
            null
        }

        // Adjustment (GAME-692): a ColorMatrixColorFilter, API-agnostic. Used for
        // text, whose TextView cannot render a colorFilter on its own in the
        // View.draw export.
        val adjustFilter = child.getTag(R.id.adjust_filter_tag) as? ColorMatrixColorFilter

        if (blend == null && adjustFilter == null) {
            return super.drawChild(canvas, child, drawingTime)
        }

        // One layer carries both: the paint's colorFilter transforms the child's
        // pixels and its blendMode composites the result against the backdrop.
        // Whole-canvas layer is safe: blend is alpha-aware and a colour matrix
        // leaves fully-transparent pixels transparent, so the surround does not
        // touch the backdrop.
        val paint = Paint().apply {
            if (blend != null) blendMode = blend
            if (adjustFilter != null) colorFilter = adjustFilter
        }
        val count = canvas.saveLayer(null, paint)
        val result = super.drawChild(canvas, child, drawingTime)
        canvas.restoreToCount(count)
        return result
    }
}
