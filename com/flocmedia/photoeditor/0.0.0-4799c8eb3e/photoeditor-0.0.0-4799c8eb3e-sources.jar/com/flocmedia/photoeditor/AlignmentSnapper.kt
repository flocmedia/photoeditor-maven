package com.flocmedia.photoeditor

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Pure geometry for GAME-702 snapping/alignment guides: given where a dragged
 * graphic WOULD land, nudge it so a salient feature (an edge or its centre)
 * lines up with the canvas centre/edges or another graphic's edge/centre, and
 * report which guide line to draw.
 *
 * Deliberately free of any Android type -- boxes are plain floats -- so the whole
 * thing is unit-testable on the JVM without a view, a Paint, or Robolectric. The
 * [MultiTouchListener] builds the boxes from live views and applies the result.
 */
object AlignmentSnapper {

    /** An axis-aligned box in canvas pixels. */
    data class Box(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val centerX get() = (left + right) / 2f
        val centerY get() = (top + bottom) / 2f
    }

    /**
     * The correction to add to the dragged graphic's proposed position, plus the
     * canvas-space coordinate of each active guide line (null = no snap on that
     * axis, so no line to draw).
     */
    data class SnapResult(
        val dx: Float,
        val dy: Float,
        val verticalGuideX: Float?,
        val horizontalGuideY: Float?,
    ) {
        val snapped get() = verticalGuideX != null || horizontalGuideY != null
    }

    val NONE = SnapResult(0f, 0f, null, null)

    /**
     * The box of the VISIBLE artwork for a graphic whose root view is at
     * ([x], [y]) (top-left, canvas pixels) with unscaled size [viewW]x[viewH]
     * and centre scale [scaleX]/[scaleY].
     *
     * A graphic's root view is [gutter] px larger than its artwork on every
     * edge: the corner drag handles and the selection frame live in that gutter
     * (imgPhotoEditorImageBlendWrapper is constrained between the handles;
     * tvPhotoEditorText sits inside frmBorder's handle-sized padding). Snapping
     * to the root box therefore aligned that invisible gutter, so a guide sat a
     * gutter-width (up to 48dp) off the sticker the user sees and edges never
     * lined up (GAME-1253 Part 2). Insetting by the gutter fixes that; because
     * the inset is symmetric the centre is unchanged, so centre-to-centre
     * snapping is unaffected.
     *
     * The gutter is inset in unscaled pixels and the result scaled about the
     * centre, matching how the view is drawn (scale is about the view centre).
     * A graphic scaled small enough that the gutter would meet in the middle
     * clamps to a zero-size box at the centre rather than inverting.
     */
    fun artworkBox(
        x: Float,
        y: Float,
        viewW: Float,
        viewH: Float,
        scaleX: Float,
        scaleY: Float,
        gutter: Float,
    ): Box {
        val cx = x + viewW / 2f
        val cy = y + viewH / 2f
        val hw = (viewW / 2f - gutter).coerceAtLeast(0f) * scaleX
        val hh = (viewH / 2f - gutter).coerceAtLeast(0f) * scaleY
        return Box(cx - hw, cy - hh, cx + hw, cy + hh)
    }

    /**
     * @param dragged   where the graphic would land with no snapping.
     * @param canvasW/H the canvas (photo) bounds the graphic aligns to.
     * @param others    every OTHER graphic's box (already filtered to live ones).
     * @param threshold how close, in px, a feature must be to snap (exclusive).
     *
     * Only the SINGLE graphic nearest the dragged one (by centre-to-centre
     * distance) contributes guide lines -- GAME-1156. With 4-5 stickers, feeding
     * every graphic's left/centre/right and top/centre/bottom made most of the
     * canvas one continuous capture band ("a blue grid that stops placement");
     * restricting graphic guides to the nearest neighbour keeps deliberate
     * sticker-to-sticker alignment while freeing the rest of the canvas. The
     * canvas centre/edges are always candidates regardless of neighbours.
     */
    fun snap(
        dragged: Box,
        canvasW: Float,
        canvasH: Float,
        others: List<Box>,
        threshold: Float,
    ): SnapResult {
        val nearest = nearestByCenter(dragged, others)
        // Candidate lines per axis: canvas near edge, centre, far edge, plus the
        // nearest other graphic's near edge / centre / far edge (if any).
        val xLines = ArrayList<Float>(3 + 3).apply {
            add(0f); add(canvasW / 2f); add(canvasW)
            nearest?.let { add(it.left); add(it.centerX); add(it.right) }
        }
        val yLines = ArrayList<Float>(3 + 3).apply {
            add(0f); add(canvasH / 2f); add(canvasH)
            nearest?.let { add(it.top); add(it.centerY); add(it.bottom) }
        }
        val (dx, vGuide) = snapAxis(listOf(dragged.left, dragged.centerX, dragged.right), xLines, threshold)
        val (dy, hGuide) = snapAxis(listOf(dragged.top, dragged.centerY, dragged.bottom), yLines, threshold)
        return SnapResult(dx, dy, vGuide, hGuide)
    }

    /**
     * The one box in [others] whose centre is closest to [dragged]'s centre, or
     * null when there are none. Ties resolve to the first-seen box.
     */
    private fun nearestByCenter(dragged: Box, others: List<Box>): Box? =
        others.minByOrNull { hypot(it.centerX - dragged.centerX, it.centerY - dragged.centerY) }

    /**
     * The closest (feature, line) pair within [threshold] on one axis, as the
     * shift that lands the feature on the line and the line itself (the guide).
     * Ties resolve to the first-seen line, which orders canvas guides before
     * graphic guides -- the canvas centre wins over a coincident graphic edge.
     */
    private fun snapAxis(
        features: List<Float>,
        lines: List<Float>,
        threshold: Float,
    ): Pair<Float, Float?> {
        var bestGap = threshold
        var bestShift = 0f
        var bestGuide: Float? = null
        for (line in lines) {
            for (f in features) {
                val gap = abs(line - f)
                if (gap < bestGap) {
                    bestGap = gap
                    bestShift = line - f
                    bestGuide = line
                }
            }
        }
        return bestShift to bestGuide
    }
}
