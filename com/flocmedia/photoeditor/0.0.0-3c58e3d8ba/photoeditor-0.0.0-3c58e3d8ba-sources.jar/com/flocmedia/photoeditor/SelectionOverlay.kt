package com.flocmedia.photoeditor

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.customview.widget.ExploreByTouchHelper
import kotlin.math.hypot

/**
 * GAME-840: draws the selected graphic's chrome -- a thin frame around the artwork and a
 * handle disc on each corner / edge midpoint -- in ONE view that is never transformed, so
 * the chrome is the same size on screen at every canvas zoom and every sticker scale (the
 * GAME-1311 §05 mock). It replaces what was drawn inside the scaled graphic view (frmBorder's
 * border and the handle ImageViews), which grew and shrank with the zoom (GAME-256/427).
 *
 * It sits in [PhotoEditorView] ABOVE `parentLayout` (so outside the zoom transform) and only
 * exists while [PhotoEditorView.isSelectionOverlayEnabled] is on.
 *
 * WHERE: [SelectionGeometry] maps the artwork's layout rect up the view chain. It is read on
 * every pre-draw of the editor while something is selected, so pinch, pan, drag, corner and
 * edge gestures all move the chrome in the same frame as the graphic -- and it redraws only
 * when the geometry or a handle's visibility actually changed.
 *
 * WHICH HANDLES: the in-view handle views stay in the layout as the source of truth for
 * visibility -- the host hides them during a gesture and shows them after, exactly as before
 * -- and this view draws a disc for each one that is VISIBLE. The in-view handles themselves
 * draw nothing any more ([InViewChrome.suppress]).
 *
 * NEVER IN AN EXPORT: export captures the editor with `View.draw` ([PhotoSaverTask]); this
 * view draws nothing while [PhotoEditorView.isCapturing], and nothing with no selection.
 *
 * TOUCH: it is the editor's top child, so it sees every touch first. A DOWN on a visible
 * handle's target (a [R.dimen.handle_size] square, larger than the drawn disc) goes to
 * [handleTouchListener] -- the host's existing corner/edge handler, fed the same MotionEvent
 * (so the same rawX/rawY) the in-view handle used to receive -- and the rest of that stream
 * follows it. Anything else returns false and falls through to the canvas exactly as before.
 * The one exception: a DOWN on the BODY but off the drawn disc is the body's, not a handle's.
 * On the image itself it falls through to move the graphic, exactly as before. The body of a
 * sticker smaller than [R.dimen.selection_min_grab_size] is widened to that size (owner,
 * 2026-09-29: the image may be scaled well below a fingertip, the grab area may not); a DOWN
 * there, off the image, is dragged from here through the canvas's own drag-the-selection
 * listener ([PhotoEditorView.dragSelectedBy]) -- unless another graphic's image is under the
 * finger, which then gets it exactly as before. The buffer belongs to the SELECTED graphic
 * only: it never selects an unselected one (owner, 2026-09-29).
 *
 * ACCESSIBILITY: each visible handle is a virtual node carrying the in-view handle's id
 * (`imgHandleTopLeft` ...), at the overlay target -- so TalkBack can find the handles and UI
 * tests that address a handle by id keep working, against the real (overlay) position.
 */
@SuppressLint("ViewConstructor")
class SelectionOverlay internal constructor(
    context: Context,
    private val editor: PhotoEditorView,
) : View(context) {

    private val res = context.resources
    private val outsetPx = res.getDimension(R.dimen.selection_frame_outset)
    private val frameRadiusPx = res.getDimension(R.dimen.selection_frame_radius)
    private val discRadiusPx = res.getDimension(R.dimen.selection_handle_diameter) / 2f
    private val ringPx = res.getDimension(R.dimen.selection_handle_ring)
    private val glyphPx = res.getDimension(R.dimen.selection_handle_glyph)
    private val targetPx = res.getDimension(R.dimen.handle_size)
    private val textDiscGapPx = res.getDimension(R.dimen.selection_text_min_disc_gap)
    private val minGrabPx = res.getDimension(R.dimen.selection_min_grab_size)

    /**
     * Receives every event of a touch that STARTED on a handle. Return false from a DOWN to
     * decline it (e.g. the handle is hidden), and it falls through to the canvas.
     */
    var handleTouchListener: SelectionHandleTouchListener? = null

    private var activeHandle: SelectionHandle? = null
    private var activeRoot: View? = null

    /** A touch stream that started on a small graphic's grab area, off its image. */
    private var draggingBody = false

    private val a11y = HandleAccessibility()

    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = res.getDimension(R.dimen.selection_frame_stroke)
        color = ContextCompat.getColor(context, R.color.selection_frame)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.selection_handle_fill)
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ringPx
        color = ContextCompat.getColor(context, R.color.selection_handle_ring)
    }

    private val glyphs: Map<SelectionHandle, Drawable> = SelectionHandle.values().associateWith {
        ContextCompat.getDrawable(context, glyphFor(it))!!.mutate()
    }

    /** The chrome as last computed, or null (nothing to draw). */
    internal var chrome: Chrome? = null
        private set

    /** Which handles are drawn -- the in-view handles that are VISIBLE. */
    internal var visibleHandles: Set<SelectionHandle> = emptySet()
        private set

    private val preDrawListener = ViewTreeObserver.OnPreDrawListener {
        refresh()
        true
    }

    init {
        // Not clickable: a touch that is not on a handle must never be consumed here.
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        ViewCompat.setAccessibilityDelegate(this, a11y)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        editor.viewTreeObserver.addOnPreDrawListener(preDrawListener)
    }

    override fun onDetachedFromWindow() {
        editor.viewTreeObserver.removeOnPreDrawListener(preDrawListener)
        super.onDetachedFromWindow()
    }

    /**
     * Recomputes the chrome from the live views; invalidates only on a change.
     * @return true if it changed.
     */
    internal fun refresh(): Boolean {
        val root = editor.selectedGraphic()
        val next = root?.let { compute(it) }
        val nextVisible = if (root != null && next != null) InViewChrome.visibleHandles(root) else emptySet()
        if (next == chrome && nextVisible == visibleHandles) return false
        chrome = next
        visibleHandles = nextVisible
        invalidate()
        a11y.invalidateRoot()
        return true
    }

    /** The handle a touch at ([x],[y]) in this view would grab, or null. */
    internal fun handleAt(x: Float, y: Float): SelectionHandle? {
        val c = chrome ?: return null
        return SelectionGeometry.hitTest(c, x, y, targetPx, visibleHandles, bodyWinsOutsideDiscPx = discRadiusPx)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            activeHandle = null
            activeRoot = null
            draggingBody = false
            refresh() // the chrome is from the last pre-draw; make sure it is this frame's
            val root = editor.selectedGraphic()
            val c = chrome
            if (root != null && c != null) {
                val listener = handleTouchListener
                val handle = if (listener != null) handleAt(event.x, event.y) else null
                if (handle != null && listener!!.onHandleTouch(root, handle, event)) {
                    activeHandle = handle
                    activeRoot = root
                    return true
                }
                // On the image: the graphic's own view takes it, exactly as before.
                if (SelectionGeometry.isOnArt(c, event.x, event.y)) return false
                // On the buffer around a small image: drag it from here -- unless another
                // graphic's image is under the finger, which then gets the touch as it would
                // without the buffer (owner, 2026-09-29).
                if (SelectionGeometry.isOnBody(c, event.x, event.y)) {
                    if (isAnotherImageAt(event.x, event.y, root)) return false
                    return startBodyDrag(event)
                }
            }
            return false
        }
        if (draggingBody) {
            editor.dragSelectedBy?.invoke(event)
            val a = event.actionMasked
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) draggingBody = false
            return true
        }
        val handle = activeHandle ?: return false
        val root = activeRoot ?: return false
        handleTouchListener?.onHandleTouch(root, handle, event)
        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            activeHandle = null
            activeRoot = null
        }
        return true
    }

    /**
     * GAME-840: is another graphic's IMAGE (any, above or below [selected]) under ([x],[y])?
     * The buffer only takes touches nothing else would: it never selects a graphic and never
     * steals one from an image underneath (owner, 2026-09-29).
     */
    private fun isAnotherImageAt(x: Float, y: Float, selected: View): Boolean =
        editor.graphicsTopDown().any { g ->
            g !== selected && compute(g)?.let { SelectionGeometry.isOnArt(it, x, y) } == true
        }

    private fun startBodyDrag(event: MotionEvent): Boolean {
        val drag = editor.dragSelectedBy ?: return false
        draggingBody = true
        drag(event)
        return true
    }

    override fun dispatchHoverEvent(event: MotionEvent): Boolean =
        a11y.dispatchHoverEvent(event) || super.dispatchHoverEvent(event)

    /** A handle's touch target, axis-aligned on screen (its bounding box when rotated). */
    internal fun targetBounds(handle: SelectionHandle, out: Rect): Boolean {
        val c = chrome ?: return false
        val centre = c.handles[handle] ?: return false
        val half = targetPx / 2f
        // The square target turns with the graphic; its screen bounding box is half*(|cos|+|sin|).
        val reach = half * (kotlin.math.abs(c.axisX.x) + kotlin.math.abs(c.axisX.y))
        out.set(
            (centre.x - reach).toInt(), (centre.y - reach).toInt(),
            (centre.x + reach).toInt(), (centre.y + reach).toInt(),
        )
        return true
    }

    private inner class HandleAccessibility : ExploreByTouchHelper(this@SelectionOverlay) {
        private val bounds = Rect()

        override fun getVirtualViewAt(x: Float, y: Float): Int =
            handleAt(x, y)?.ordinal ?: INVALID_ID

        override fun getVisibleVirtualViews(ids: MutableList<Int>) {
            val c = chrome ?: return
            for (handle in c.handles.keys) if (handle in visibleHandles) ids.add(handle.ordinal)
        }

        override fun onPopulateNodeForVirtualView(id: Int, node: AccessibilityNodeInfoCompat) {
            val handle = SelectionHandle.values()[id]
            if (!targetBounds(handle, bounds)) bounds.set(0, 0, 1, 1)
            @Suppress("DEPRECATION")
            node.setBoundsInParent(bounds)
            node.contentDescription = contentDescriptionFor(handle)
            InViewChrome.handleIds[handle]?.let { node.viewIdResourceName = resources.getResourceName(it) }
        }

        override fun onPerformActionForVirtualView(id: Int, action: Int, arguments: Bundle?): Boolean = false
    }

    private fun compute(root: View): Chrome? {
        val art: View = root.findViewById(R.id.imgPhotoEditorImage)
            ?: root.findViewById(R.id.tvPhotoEditorText)
            ?: return null
        if (art.visibility != VISIBLE) return null
        // The chain starts at the artwork's PARENT: the artwork's own transform (a flip is
        // rotationY on it) must not move or relabel the handles.
        val chain = ArrayList<ViewXform>(6)
        var v: View = art.parent as? View ?: return null
        while (v !== editor) {
            chain.add(ViewXform.of(v))
            v = v.parent as? View ?: return null // detached from the editor: nothing to draw
        }
        val quad = SelectionGeometry.artQuad(
            art.left.toFloat(), art.top.toFloat(), art.right.toFloat(), art.bottom.toFloat(), chain,
        ) ?: return null
        val withEdges = InViewChrome.hasEdgeHandles(root)
        // Text and emoji (corner discs only) never let those discs come closer than the gap,
        // however narrow the text -- a single character (owner, 2026-09-28). A sticker's grab
        // area never gets smaller than a fingertip, however small its image (owner, 2026-09-29).
        // All eight handles stay, even on a tiny sticker (owner, 2026-09-29: "keep all handles
        // visible"); on the widened frame (>= grab + 2 x outset) the discs cannot crowd.
        val minSide = if (withEdges) minGrabPx + 2f * outsetPx else discRadiusPx * 2f + textDiscGapPx
        return SelectionGeometry.chrome(quad, outsetPx, withEdges, minSide, dropGrownEdges = false)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (editor.isCapturing) return
        val c = chrome ?: return
        drawFrame(canvas, c)
        for ((handle, centre) in c.handles) {
            if (handle in visibleHandles) drawHandle(canvas, handle, centre, c.angleDegrees)
        }
    }

    private val frameRect = RectF()

    private fun drawFrame(canvas: Canvas, c: Chrome) {
        val f = c.frame
        val cx = (f.topLeft.x + f.bottomRight.x) / 2f
        val cy = (f.topLeft.y + f.bottomRight.y) / 2f
        val halfW = hypot((f.topRight.x - f.topLeft.x).toDouble(), (f.topRight.y - f.topLeft.y).toDouble()).toFloat() / 2f
        val halfH = hypot((f.bottomLeft.x - f.topLeft.x).toDouble(), (f.bottomLeft.y - f.topLeft.y).toDouble()).toFloat() / 2f
        canvas.save()
        canvas.rotate(c.angleDegrees, cx, cy)
        frameRect.set(cx - halfW, cy - halfH, cx + halfW, cy + halfH)
        canvas.drawRoundRect(frameRect, frameRadiusPx, frameRadiusPx, framePaint)
        canvas.restore()
    }

    private fun drawHandle(canvas: Canvas, handle: SelectionHandle, centre: Pt, angle: Float) {
        canvas.drawCircle(centre.x, centre.y, discRadiusPx, fillPaint)
        // The ring is drawn INSIDE the disc's 24dp: stroke centred half a ring in.
        canvas.drawCircle(centre.x, centre.y, discRadiusPx - ringPx / 2f, ringPaint)
        val g = glyphs.getValue(handle)
        val half = (glyphPx / 2f).toInt()
        canvas.save()
        canvas.rotate(angle, centre.x, centre.y)
        g.setBounds(centre.x.toInt() - half, centre.y.toInt() - half, centre.x.toInt() + half, centre.y.toInt() + half)
        g.draw(canvas)
        canvas.restore()
    }

    internal companion object {
        fun contentDescriptionFor(handle: SelectionHandle): String = when (handle) {
            SelectionHandle.TOP_LEFT -> "Resize and rotate, top left"
            SelectionHandle.TOP_RIGHT -> "Resize and rotate, top right"
            SelectionHandle.BOTTOM_RIGHT -> "Resize and rotate, bottom right"
            SelectionHandle.BOTTOM_LEFT -> "Resize and rotate, bottom left"
            SelectionHandle.TOP -> "Stretch, top edge"
            SelectionHandle.RIGHT -> "Stretch, right edge"
            SelectionHandle.BOTTOM -> "Stretch, bottom edge"
            SelectionHandle.LEFT -> "Stretch, left edge"
        }

        fun glyphFor(handle: SelectionHandle): Int = when (handle) {
            SelectionHandle.TOP_LEFT, SelectionHandle.BOTTOM_RIGHT -> R.drawable.ic_selection_glyph_diagonal_nwse
            SelectionHandle.TOP_RIGHT, SelectionHandle.BOTTOM_LEFT -> R.drawable.ic_selection_glyph_diagonal_nesw
            SelectionHandle.TOP, SelectionHandle.BOTTOM -> R.drawable.ic_selection_glyph_vertical
            SelectionHandle.LEFT, SelectionHandle.RIGHT -> R.drawable.ic_selection_glyph_horizontal
        }
    }
}

/**
 * The chrome that used to be drawn INSIDE each graphic view. With the overlay on it stays in
 * the layout -- its 48dp boxes are still part of the graphic's size (cut 1 keeps the inset),
 * and the handles' VISIBLE/INVISIBLE state is still how the host says which to show -- but
 * it no longer draws anything.
 */
internal object InViewChrome {
    val handleIds: Map<SelectionHandle, Int> = linkedMapOf(
        SelectionHandle.TOP_LEFT to R.id.imgHandleTopLeft,
        SelectionHandle.TOP_RIGHT to R.id.imgHandleTopRight,
        SelectionHandle.BOTTOM_RIGHT to R.id.imgHandleBottomRight,
        SelectionHandle.BOTTOM_LEFT to R.id.imgHandleBottomLeft,
        SelectionHandle.TOP to R.id.imgHandleTop,
        SelectionHandle.RIGHT to R.id.imgHandleRight,
        SelectionHandle.BOTTOM to R.id.imgHandleBottom,
        SelectionHandle.LEFT to R.id.imgHandleLeft,
    )

    fun hasEdgeHandles(root: View): Boolean = root.findViewById<View>(R.id.imgHandleTop) != null

    fun visibleHandles(root: View): Set<SelectionHandle> =
        handleIds.filter { (_, id) -> root.findViewById<View>(id)?.visibility == View.VISIBLE }.keys

    /**
     * Stop the graphic's own border and handle glyphs from drawing, and take the in-view
     * handles out of the accessibility tree (the overlay's virtual nodes replace them).
     * Idempotent.
     */
    fun suppress(root: View) {
        root.findViewById<View>(R.id.frmBorder)?.background = null
        for (id in handleIds.values) {
            root.findViewById<ImageView>(id)?.apply {
                setImageDrawable(null)
                background = null
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
        }
    }
}

/**
 * GAME-840: the host's handler for a touch that started on a selection handle. [event] is the
 * real MotionEvent (use `rawX/rawY`, as the in-view handle listeners did). Return false from
 * the DOWN to decline the touch.
 */
fun interface SelectionHandleTouchListener {
    fun onHandleTouch(graphicRoot: View, handle: SelectionHandle, event: MotionEvent): Boolean
}
