package com.flocmedia.photoeditor

import android.view.View
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Which of a graphic's four mid-edge handles a one-axis stretch is driving
 * (GAME-1259). The sibling of [CornerHandle]: corners scale+rotate proportionally,
 * edges stretch a single axis with the opposite edge anchored.
 */
enum class EdgeHandle {
    TOP,
    RIGHT,
    BOTTOM,
    LEFT,
    ;

    /** True for LEFT/RIGHT (they change WIDTH); false for TOP/BOTTOM (HEIGHT). */
    val isHorizontal: Boolean get() = this == LEFT || this == RIGHT
}

/**
 * What a mid-edge drag ACTION_MOVE resolves to: the new layoutParams size on the
 * one axis the [edge] stretches. The host applies it (a sticker rewrites its
 * scale tag through `stretchSticker`, and re-anchors the opposite edge), exactly
 * as it applies a [CornerGestureUpdate].
 *
 * Only ONE dimension changes; the other is left to the host's current value. The
 * opposite edge is kept fixed on the host side (resize about centre + a half-delta
 * translation) because that needs the view's live position, not just its geometry.
 */
data class EdgeGestureUpdate(
    val itemRootFrameView: View,
    val edge: EdgeHandle,
    /** New size on the stretched axis, in the root's layoutParams px (unzoomed). */
    val newSizePx: Int,
    val editorScaleX: Float,
)

/**
 * The mid-edge one-axis stretch gesture (GAME-1259), mirroring [CornerGesture].
 *
 * The four edge handles are app-owned views layered over the graphic that absorb
 * their own touch stream, so the app drives the gesture: [begin] primes the
 * anchor, [update] projects the finger onto the edge normal to a new size, the app
 * keeps the touch plumbing and applies the resize.
 *
 * Unlike a corner (radius from the centre → uniform scale + rotation), an edge is a
 * single axis: the drag is projected onto the graphic's OUTWARD EDGE NORMAL in its
 * rotated frame, so only the perpendicular component moves the edge and a drag
 * along the edge does nothing. `deltaAngle` is always 0.
 */
internal object EdgeGesture {

    /** Minimum stretched-axis size in layoutParams px, so a drag can't invert or
     *  collapse the graphic. The host clamps further via `isValidStickerDimensions`. */
    private const val MIN_SIZE_PX = 1

    fun begin(listener: MultiTouchListener, edge: EdgeHandle, rawX: Float, rawY: Float) {
        val itemRoot = listener.itemRootFrameView ?: return

        listener.beginExternalGesture()

        listener.isCornerMovable = true
        listener.isTouchMovable = false
        listener.edgeHandle = edge

        listener.editorScale = listener.photoEditorView.parentLayout.scaleX

        listener.centerX = (itemRoot.left + itemRoot.right) / 2f
        listener.centerY = (itemRoot.top + itemRoot.bottom) / 2f

        listener.adjustedScaledWidth = itemRoot.width * listener.editorScale
        listener.adjustedScaledHeight = itemRoot.height * listener.editorScale

        val rotation = itemRoot.rotation + listener.canvasView.rotation
        val anchor = edgeAnchor(
            edge,
            listener.centerX,
            listener.centerY,
            listener.adjustedScaledWidth,
            listener.adjustedScaledHeight,
            itemRoot.scaleX,
            rotation,
        )
        listener.coordinateX = anchor.x
        listener.coordinateY = anchor.y

        listener.startX = rawX - listener.coordinateX + listener.centerX
        listener.startY = rawY - listener.coordinateY + listener.centerY

        // The centre→edge distance along the outward normal is the half-extent of
        // the stretched axis. Scale is measured against it.
        val outward = edgeOutwardUnit(edge, rotation)
        listener.startR =
            ((anchor.x - listener.centerX) * outward.first +
                (anchor.y - listener.centerY) * outward.second).toFloat()
    }

    fun update(listener: MultiTouchListener, rawX: Float, rawY: Float): EdgeGestureUpdate? {
        val itemRoot = listener.itemRootFrameView ?: return null
        val edge = listener.edgeHandle ?: return null
        if (listener.startR == 0f) return null

        val rotation = itemRoot.rotation + listener.canvasView.rotation
        val outward = edgeOutwardUnit(edge, rotation)

        // Project the finger (in the same centre-relative frame begin set up) onto
        // the outward edge normal. A drag along the edge contributes nothing.
        // fingerFromCentre == startR (the half-extent) at gesture start.
        val fingerFromCentre =
            ((rawX - listener.startX) * outward.first +
                (rawY - listener.startY) * outward.second)
        val deltaScale = edgeStretchScale(fingerFromCentre.toFloat(), listener.startR)

        // Start size on the stretched axis, back out of the editor zoom.
        val startSizePx =
            if (edge.isHorizontal) listener.adjustedScaledWidth / listener.editorScale
            else listener.adjustedScaledHeight / listener.editorScale
        val newSizePx = (startSizePx * deltaScale).roundToInt().coerceAtLeast(MIN_SIZE_PX)

        return EdgeGestureUpdate(
            itemRootFrameView = itemRoot,
            edge = edge,
            newSizePx = newSizePx,
            editorScaleX = listener.photoEditorView.parentLayout.scaleX,
        )
    }
}

/**
 * The one-axis stretch scale factor (applied to the graphic's full extent) for a
 * finger [fingerFromCentre] px along the outward normal, where [halfExtent] is the
 * centre→edge distance at gesture start (== `fingerFromCentre` at the start).
 *
 * Referenced to the FIXED OPPOSITE edge (the full extent, `2·halfExtent`), NOT the
 * centre: the host keeps the opposite edge pinned (resize-about-centre + a
 * half-delta translate), which itself moves the centre toward the finger, so a
 * centre-referenced scale (`fingerFromCentre / halfExtent`) makes the dragged edge
 * travel TWICE the finger. Measuring from the fixed opposite edge instead makes the
 * dragged edge track the finger 1:1 (GAME-1259 accel fix). Derivation: with the
 * opposite edge fixed, `newExtent = fingerFromCentre + halfExtent` is the finger's
 * distance from that edge, and `scale = newExtent / (2·halfExtent)` grows the full
 * extent by exactly the finger's displacement.
 */
internal fun edgeStretchScale(fingerFromCentre: Float, halfExtent: Float): Float =
    if (halfExtent == 0f) 1f else (fingerFromCentre + halfExtent) / (2f * halfExtent)

/** The outward unit normal of [edge] in screen coordinates (y-down), at
 *  [rotationDegrees] (graphic + canvas). Local axes: x = (cos, sin), y = (-sin,
 *  cos); RIGHT/LEFT point along ±x, BOTTOM/TOP along ±y. */
internal fun edgeOutwardUnit(edge: EdgeHandle, rotationDegrees: Float): Pair<Double, Double> {
    val theta = Math.toRadians(rotationDegrees.toDouble())
    val ax = cos(theta); val ay = sin(theta)   // local +x
    val bx = -sin(theta); val by = cos(theta)   // local +y
    return when (edge) {
        EdgeHandle.RIGHT -> ax to ay
        EdgeHandle.LEFT -> -ax to -ay
        EdgeHandle.BOTTOM -> bx to by
        EdgeHandle.TOP -> -bx to -by
    }
}

/**
 * The screen position of a graphic's mid-edge handle, mirroring [cornerAnchor].
 *
 * A corner sits half a DIAGONAL from the centre; an edge midpoint sits half the
 * WIDTH (left/right) or half the HEIGHT (top/bottom) along the graphic's outward
 * edge normal in its rotated frame. As with cornerAnchor, [graphicScale] multiplies
 * the already-editor-scaled extent and the arithmetic rounds once, at the end.
 */
internal fun edgeAnchor(
    edge: EdgeHandle,
    centerX: Float,
    centerY: Float,
    scaledWidth: Float,
    scaledHeight: Float,
    graphicScale: Float,
    rotationDegrees: Float,
): CornerAnchor {
    val halfExtent =
        if (edge.isHorizontal) scaledWidth / 2.0 * graphicScale
        else scaledHeight / 2.0 * graphicScale
    val outward = edgeOutwardUnit(edge, rotationDegrees)
    return CornerAnchor(
        (centerX + halfExtent * outward.first).toFloat(),
        (centerY + halfExtent * outward.second).toFloat(),
    )
}
