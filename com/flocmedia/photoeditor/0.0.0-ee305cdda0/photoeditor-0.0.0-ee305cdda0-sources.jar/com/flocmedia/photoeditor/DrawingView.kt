package com.flocmedia.photoeditor

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.util.AttributeSet
import android.util.Pair
import android.view.MotionEvent
import android.widget.ImageView
import com.flocmedia.photoeditor.shape.*
import java.util.*

/**
 *
 *
 * This is custom drawing view used to do painting on user touch events it it will paint on canvas
 * as per attributes provided to the paint
 *
 *
 * @author [Burhanuddin Rashid](https://github.com/burhanrashid52)
 * @version 0.1.1
 * @since 12/1/18
 */
class DrawingView @JvmOverloads constructor(
    context: Context?,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : ImageView(context, attrs, defStyle) {
    private val drawShapes = Stack<ShapeAndPaint?>()
    private val redoShapes = Stack<ShapeAndPaint?>()
    internal var currentShape: ShapeAndPaint? = null
    var isDrawingEnabled = false
        private set
    private var viewChangeListener: BrushViewChangeListener? = null
    var currentShapeBuilder: ShapeBuilder

    /**
     * Committed strokes, rasterized.
     *
     * TWO REASONS, and the first is the one that motivated it. A plain View
     * carries no drawable, and PostHog's wireframe replay only captures an
     * ImageView's `drawable` -- so brush strokes were invisible in every
     * replay. Not "masked": absent. Verified against the SDK: `getBackground()`
     * is read only through `toRGBColor()`, so a bitmap BACKGROUND would have
     * rendered as a flat colour; it has to be the image drawable.
     *
     * Second, onDraw used to replay the whole Stack every frame, so a long
     * brush session got progressively more expensive to draw.
     *
     * The stack remains the source of truth. This is a cache, rebuilt whenever
     * the stack changes -- stroke committed, undo, redo, clear.
     */
    private var strokeCache: Bitmap? = null
    private var strokeCanvas: Canvas? = null

    /**
     * True between ACTION_DOWN and the stroke ending.
     *
     * Needed because `createShape()` pushes the in-progress shape onto
     * `drawShapes` at ACTION_DOWN, so "the stack" and "what is committed" are
     * not the same thing mid-stroke. While this is true, the cache holds
     * everything EXCEPT `currentShape`, and onDraw paints that shape live on
     * top.
     *
     * A separate flag rather than nulling `currentShape` at stroke end:
     * DrawingViewApiTest reads `currentShape.paint` after drawing to assert
     * brush colour/size/opacity, and nulling it would break 13 tests for a
     * reason unrelated to what they check.
     */
    private var strokeInProgress = false

    // eraser parameters
    private var isErasing = false
    var eraserSize = DEFAULT_ERASER_SIZE

    // endregion
    private fun createPaint(): Paint {
        val paint = Paint()
        paint.isAntiAlias = true
        paint.isDither = true
        paint.style = Paint.Style.STROKE
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeCap = Paint.Cap.ROUND
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_OVER)

        // apply shape builder parameters
        currentShapeBuilder?.apply {
            paint.strokeWidth = this.shapeSize
            // 'paint.color' must be called before 'paint.alpha',
            // otherwise 'paint.alpha' value will be overwritten.
            paint.color = this.shapeColor
            shapeOpacity?.also { paint.alpha = it }
        }

        return paint
    }

    private fun createEraserPaint(): Paint {
        val paint = createPaint()
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        // Ported from upstream 76f1b03 ("using eraser size when in erasing mode"): without this,
        // the eraser always erased at createPaint()'s stroke width (from the current shape
        // builder), ignoring whatever eraserSize the user actually selected.
        paint.strokeWidth = eraserSize
        return paint
    }

    private fun setupBrushDrawing() {
        //Caution: This line is to disable hardware acceleration to make eraser feature work properly
        setLayerType(LAYER_TYPE_HARDWARE, null)
        visibility = GONE
        // The stroke cache is a view-sized bitmap set as our image drawable, so
        // FIT_XY blits it 1:1 with no matrix. adjustViewBounds MUST stay false:
        // with it true, ImageView resizes to the drawable's aspect ratio and,
        // combined with onMeasure below, is another way the drawable could drive
        // our bounds. See onMeasure for why that is fatal here (GAME-796).
        scaleType = ScaleType.FIT_XY
        adjustViewBounds = false
        currentShapeBuilder = ShapeBuilder()
    }

    /**
     * Measure exactly as the plain `View` this used to be — NOT as an ImageView.
     *
     * GAME-796: this view sits under four RelativeLayout ALIGN_TOP/BOTTOM/LEFT/
     * RIGHT rules to the photo (PhotoEditorView.setupDrawingView), which resolve
     * its rect to the photo's bounds. `ImageView.onMeasure` instead derives its
     * size from the drawable's intrinsic size, and with our WRAP_CONTENT height
     * and no drawable yet it collapsed the view to **height 0** — measured on
     * device as `onSizeChanged w=1028 h=0`. A zero-height view receives no touch
     * events, so no stroke was ever committed (0.000% export, blank canvas).
     *
     * `getDefaultSize` honours the EXACTLY spec the align rules hand down and
     * ignores the drawable entirely, which is precisely what the superclass
     * `View` did before this became an `ImageView`. Do not delete without an
     * on-device brush check — the JVM/Robolectric suite cannot see this.
     */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            getDefaultSize(suggestedMinimumWidth, widthMeasureSpec),
            getDefaultSize(suggestedMinimumHeight, heightMeasureSpec),
        )
    }

    fun clearAll() {
        drawShapes.clear()
        redoShapes.clear()
        rebuildStrokeCache()
    }

    fun setBrushViewChangeListener(brushViewChangeListener: BrushViewChangeListener?) {
        viewChangeListener = brushViewChangeListener
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        allocateStrokeCache(w, h)
    }

    /**
     * (Re)allocate the cache to match the view, and repopulate it.
     *
     * ARGB_8888 because the eraser composites with PorterDuff.CLEAR and needs a
     * real alpha channel to clear TO. On a surface without one, erasing would
     * paint black rather than remove ink.
     */
    private fun allocateStrokeCache(w: Int, h: Int) {
        if (w <= 0 || h <= 0) {
            strokeCache = null
            strokeCanvas = null
            setImageDrawable(null)
            return
        }
        if (strokeCache?.width == w && strokeCache?.height == h) return

        strokeCache?.recycle()
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        strokeCache = bitmap
        strokeCanvas = Canvas(bitmap)

        // rebuildStrokeCache() re-asserts the drawable via setImageBitmap on
        // every stroke (see its comment) so PostHog re-encodes the wireframe;
        // this initial set just makes the drawable non-null before the first
        // rebuild. onMeasure keeps the resulting requestLayout from resizing us.
        setImageBitmap(bitmap)
        rebuildStrokeCache()
    }

    /**
     * Replay the committed stack into the cache.
     *
     * Called whenever the stack changes rather than on a dirty flag, because
     * every mutation site here is already a discrete user action -- stroke
     * committed, undo, redo, clear -- not a per-frame event.
     */
    private fun rebuildStrokeCache() {
        val canvas = strokeCanvas ?: return
        canvas.drawColor(android.graphics.Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        for (shape in drawShapes) {
            // Skip the live stroke: it is already on the stack from ACTION_DOWN
            // but is not committed until endShape, and onDraw paints it
            // separately so the user sees it move.
            if (strokeInProgress && shape === currentShape) continue
            shape?.shape?.draw(canvas, shape.paint)
        }
        // Re-assert the drawable, NOT just invalidate(). PostHog's wireframe
        // capture caches an ImageView's base64 by drawable identity and does not
        // re-encode when the SAME bitmap is mutated in place -- so an invalidate()
        // alone leaves the replay holding the blank bitmap this cache was first
        // set with, and the stroke never reaches a replay (measured: the captured
        // DrawingView node was 0% non-transparent while the stroke was on screen).
        // setImageBitmap swaps in a fresh BitmapDrawable, which posthog re-encodes.
        //
        // Safe to do per stroke ONLY because onMeasure ignores the drawable, so
        // the requestLayout this triggers cannot resize us (see onMeasure). That
        // is the invariant the original "set once" comment was protecting; the
        // measurement fix removes the need for it. GAME-796.
        strokeCache?.let { setImageBitmap(it) }
    }

    public override fun onDraw(canvas: Canvas) {
        if (strokeCanvas == null) {
            // No cache yet -- the view has not been sized, so onSizeChanged has
            // not run. Replay the stack directly, exactly as this did before
            // the cache existed.
            //
            // NOT a defensive nicety. Without it an unsized view drops every
            // committed stroke and renders only the live one, because the
            // committed ones live in a bitmap that does not exist. Caught by
            // testCanvasIsDrawingCorrectlyOnDraw, which drives four ACTION_DOWNs
            // at a view that was never laid out and expects four draws.
            for (shape in drawShapes) {
                shape?.shape?.draw(canvas, shape.paint)
            }
            return
        }

        // The committed strokes, as a bitmap. This is what PostHog's wireframe
        // replay can actually see, and it replaces replaying the whole Stack
        // every frame.
        super.onDraw(canvas)

        // The live stroke on top. Still drawn straight onto the view canvas, so
        // an in-progress ERASER stroke composites against the hardware layer
        // set up in setupBrushDrawing() -- which is the reason that layer type
        // exists and why it is left alone.
        if (strokeInProgress) {
            currentShape?.let { it.shape.draw(canvas, it.paint) }
        }
    }

    /**
     * Handle touch event to draw paint on canvas i.e brush drawing
     *
     * @param event points having touch info
     * @return true if handling touch events
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        return if (isDrawingEnabled) {
            val touchX = event.x
            val touchY = event.y
            when (event.action) {
                MotionEvent.ACTION_DOWN -> onTouchEventDown(touchX, touchY)
                MotionEvent.ACTION_MOVE -> onTouchEventMove(touchX, touchY)
                MotionEvent.ACTION_UP -> onTouchEventUp(touchX, touchY)
            }
            invalidate()
            true
        } else {
            false
        }
    }

    private fun onTouchEventDown(touchX: Float, touchY: Float) {
        createShape()
        currentShape?.shape?.apply {
            startShape(touchX, touchY)
            // GAME-1035: record the raw point so the stroke can later be serialized
            // and replayed as an editable vector (see addRestoredStroke). Recorded
            // here, not inside the shape, so drawing behaviour is untouched.
            recordPoint(touchX, touchY)
        }
    }

    private fun onTouchEventMove(touchX: Float, touchY: Float) {
        currentShape?.shape?.apply {
            moveShape(touchX, touchY)
            recordPoint(touchX, touchY)
        }
    }

    private fun onTouchEventUp(touchX: Float, touchY: Float) {
        currentShape?.apply {
            shape.stopShape()
            endShape(touchX, touchY)
        }
    }

    private fun createShape() {
        var paint = createPaint()
        var shape: AbstractShape = BrushShape()

        if (isErasing) {
            paint = createEraserPaint()
        } else {
            when (val shapeType = currentShapeBuilder.shapeType) {
                ShapeType.Oval -> {
                    shape = OvalShape()
                }
                ShapeType.Brush -> {
                    shape = BrushShape()
                }
                ShapeType.Rectangle -> {
                    shape = RectangleShape()
                }
                ShapeType.Line -> {
                    shape = LineShape(context)
                }
                is ShapeType.Arrow -> {
                    shape = LineShape(context, shapeType.pointerLocation)
                }
            }
        }

        // GAME-1035: tag the shape as an eraser so a restore can rebuild its CLEAR
        // paint (a Paint's xfermode mode is not reliably readable back).
        shape.isEraser = isErasing

        currentShape = ShapeAndPaint(shape, paint)
        drawShapes.push(currentShape)
        strokeInProgress = true
        viewChangeListener?.onStartDrawing()
    }

    /**
     * GAME-1035: re-add a previously captured stroke as an EDITABLE vector shape.
     *
     * A restored draft's brush strokes come back as real stack entries -- undoable,
     * erasable, extendable, and picked up by the normal export path -- not a flat
     * raster. The recorded [points] are replayed through the same
     * startShape/moveShape/stopShape the touch handler uses, so the reconstructed
     * Path (including its TOUCH_TOLERANCE thinning) is identical to the original.
     * The paint is rebuilt from primitives exactly as createPaint/createEraserPaint
     * do. [offsetX]/[offsetY]/[canvasScaleX]/[canvasScaleY] restore a BrushShape's
     * post-crop adjustCanvas transform (identity for a stroke drawn on an uncropped
     * image); they are ignored for non-brush shapes, which have no such transform.
     */
    fun addRestoredStroke(
        points: List<PointF>,
        color: Int,
        strokeWidth: Float,
        shapeName: String,
        isEraser: Boolean,
        offsetX: Float = 0f,
        offsetY: Float = 0f,
        canvasScaleX: Float = 1f,
        canvasScaleY: Float = 1f,
    ) {
        if (points.isEmpty()) return

        val shape: AbstractShape = when (shapeName) {
            "LineShape" -> LineShape(context)
            "OvalShape" -> OvalShape()
            "RectangleShape" -> RectangleShape()
            else -> BrushShape()
        }
        shape.isEraser = isEraser

        // Rebuilt from scratch rather than createPaint() so it does not depend on
        // the current shape-builder state; mirrors createPaint()'s constants and
        // createEraserPaint()'s CLEAR xfermode. The serialized color already carries
        // its alpha, so no separate opacity step is needed.
        val paint = Paint().apply {
            isAntiAlias = true
            isDither = true
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            this.color = color
            this.strokeWidth = strokeWidth
            xfermode = PorterDuffXfermode(
                if (isEraser) PorterDuff.Mode.CLEAR else PorterDuff.Mode.SRC_OVER
            )
        }

        // Replay through the same calls a live stroke uses, recording the points
        // again so a later re-save serializes an identical stroke.
        shape.startShape(points.first().x, points.first().y)
        shape.recordPoint(points.first().x, points.first().y)
        for (i in 1 until points.size) {
            shape.moveShape(points[i].x, points[i].y)
            shape.recordPoint(points[i].x, points[i].y)
        }
        shape.stopShape()

        if (shape is BrushShape &&
            (offsetX != 0f || offsetY != 0f || canvasScaleX != 1f || canvasScaleY != 1f)
        ) {
            shape.adjustCanvas(offsetX, offsetY, canvasScaleX, canvasScaleY)
        }

        drawShapes.push(ShapeAndPaint(shape, paint))
        rebuildStrokeCache()
    }

    private fun endShape(touchX: Float, touchY: Float) {
        if (currentShape?.shape?.hasBeenTapped() == true) {
            // just a tap, this is not a shape, so remove it
            drawShapes.remove(currentShape)
            //handleTap(touchX, touchY);
        }
        // Committed: fold it into the cache before notifying anyone, so a
        // listener that reads the view mid-callback sees a consistent state.
        strokeInProgress = false
        rebuildStrokeCache()
        viewChangeListener?.apply {
            onStopDrawing()
            // Ported from upstream 8648773 ("Fix redo logic"): a new stroke starts a new branch
            // of history, same reasoning as GraphicManager.addView()'s companion fix in this
            // same commit -- a previously-undone stroke sitting on this DrawingView's OWN redo
            // stack should no longer be redoable once a new stroke has been drawn.
            if (redoShapes.isNotEmpty()) {
                redoShapes.clear()
            }
            onViewAdd(this@DrawingView)
        }
    }

    fun undo(): Boolean {
        if (!drawShapes.empty()) {
            redoShapes.push(drawShapes.pop())
            rebuildStrokeCache()
        }
        viewChangeListener?.onViewRemoved(this)
        return !drawShapes.empty()
    }

    fun redo(): Boolean {
        if (!redoShapes.empty()) {
            drawShapes.push(redoShapes.pop())
            rebuildStrokeCache()
        }
        viewChangeListener?.onViewAdd(this)
        return !redoShapes.empty()
    }

    // region eraser
    fun brushEraser() {
        isDrawingEnabled = true
        isErasing = true
    }

    // endregion
    // region Setters/Getters

    fun enableDrawing(brushDrawMode: Boolean) {
        isDrawingEnabled = brushDrawMode
        isErasing = !brushDrawMode
        if (brushDrawMode) {
            visibility = VISIBLE
        }
    }

    // endregion
    val drawingPath: Pair<Stack<ShapeAndPaint?>, Stack<ShapeAndPaint?>>
        get() = Pair(drawShapes, redoShapes)

    companion object {
        const val DEFAULT_ERASER_SIZE = 50.0f
    }

    // region constructors
    init {
        //Caution: This line is to disable hardware acceleration to make eraser feature work properly
        setLayerType(LAYER_TYPE_HARDWARE, null)
        visibility = GONE
        currentShapeBuilder = ShapeBuilder()
        setupBrushDrawing()
    }
}