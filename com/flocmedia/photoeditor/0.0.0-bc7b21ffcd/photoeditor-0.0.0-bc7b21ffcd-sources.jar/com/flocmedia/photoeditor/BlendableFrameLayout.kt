package com.flocmedia.photoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build
import android.view.View
import android.widget.FrameLayout

/**
 * The editor canvas container. Composites any child graphic that carries a
 * [GraphicBlendMode] tag against the layers already drawn beneath it (GAME-703),
 * by wrapping the child's draw in a [Canvas.saveLayer] whose paint carries the
 * blend mode.
 *
 * This one override reaches BOTH the live screen AND the `View.draw`-based export
 * (`PhotoSaverTask`), because drawChild runs in both. A blend-aware
 * [android.graphics.BlendMode] is alpha-correct, so the graphic's transparent
 * surround leaves the backdrop intact -- unlike PorterDuffXfermode, which erases
 * it. Blend is therefore API 29+ only; below that, and for NORMAL, the child is
 * drawn as-is.
 */
class BlendableFrameLayout(context: Context) : FrameLayout(context) {

    override fun drawChild(canvas: Canvas, child: View, drawingTime: Long): Boolean {
        val mode = child.getTag(R.id.blend_mode_tag) as? GraphicBlendMode
        if (mode == null || mode == GraphicBlendMode.NORMAL ||
            Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
        ) {
            return super.drawChild(canvas, child, drawingTime)
        }
        val blend = mode.toBlendMode()
            ?: return super.drawChild(canvas, child, drawingTime)

        // Whole-canvas layer is safe here: the blend is alpha-aware, so the
        // layer's transparent regions leave the backdrop untouched.
        val paint = Paint().apply { blendMode = blend }
        val count = canvas.saveLayer(null, paint)
        val result = super.drawChild(canvas, child, drawingTime)
        canvas.restoreToCount(count)
        return result
    }
}
