package com.flocmedia.photoeditor

data class TextShadow(
    var radius: Float,
    var dx: Float,
    var dy: Float,
    var color: Int
)