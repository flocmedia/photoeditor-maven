package com.flocmedia.photoeditor

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.flocmedia.photoeditor.MultiTouchListener.OnGestureControl

/**
 * Created by Burhanuddin Rashid on 14/05/21.
 *
 * @author <https:></https:>//github.com/burhanrashid52>
 */
internal abstract class Graphic(
    val context: Context,
    val layoutId: Int,
    val viewType: ViewType,
    val graphicManager: GraphicManager?) {

    val rootView: View

    open fun updateView(view: View) {
        //Optional for subclass to override
    }

    init {
        if (layoutId == 0) {
            throw UnsupportedOperationException("Layout id cannot be zero. Please define a layout")
        }
        rootView = LayoutInflater.from(context).inflate(layoutId, null)
        setupView(rootView)
        setupRemoveView(rootView)
    }


    private fun setupRemoveView(rootView: View) {
        //We are setting tag as ViewType to identify what type of the view it is
        //when we remove the view from stack i.e onRemoveViewListener(ViewType viewType, int numberOfAddedViews);
        rootView.tag = viewType
        val imgClose: ImageView? = null
        imgClose?.setOnClickListener { graphicManager?.removeView(this@Graphic) }
    }

    protected fun toggleSelection() {
        val frmBorder = rootView.findViewById<View>(R.id.frmBorder)
        val imgClose: View? = null
        if (frmBorder != null) {
            frmBorder.setBackgroundResource(R.drawable.rounded_border_tv)
            frmBorder.tag = true
        }
        if (imgClose != null) {
            imgClose.visibility = View.VISIBLE
        }
    }

    protected fun buildGestureController(
        canvasView: ViewGroup,
        viewState: PhotoEditorViewState,
        onPhotoEditorListener: OnPhotoEditorListener?
    ): OnGestureControl {
        val boxHelper = BoxHelper(canvasView, viewState)
        return object : OnGestureControl {
            override fun onClick() {
                if (viewState.currentSelectedView == rootView)
                    return

                if (viewState.currentSelectedView != null && viewState.currentSelectedView != rootView) {
                    onPhotoEditorListener?.onInFocusViewChangeListener(null)
                }

                boxHelper.clearHelperBox()
                toggleSelection()
                // Change the in-focus view
                viewState.currentSelectedView = rootView
                onPhotoEditorListener?.onInFocusViewChangeListener(
                    rootView
                )
            }

            override fun onLongClick() {
                updateView(rootView)
            }

            override fun onDown() {}
            override fun onFling() {
                if (viewState.currentSelectedView == null) {
                    boxHelper.clearHelperBox()
                    toggleSelection()

                    // Change the in-focus view
                    viewState.currentSelectedView = rootView
                    onPhotoEditorListener?.onInFocusViewChangeListener(
                        rootView
                    )
                }
            }
        }
    }

    open fun setupView(rootView: View) {}
}