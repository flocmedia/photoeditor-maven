package com.flocmedia.photoeditor

import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Which of a graphic's four corner drag handles a resize/rotate gesture is
 * driving.
 *
 * The library's public counterpart to the app-side `OnTouchHandleType` this
 * replaces (GAME-1087). The corner-resize/rotate gesture math moved into the
 * library, so the handle identity it is parameterised on moves with it.
 */
enum class CornerHandle {
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT,
}

/**
 * A corner handle's position on screen, in the same coordinate space as
 * [MultiTouchListener.centerX] / [MultiTouchListener.centerY].
 */
internal data class CornerAnchor(val x: Float, val y: Float)

/**
 * What a corner-drag ACTION_MOVE resolves to.
 *
 * The library computes the transform the finger described; the host applies it,
 * because how a resize lands is app policy (a sticker rewrites its scale, a text
 * root is re-measured about its centre, and the app records rotation telemetry).
 * So this carries the [MultiTouchListener.TransformInfo] plus exactly the three
 * scalars and the view the host's `onGraphicMove` takes.
 */
data class CornerGestureUpdate(
    val itemRootFrameView: View,
    val transformInfo: MultiTouchListener.TransformInfo,
    val editorScaleX: Float,
    val startScale: Float,
    val startRotation: Float,
)

/**
 * The corner-resize/rotate gesture, moved out of the app's `GraphicHelper`
 * (GAME-1087).
 *
 * The four corner handles are app-owned views layered over the graphic; they
 * absorb the touch stream themselves, so [MultiTouchListener.onTouch] never runs
 * for a handle drag. The app used to drive the gesture by poking fifteen raw
 * fields on the listener on ACTION_DOWN and reading them back on ACTION_MOVE.
 * That is the coupling this ticket removes: [begin] does the setup, [update]
 * does the per-frame math, and the app keeps only the touch plumbing (pointer
 * tracking, handle visibility, its own `onGraphicMove`).
 */
internal object CornerGesture {

    /**
     * Opens a corner gesture on [handle]: snapshots the graphic for history and
     * primes the transform anchors on [listener] from the finger's screen
     * position ([rawX], [rawY]).
     *
     * Opens a history entry via [MultiTouchListener.beginExternalGesture], so
     * call it only once the app has decided the gesture is real (the handle is
     * visible) -- a gesture we do not absorb must not open an entry.
     */
    fun begin(listener: MultiTouchListener, handle: CornerHandle, rawX: Float, rawY: Float) {
        val itemRoot = listener.itemRootFrameView ?: return

        listener.beginExternalGesture()

        // The entire handle object is clickable, including its transparent part,
        // to make a larger touch target.
        listener.isCornerMovable = true
        listener.isTouchMovable = false

        listener.editorScale = listener.photoEditorView.parentLayout.scaleX

        listener.centerX = (itemRoot.left + itemRoot.right) / 2f
        listener.centerY = (itemRoot.top + itemRoot.bottom) / 2f

        // Adjust width and height to the scale of the editor.
        listener.adjustedScaledHeight = itemRoot.height * listener.editorScale
        listener.adjustedScaledWidth = itemRoot.width * listener.editorScale

        val anchor = cornerAnchor(
            handle,
            listener.centerX,
            listener.centerY,
            listener.adjustedScaledWidth,
            listener.adjustedScaledHeight,
            itemRoot.scaleX,
            itemRoot.rotation + listener.canvasView.rotation,
        )
        listener.coordinateX = anchor.x
        listener.coordinateY = anchor.y

        listener.startX = rawX - listener.coordinateX + listener.centerX
        listener.startY = rawY - listener.coordinateY + listener.centerY

        listener.startR = hypot(
            (rawX - listener.startX).toDouble(),
            (rawY - listener.startY).toDouble(),
        ).toFloat()
        listener.startA = Math.toDegrees(
            atan2(
                (rawY - listener.startY).toDouble(),
                (rawX - listener.startX).toDouble(),
            )
        ).toFloat()

        listener.startScale = itemRoot.scaleX
        listener.startRotation = itemRoot.rotation
    }

    /**
     * Resolves one ACTION_MOVE of the gesture opened by [begin] to the transform
     * the finger has described at ([rawX], [rawY]). Returns null if the graphic
     * is no longer attached.
     */
    fun update(listener: MultiTouchListener, rawX: Float, rawY: Float): CornerGestureUpdate? {
        val itemRoot = listener.itemRootFrameView ?: return null

        val newRadius = hypot(
            (rawX - listener.startX).toDouble(),
            (rawY - listener.startY).toDouble(),
        ).toFloat()
        val newAngle = Math.toDegrees(
            atan2(
                (rawY - listener.startY).toDouble(),
                (rawX - listener.startX).toDouble(),
            )
        ).toFloat()
        val newDeltaScale: Float = newRadius / listener.startR

        val info = MultiTouchListener.TransformInfo()
        info.deltaScale = newDeltaScale
        // GAME-259: hold rotation through a dead zone, then engage FROM THAT POINT
        // (no jump at the threshold). A corner scales by radius; the drag angle
        // only rotates once it has travelled past the slop. See the survey in
        // docs/plans/STRETCH_HANDLES.md -- corners scale, rotation is a separate,
        // deliberate action, so a small incidental swing must not tilt the graphic.
        info.deltaAngle = applyRotationDeadZone(newAngle - listener.startA)
        info.deltaX = 0.0f
        info.deltaY = 0.0f
        info.pivotX = null
        info.pivotY = null

        return CornerGestureUpdate(
            itemRootFrameView = itemRoot,
            transformInfo = info,
            editorScaleX = listener.photoEditorView.parentLayout.scaleX,
            startScale = listener.startScale,
            startRotation = listener.startRotation,
        )
    }

    /**
     * The ACTION_UP frame (GAME-259). Resolves the finger's transform exactly as
     * [update] does -- so the scale it lands is byte-for-byte the last move frame's
     * (the release point is where the finger already was) -- then SNAPS the
     * resulting rotation to the nearest right angle when it is within
     * [ROTATION_SNAP_TOLERANCE_DEGREES]. Only [MultiTouchListener.TransformInfo.deltaAngle]
     * is rewritten; scale is untouched.
     *
     * Rewriting the delta (rather than poking the view) keeps the snap on the same
     * `onGraphicMove` seam the drag used, so the host's rotation telemetry records
     * the snapped value. The host applies this only on a real ACTION_UP, and only
     * when the gesture actually engaged rotation, so a tap or a pure-scale drag
     * never nudges a pre-existing angle.
     */
    fun updateOnRelease(listener: MultiTouchListener, rawX: Float, rawY: Float): CornerGestureUpdate? {
        val resolved = update(listener, rawX, rawY) ?: return null
        val landed = listener.startRotation + resolved.transformInfo.deltaAngle
        val snapped = snapRotationOnRelease(landed)
        resolved.transformInfo.deltaAngle = snapped - listener.startRotation
        return resolved
    }
}

/**
 * The rotation dead zone for a corner drag, in degrees (GAME-259). Rotation holds
 * at the gesture-start angle until the finger's angular travel exceeds this, then
 * engages from that point. 6deg is the touch-slop analogue; no published number
 * exists (tuned on device).
 */
internal const val ROTATION_DEAD_ZONE_DEGREES = 6f

/**
 * On release, a corner drag's rotation snaps to the nearest right angle when it
 * lands within this tolerance, in degrees (GAME-259; Microsoft "constrained on
 * release", img.ly `snapRotationTolerance`).
 */
internal const val ROTATION_SNAP_TOLERANCE_DEGREES = 5f

/**
 * Applies the rotation dead zone to a raw angular delta [rawDelta] (finger angle
 * now minus at gesture start). Within +-[deadZone] the graphic does not rotate;
 * past it, it rotates by the EXCESS only -- the dead zone is subtracted so
 * rotation engages continuously from zero, with no jump at the threshold.
 *
 * MUTATION EVIDENCE: drop the `- deadZone` / `+ deadZone` and a delta just past
 * the threshold jumps to the full delta instead of ~zero
 * (`rotationEngagesFromZeroWithNoJump`).
 */
internal fun applyRotationDeadZone(
    rawDelta: Float,
    deadZone: Float = ROTATION_DEAD_ZONE_DEGREES,
): Float = when {
    rawDelta > deadZone -> rawDelta - deadZone
    rawDelta < -deadZone -> rawDelta + deadZone
    else -> 0f
}

/**
 * Snaps a release [rotation] (degrees, in [-180, 180] as `adjustAngle` keeps it)
 * to the nearest multiple of 90 when within [tolerance]; otherwise returns it
 * unchanged (GAME-259). The nearest multiple is one of -180/-90/0/90/180, so the
 * gap is at most 45deg and there is no wrap to handle.
 */
internal fun snapRotationOnRelease(
    rotation: Float,
    tolerance: Float = ROTATION_SNAP_TOLERANCE_DEGREES,
): Float {
    val nearest = Math.round(rotation / 90f) * 90f
    return if (kotlin.math.abs(rotation - nearest) <= tolerance) nearest else rotation
}

/**
 * Where one of a graphic's four corner handles sits.
 *
 * GAME-904. This was four hand-inlined copies of the same trigonometry, and two
 * of the four were wrong in a way that only showed up after a stretch. Moved
 * into the library by GAME-1087 along with the gesture it feeds.
 *
 * The geometry: a graphic is a [scaledWidth] x [scaledHeight] rectangle, scaled
 * by [graphicScale] and rotated by [rotationDegrees] about its centre. Every
 * corner is the same distance from that centre -- half the diagonal -- and
 * differs only in angle. Writing phi = atan2(h, w) for the angle of the
 * bottom-right corner in the graphic's own unrotated frame, and theta for the
 * rotation, the four corners sit at theta+phi (bottom right), theta-phi (top
 * right), and the antipodes of each. Note that phi cancels the editor zoom baked
 * into both dimensions, so only the ASPECT RATIO reaches it.
 *
 * The bug was that top-right and bottom-left were written as
 * `(+sin(theta+phi), -cos(theta+phi))` and its negation, which is the point at
 * theta+phi-90 degrees. That equals theta-phi only when
 *
 *     theta + phi - 90 == theta - phi   <=>   phi == 45   <=>   w == h
 *
 * so the formula was correct for a SQUARE graphic and wrong for every other
 * aspect ratio. Stickers are placed square (a 412x412 root), which is why this
 * survived: the only way to make w != h is Stretch H / Stretch V, which resizes
 * via layoutParams rather than scaleX/scaleY. Top-left and bottom-right used
 * +-(theta+phi) and were right at any aspect ratio -- hence the report of
 * exactly two good corners and two bad ones.
 *
 * Getting this wrong is not a cosmetic offset. The returned point becomes
 * `coordinateX/Y`, which sets `startX/startY`, which sets `startA`; every
 * `deltaAngle` in ACTION_MOVE is measured from it. A wrong anchor means the
 * graphic spins about the wrong pivot by the wrong amount for the whole drag.
 *
 * ## Why this returns a POSITION and not an offset from the centre
 *
 * It returned an offset first, and that was measurably wrong. The old code
 * evaluated `centre - halfDiagonal * cos(...)` entirely in Double and rounded
 * once, at the end. Returning an offset rounds the offset to Float and then adds
 * it to the centre in Float -- two roundings instead of one, which disagrees
 * with the old arithmetic on 29% of inputs by up to ~0.001 px.
 *
 * A thousandth of a pixel sounds ignorable, and as a position it is. But it
 * lands in `startA`, and an 800 ms rotate-and-scale drag integrates from there:
 * an on-device A/B measured the top-left leg -- a corner this change is not
 * supposed to touch at all -- shifting 3.1-3.5% of exported pixels against a
 * 0.9% run-to-run noise floor. Taking the centre as a parameter and rounding
 * once, at the end, makes the two unchanged corners bit-identical to the code
 * they replaced, which is the entire safety argument for this refactor.
 * `theUnchangedCornersAreBitIdenticalToTheOldArithmetic` pins it.
 *
 * @param centerX the graphic's centre, in [MultiTouchListener]'s coordinates
 * @param centerY the graphic's centre, in [MultiTouchListener]'s coordinates
 * @param scaledWidth  the graphic's width in editor-scaled pixels
 * @param scaledHeight the graphic's height in editor-scaled pixels
 * @param graphicScale the graphic's own scaleX (assumed equal to scaleY, as
 *   everywhere else)
 * @param rotationDegrees the graphic's rotation plus the canvas's
 */
internal fun cornerAnchor(
    handle: CornerHandle,
    centerX: Float,
    centerY: Float,
    scaledWidth: Float,
    scaledHeight: Float,
    graphicScale: Float,
    rotationDegrees: Float,
): CornerAnchor {
    val halfDiagonal =
        hypot(scaledWidth.toDouble(), scaledHeight.toDouble()) / 2f * graphicScale
    val theta = Math.toRadians(rotationDegrees.toDouble())
    val phi = atan2(scaledHeight.toDouble(), scaledWidth.toDouble())

    val angle = when (handle) {
        CornerHandle.BOTTOM_RIGHT,
        CornerHandle.TOP_LEFT -> theta + phi
        CornerHandle.TOP_RIGHT,
        CornerHandle.BOTTOM_LEFT -> theta - phi
    }
    val sign = when (handle) {
        CornerHandle.BOTTOM_RIGHT,
        CornerHandle.TOP_RIGHT -> 1.0
        CornerHandle.TOP_LEFT,
        CornerHandle.BOTTOM_LEFT -> -1.0
    }

    // One rounding, at the end. See the note above -- rounding the offset
    // separately is not equivalent, and the difference is observable on a device.
    return CornerAnchor(
        (centerX + sign * halfDiagonal * cos(angle)).toFloat(),
        (centerY + sign * halfDiagonal * sin(angle)).toFloat(),
    )
}
