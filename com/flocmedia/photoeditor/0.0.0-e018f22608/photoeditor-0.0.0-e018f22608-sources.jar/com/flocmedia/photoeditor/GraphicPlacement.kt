package com.flocmedia.photoeditor

import android.view.View

/**
 * What a newly-added graphic's placement transform resolves to: the
 * [MultiTouchListener.TransformInfo] plus the three scalars the host's
 * `onGraphicMove` takes -- the same shape as a corner-gesture update, because
 * placement drives the same app callback.
 */
data class PlacementTransform(
    val transformInfo: MultiTouchListener.TransformInfo,
    val editorScaleX: Float,
    val startScale: Float,
    val startRotation: Float,
)

/**
 * Places a freshly-added graphic onto the canvas: its initial scale/rotation,
 * and its centre in the visible region.
 *
 * Moved out of the app's `Realigner` (GAME-1087). Like the corner gesture, the
 * app owns the touch/history callbacks (`onGraphicMove`, `onGraphicActionDown`)
 * -- those stay app policy -- and the library owns the geometry: how big a new
 * graphic starts relative to the editor zoom, how it cancels the canvas rotation
 * to land upright, and where its centre goes once it has a measured size.
 */
object GraphicPlacement {

    /**
     * The initial transform for a graphic just added to [graphicRootView]'s
     * canvas: scaled DOWN as the editor is zoomed IN (so a sticker placed at 4x
     * zoom is not enormous), and rotated to cancel the canvas rotation so it
     * lands upright. The host applies this through its `onGraphicMove`.
     */
    fun transformForNewGraphic(
        photoEditorView: PhotoEditorView,
        graphicRootView: View,
    ): PlacementTransform {
        val parentView: View = photoEditorView.parentLayout
        val canvasView: View = photoEditorView.canvasLayout

        val info = MultiTouchListener.TransformInfo()
        // Scale relative to the editor zoom, floored so it never collapses.
        info.deltaScale = Math.max(
            MINIMUM_STICKER_SCALE_STARTING_SIZE,
            1 - 1 * (parentView.scaleX - 1) / (ZoomLayout.MAX_ZOOM - 1)
        )
        // Offset the canvas rotation so the graphic is right side up.
        info.deltaAngle = -canvasView.rotation
        info.deltaX = 0.0f
        info.deltaY = 0.0f
        info.pivotX = null
        info.pivotY = null

        return PlacementTransform(
            transformInfo = info,
            editorScaleX = parentView.scaleX,
            startScale = graphicRootView.scaleX,
            startRotation = graphicRootView.rotation,
        )
    }

    /**
     * Centres [graphicRootView] in the VISIBLE region of the canvas, allowing
     * for [targetSize] (the graphic's build size) and the current zoom. Call
     * once the graphic has a non-zero measured size -- centring reads its width
     * and height, which are 0 until it has been laid out.
     *
     * The visible region matters when the editor is zoomed: `canvasLayout.width`
     * always reports the full unscaled width, so the visible width is
     * `width / scaleX`. Centring against the full width dropped the graphic at
     * the top-left of the viewport, off screen when zoomed in (GAME-347). At
     * zoom 1 this reduces exactly to `(canvasWidth - graphicWidth) / 2`, so
     * un-zoomed placement is unchanged.
     */
    fun centreInVisibleRegion(
        photoEditorView: PhotoEditorView,
        graphicRootView: View,
        targetSize: Int,
    ) {
        val parentView: View = photoEditorView.parentLayout
        val canvasView: View = photoEditorView.canvasLayout

        graphicRootView.translationX =
            -parentView.translationX / parentView.scaleX +
                targetSize / 2f * (graphicRootView.scaleX - 1)
        graphicRootView.translationY =
            -parentView.translationY / parentView.scaleY +
                targetSize / 2f * (graphicRootView.scaleY - 1)

        val visibleWidth = canvasView.width / parentView.scaleX
        val visibleHeight = canvasView.height / parentView.scaleY
        graphicRootView.translationX += (visibleWidth - graphicRootView.width) / 2
        graphicRootView.translationY += (visibleHeight - graphicRootView.height) / 2
    }

    private const val MINIMUM_STICKER_SCALE_STARTING_SIZE = 0.2f
}
