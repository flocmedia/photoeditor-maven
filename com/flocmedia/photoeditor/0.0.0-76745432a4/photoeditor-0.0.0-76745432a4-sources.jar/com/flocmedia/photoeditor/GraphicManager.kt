package com.flocmedia.photoeditor

import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.RelativeLayout

/**
 * Created by Burhanuddin Rashid on 15/05/21.
 *
 * @author <https:></https:>//github.com/burhanrashid52>
 */
internal class GraphicManager(
    private val mCanvasView: ViewGroup,
    private val mViewState: PhotoEditorViewState
) {
    var onPhotoEditorListener: OnPhotoEditorListener? = null
    fun addView(graphic: Graphic) {
        val view = graphic.rootView
        val params = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )

        // NOTE(cheng): Commenting this out since this makes it impossible to resize/move the graphic
        //              after it has been added.
        // params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        mCanvasView.addView(view, params)
        mViewState.addAddedView(view)

        // Ported from upstream 8648773 ("Fix redo logic"): a new view being added starts a new
        // branch of history, so whatever was previously undone (and sitting on the redo stack)
        // is no longer redoable -- without this, redo() after adding something new resurrects
        // the OLDER undone view instead of doing nothing, appended to the end of the added-views
        // list rather than restored to its original position.
        if (mViewState.redoViewsCount > 0) {
            mViewState.clearRedoViews()
        }

        // NOTE(fleissig): we can center the text because we already know its size
        if (graphic is Text) {
            view.x = mCanvasView.width/2f - view.width/2f
            view.y = mCanvasView.height/2f - view.height/2f
        }
        else if (graphic is Sticker) {
            view.viewTreeObserver.addOnGlobalLayoutListener(object :
                ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    val stickerDefSize = graphic.context.resources.getDimension(R.dimen.default_sticker_size)
                    view.layoutParams.width = stickerDefSize.toInt()
                    view.layoutParams.height = stickerDefSize.toInt()

                    view.requestLayout()

                    // Remove listener after being called so it doesn't loop on every change.
                    view.viewTreeObserver.removeOnGlobalLayoutListener(this)
                }
            })
        }

        onPhotoEditorListener?.onAddViewListener(
            graphic.viewType,
            mViewState.addedViewsCount
        )
    }

    fun removeView(graphic: Graphic) {
        val view = graphic.rootView
        if (mViewState.containsAddedView(view)) {
            mCanvasView.removeView(view)
            mViewState.removeAddedView(view)
            mViewState.pushRedoView(view)
            onPhotoEditorListener?.onRemoveViewListener(
                graphic.viewType,
                mViewState.addedViewsCount
            )
        }
    }

    fun updateView(view: View) {
        mCanvasView.updateViewLayout(view, view.layoutParams)
        mViewState.replaceAddedView(view)
    }

    fun undoView(): Boolean {
        if (mViewState.addedViewsCount > 0) {
            val removeView = mViewState.getAddedView(
                mViewState.addedViewsCount - 1
            )
            if (removeView is DrawingView) {
                // Ported from upstream 685c82b ("Fix return value of undo() and redo()
                // methods."): removeView.undo() alone only reports whether the DrawingView
                // itself has more strokes left to undo, ignoring whatever else remains below it
                // on the added-views stack. A sticker/text view sitting underneath a DrawingView
                // with nothing left to undo would make this wrongly report "nothing more to
                // undo" even though it is.
                return removeView.undo() || (mViewState.addedViewsCount != 0)
            } else {
                mViewState.removeAddedView(mViewState.addedViewsCount - 1)
                mCanvasView.removeView(removeView)
                mViewState.pushRedoView(removeView)
            }
            when (val viewTag = removeView.tag) {
                is ViewType -> onPhotoEditorListener?.onRemoveViewListener(
                    viewTag,
                    mViewState.addedViewsCount
                )
            }
        }
        return mViewState.addedViewsCount != 0
    }

    fun redoView(): Boolean {
        if (mViewState.redoViewsCount > 0) {
            val redoView = mViewState.getRedoView(
                mViewState.redoViewsCount - 1
            )
            if (redoView is DrawingView) {
                // Ported from upstream 8648773, same reasoning as undoView()'s DrawingView
                // branch fix (685c82b, PR "Fix undoView() ignoring what's below a DrawingView on
                // the stack"): redoView.redo() alone only reports whether the DrawingView itself
                // has more strokes left to redo, ignoring whatever else remains on the redo
                // stack below it.
                val result = redoView.redo()
                return result || (mViewState.redoViewsCount != 0)
            } else {
                mViewState.popRedoView()
                mCanvasView.addView(redoView)
                mViewState.addAddedView(redoView)
            }
            when (val viewTag = redoView.tag) {
                is ViewType -> onPhotoEditorListener?.onAddViewListener(
                    viewTag,
                    mViewState.addedViewsCount
                )
            }
        }
        return mViewState.redoViewsCount != 0
    }
}