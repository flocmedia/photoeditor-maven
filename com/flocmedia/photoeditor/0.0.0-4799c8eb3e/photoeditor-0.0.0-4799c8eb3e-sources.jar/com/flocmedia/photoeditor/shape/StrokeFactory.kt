package com.flocmedia.photoeditor.shape

import android.content.Context
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode

/**
 * Rebuilds a previously captured stroke as an editable vector [ShapeAndPaint],
 * with no [com.flocmedia.photoeditor.DrawingView] and no view hierarchy.
 *
 * ## Why this is separate from DrawingView
 *
 * `DrawingView.addRestoredStroke` has always been able to do this — its body was
 * View-independent apart from the final `drawShapes.push` / `rebuildStrokeCache`
 * — but it is an instance method on a `View`, so the only way to obtain a
 * `ShapeAndPaint` was to have a laid-out DrawingView. That is fine in the editor
 * and impossible in a headless renderer.
 *
 * The consumer is the app's durable HD-export worker (GAME-1031), a WorkManager
 * worker with no Activity. Because it could not build strokes, it could not use
 * the vector brush path at all, so the app spooled a flattened PNG for it
 * instead — and that raster's size, chosen in advance at spool time, silently
 * became the ceiling on every exported brush's resolution. Fixing the vector
 * renderer did nothing for exports, because exports never reached it
 * (thug-life GAME-1279). With this, the worker can render the same vectors the
 * editor does and resolution follows the render.
 *
 * ## Contract
 *
 * The returned shape is **identical** to the one `addRestoredStroke` produces —
 * that method now delegates here, precisely so the two cannot drift. The points
 * are replayed through the same `startShape`/`moveShape`/`stopShape` the touch
 * handler uses, so the reconstructed Path (including its TOUCH_TOLERANCE
 * thinning) matches the original, and the paint mirrors `createPaint()` /
 * `createEraserPaint()`.
 *
 * [context] is needed only by [LineShape]; every other shape ignores it. It is
 * an application Context's worth of dependency — no window, no view, no layout
 * pass — which is what makes this callable from a worker.
 */
object StrokeFactory {

    /**
     * @param points the recorded stroke path, in the coordinate space it was
     *   drawn in. Empty returns null: a stroke with no points has no geometry,
     *   and returning a degenerate shape would push an invisible entry onto a
     *   caller's undo stack.
     * @param times per-point event times parallel to [points] (GAME-1132), so a
     *   restored brush stroke re-derives its velocity taper. Empty or short is
     *   safe — missing entries record 0 and [BrushShape] falls back to constant
     *   width, which is exactly how a pre-times draft looked.
     * @param taperEnabled whether this stroke tapered by draw speed when it was
     *   drawn (GAME-1210). Per-stroke, so an old stroke keeps its look
     *   regardless of the current mode.
     * @param offsetX/offsetY/canvasScaleX/canvasScaleY a BrushShape's post-crop
     *   `adjustCanvas` transform (identity for a stroke drawn on an uncropped
     *   image). Ignored for non-brush shapes, which have no such transform.
     */
    @JvmStatic
    @JvmOverloads
    fun restore(
        context: Context,
        points: List<PointF>,
        color: Int,
        strokeWidth: Float,
        shapeName: String,
        isEraser: Boolean,
        offsetX: Float = 0f,
        offsetY: Float = 0f,
        canvasScaleX: Float = 1f,
        canvasScaleY: Float = 1f,
        times: List<Long> = emptyList(),
        taperEnabled: Boolean = true,
    ): ShapeAndPaint? {
        if (points.isEmpty()) return null

        val shape: AbstractShape = when (shapeName) {
            "LineShape" -> LineShape(context)
            "OvalShape" -> OvalShape()
            "RectangleShape" -> RectangleShape()
            else -> BrushShape()
        }
        shape.isEraser = isEraser
        (shape as? BrushShape)?.taperEnabled = taperEnabled

        // Rebuilt from scratch rather than createPaint() so it does not depend on
        // the current shape-builder state; mirrors createPaint()'s constants and
        // createEraserPaint()'s CLEAR xfermode. The serialized color already
        // carries its alpha, so no separate opacity step is needed.
        val paint = Paint().apply {
            isAntiAlias = true
            isDither = true
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            this.color = color
            this.strokeWidth = strokeWidth
            xfermode = PorterDuffXfermode(
                if (isEraser) PorterDuff.Mode.CLEAR else PorterDuff.Mode.SRC_OVER
            )
        }

        // Replay through the same calls a live stroke uses, recording the points
        // again so a later re-save serializes an identical stroke.
        shape.startShape(points.first().x, points.first().y)
        shape.recordPoint(points.first().x, points.first().y, times.getOrElse(0) { 0L })
        for (i in 1 until points.size) {
            shape.moveShape(points[i].x, points[i].y)
            shape.recordPoint(points[i].x, points[i].y, times.getOrElse(i) { 0L })
        }
        shape.stopShape()

        if (shape is BrushShape &&
            (offsetX != 0f || offsetY != 0f || canvasScaleX != 1f || canvasScaleY != 1f)
        ) {
            shape.adjustCanvas(offsetX, offsetY, canvasScaleX, canvasScaleY)
        }

        return ShapeAndPaint(shape, paint)
    }
}
