package com.flocmedia.photoeditor.shape

import android.graphics.Color
import androidx.annotation.ColorInt

/**
 *
 *
 * Used to hold a Shape parameters: type, size, opacity and color.
 *
 */
class ShapeBuilder {

    var shapeType: ShapeType = ShapeType.Brush
        private set

    var shapeSize: Float = DEFAULT_SHAPE_SIZE
        private set

    @androidx.annotation.IntRange(from = 0, to = 255)
    var shapeOpacity: Int? = DEFAULT_SHAPE_OPACITY
        private set

    @get:ColorInt
    @ColorInt
    var shapeColor: Int = DEFAULT_SHAPE_COLOR
        private set

    /**
     * GAME-1210: whether a freehand brush stroke tapers by draw speed
     * (GAME-1132). True = the velocity taper; false = a uniform pen. Carried on
     * the builder like the other brush parameters so the app can flip it via
     * PhotoEditor.brushTaperEnabled, and DrawingView stamps it onto each new
     * BrushShape. No effect on the eraser or the geometric shapes.
     */
    var taperEnabled: Boolean = DEFAULT_TAPER_ENABLED
        private set

    fun withShapeType(shapeType: ShapeType): ShapeBuilder {
        this.shapeType = shapeType
        return this
    }

    fun withShapeSize(size: Float): ShapeBuilder {
        shapeSize = size
        return this
    }

    fun withShapeOpacity(
        @androidx.annotation.IntRange(
            from = 0,
            to = 255
        ) opacity: Int?
    ): ShapeBuilder {
        shapeOpacity = opacity
        return this
    }

    fun withShapeColor(@ColorInt color: Int): ShapeBuilder {
        shapeColor = color
        return this
    }

    fun withTaperEnabled(enabled: Boolean): ShapeBuilder {
        taperEnabled = enabled
        return this
    }

    companion object {
        const val DEFAULT_SHAPE_SIZE = 25.0f
        const val DEFAULT_SHAPE_OPACITY = 255
        const val DEFAULT_SHAPE_COLOR = Color.BLACK
        const val DEFAULT_TAPER_ENABLED = true
    }

    init {
        // default values
        withShapeType(ShapeType.Brush)
        withShapeSize(DEFAULT_SHAPE_SIZE)
        withShapeOpacity(DEFAULT_SHAPE_OPACITY)
        withShapeColor(DEFAULT_SHAPE_COLOR)
        withTaperEnabled(DEFAULT_TAPER_ENABLED)
    }
}