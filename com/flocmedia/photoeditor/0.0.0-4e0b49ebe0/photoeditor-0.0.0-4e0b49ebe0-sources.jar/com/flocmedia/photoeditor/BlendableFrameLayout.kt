package com.flocmedia.photoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout

/**
 * Wraps the immediate parent of a graphic's CONTENT view (the sticker image or
 * the text). Composites any child carrying a [GraphicBlendMode] tag against the
 * layers already drawn beneath it (GAME-703) by wrapping the child's draw in a
 * [Canvas.saveLayer] whose paint carries the blend mode.
 *
 * It wraps only the content -- not the graphic root -- so a blended graphic does
 * NOT blend its selection border or resize handles (those are drawn outside this
 * layer). The content still composites against the photo, because this layer's
 * ancestors do not isolate: by the time the content draws, the canvas already
 * holds the photo.
 *
 * This one override reaches BOTH the live screen AND the `View.draw`-based export
 * (`PhotoSaverTask`), because drawChild runs in both. A blend-aware
 * [android.graphics.BlendMode] is alpha-correct, so the content's transparent
 * surround leaves the backdrop intact -- unlike PorterDuffXfermode, which erases
 * it. Blend is therefore API 29+ only; below that, and for NORMAL, the child is
 * drawn as-is.
 */
class BlendableFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    override fun drawChild(canvas: Canvas, child: View, drawingTime: Long): Boolean {
        val mode = child.getTag(R.id.blend_mode_tag) as? GraphicBlendMode
        if (mode == null || mode == GraphicBlendMode.NORMAL ||
            Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
        ) {
            return super.drawChild(canvas, child, drawingTime)
        }
        val blend = mode.toBlendMode()
            ?: return super.drawChild(canvas, child, drawingTime)

        // Whole-canvas layer is safe here: the blend is alpha-aware, so the
        // layer's transparent regions leave the backdrop untouched.
        val paint = Paint().apply { blendMode = blend }
        val count = canvas.saveLayer(null, paint)
        val result = super.drawChild(canvas, child, drawingTime)
        canvas.restoreToCount(count)
        return result
    }
}
