package com.flocmedia.photoeditor

import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * Created by Burhanuddin Rashid on 14/05/21.
 *
 * @author <https:></https:>//github.com/burhanrashid52>
 */
internal class Emoji(
    private val mPhotoEditorView: PhotoEditorView,
    private val mCanvasView: ViewGroup,
    private val mMultiTouchListener: MultiTouchListener,
    private val mViewState: PhotoEditorViewState,
    private val mOnPhotoEditorListener: OnPhotoEditorListener,
    graphicManager: GraphicManager?,
    private val mDefaultEmojiTypeface: Typeface?
) : Graphic(
    context = mPhotoEditorView.context,
    graphicManager = graphicManager,
    viewType = ViewType.EMOJI,
    layoutId = R.layout.view_photo_editor_text
) {
    private var txtEmoji: TextView? = null
    fun buildView(emojiTypeface: Typeface?, emojiName: String?) {
        txtEmoji?.apply {
            if (emojiTypeface != null) {
                typeface = emojiTypeface
            }
            textSize = 56f
            text = emojiName
        }
    }

    private fun setupGesture() {
        val onGestureControl = buildGestureController(
            mCanvasView,
            mViewState,
            mOnPhotoEditorListener
        )
        mMultiTouchListener.setOnGestureControl(onGestureControl)
        val rootView = rootView
        rootView.setOnTouchListener(mMultiTouchListener)
    }

    override fun setupView(rootView: View) {
        txtEmoji = rootView.findViewById(R.id.tvPhotoEditorText)
        txtEmoji?.run {
            if (mDefaultEmojiTypeface != null) {
                typeface = mDefaultEmojiTypeface
            }
            gravity = Gravity.CENTER
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)

            // Emoji share the text item's layout, so this really is an
            // OutlinedTextView -- but an emoji must never be outlined. That is
            // already true from the default and from the fact that nothing in
            // the emoji path asks for an outline; this line is here so the
            // requirement is stated where someone would otherwise break it, and
            // so it survives a change to the default.
            (this as? OutlinedTextView)?.isTextOutlineEnabled = false
        }
    }

    init {
        setupGesture()
    }
}