package com.flocmedia.photoeditor

import android.content.res.Resources

/**
 * The numbers behind GAME-702 snapping, in one place (mirroring how
 * [TextOutlines] centralises the outline numbers): how close a feature must be
 * to snap, and how the guide line looks. Density-scaled so they mean the same
 * thing on every screen.
 */
object SnapGuides {

    /** A feature within this many dp of a line snaps to it. */
    private const val THRESHOLD_DP = 8f

    /** Guide line thickness. */
    private const val STROKE_DP = 1.5f

    fun thresholdPx(resources: Resources): Float =
        THRESHOLD_DP * resources.displayMetrics.density

    fun strokeWidthPx(resources: Resources): Float =
        STROKE_DP * resources.displayMetrics.density
}
