package com.flocmedia.photoeditor

import android.graphics.BlendMode
import android.os.Build
import androidx.annotation.RequiresApi

/**
 * The blend modes a text/sticker graphic can composite with against the layers
 * beneath it (GAME-703). NORMAL is the default (opaque draw, no blend).
 *
 * Backed by [android.graphics.BlendMode], which is API 29+. There is no
 * alpha-aware equivalent below 29 -- PorterDuffXfermode is *modulate* and erases
 * the backdrop under a graphic's transparent surround (spike-confirmed) -- so
 * blending is a 29+ feature and simply does nothing on older devices. Use
 * [isSupported] to gate the UI.
 */
enum class GraphicBlendMode {
    NORMAL, MULTIPLY, SCREEN, OVERLAY, DARKEN, LIGHTEN, ADD;

    /** The platform blend, or null for NORMAL (draw as-is). API 29+ only. */
    @RequiresApi(Build.VERSION_CODES.Q)
    fun toBlendMode(): BlendMode? = when (this) {
        NORMAL -> null
        MULTIPLY -> BlendMode.MULTIPLY
        SCREEN -> BlendMode.SCREEN
        OVERLAY -> BlendMode.OVERLAY
        DARKEN -> BlendMode.DARKEN
        LIGHTEN -> BlendMode.LIGHTEN
        ADD -> BlendMode.PLUS
    }

    companion object {
        /** True where per-graphic blending can actually be applied. */
        fun isSupported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

        /** Safe parse from a persisted ordinal; out-of-range decodes to NORMAL. */
        fun fromOrdinal(ordinal: Int): GraphicBlendMode =
            values().getOrElse(ordinal) { NORMAL }
    }
}
