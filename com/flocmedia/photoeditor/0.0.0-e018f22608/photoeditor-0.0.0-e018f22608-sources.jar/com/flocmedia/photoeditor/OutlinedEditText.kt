package com.flocmedia.photoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText

/**
 * The text-entry field in the add/edit text dialog, drawing the same glyph
 * outline the placed graphic will have.
 *
 * This exists because the preview is an [android.widget.EditText] and the thing
 * it is previewing is a `TextView` inside the photo editor library, so they
 * cannot be the same class. Every number that decides what the outline LOOKS
 * like is taken from the library's [TextOutlines] rather than restated here --
 * the stroke width, the contrast rule, the reserved inset. A preview that
 * computes its own would drift from the real thing silently, and the user would
 * only find out after tapping Done.
 *
 * See `OutlinedTextView` in the library for the shared mechanics; the notes
 * there on why the text colour is swapped rather than the paint colour, and on
 * why self-invalidation has to be suppressed, apply here identically.
 */
class OutlinedEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = androidx.appcompat.R.attr.editTextStyle,
) : AppCompatEditText(context, attrs, defStyleAttr) {

    var isTextOutlineEnabled: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            requestLayout()
            invalidate()
        }

    private var isDrawingOutline = false

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        syncOutlinePadding()
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    private fun syncOutlinePadding() {
        // GAME-786: insetPx(paint), not insetPx(textSize). The stroke this field
        // draws goes through GlyphOutlinePainter, which now sizes it against the
        // TYPEFACE -- so padding computed from the text size alone would reserve
        // for the older, thicker outline and the preview would stop matching the
        // canvas. Which is the one thing TextOutlines exists to prevent.
        val inset = if (isTextOutlineEnabled) TextOutlines.insetPx(paint) else 0
        if (inset != paddingLeft || inset != paddingTop ||
            inset != paddingRight || inset != paddingBottom
        ) {
            setPadding(inset, inset, inset, inset)
        }
    }

    /**
     * The colour this field will stroke with, for its current text colour.
     *
     * Mirrors `OutlinedTextView.resolveOutlineColour` and must give the same
     * answer for the same input -- it is the whole reason the rule lives in
     * [TextOutlines] rather than in either view. Public for the same reason it
     * is public there: the colour otherwise only ever reaches a canvas, so
     * nothing can check the rule without a rendered frame.
     */
    fun resolveOutlineColour(): Int =
        TextOutlines.contrastingOutlineColour(currentTextColor)

    override fun onDraw(canvas: Canvas) {
        if (!isTextOutlineEnabled || length() == 0) {
            super.onDraw(canvas)
            return
        }

        val outlineColour = resolveOutlineColour()

        // An EditText paints its selection highlight from a SEPARATE paint,
        // which the stroke/fill split does not touch -- so a two-pass draw
        // paints the highlight twice, and two coats of a translucent colour
        // read as a darker one. Only the fill pass needs it.
        val savedHighlight = highlightColor

        isDrawingOutline = true
        try {
            val saved = GlyphOutlinePainter.beginStrokePass(this, outlineColour)
            try {
                highlightColor = Color.TRANSPARENT
                super.onDraw(canvas)

                GlyphOutlinePainter.switchToFillPass(this, saved)
                highlightColor = savedHighlight
                super.onDraw(canvas)
            } finally {
                GlyphOutlinePainter.restore(this, saved)
                highlightColor = savedHighlight
            }
        } finally {
            isDrawingOutline = false
        }

        // The caret is drawn twice as well. Left alone deliberately: it is a
        // Drawable rather than something the paint style reaches, so both
        // copies land in the same place with the same opaque pixels and are
        // indistinguishable from one. Hiding it for the stroke pass would mean
        // toggling cursor visibility from inside onDraw, which disturbs the
        // blink scheduling in Editor -- a real bug traded for an invisible one.
    }

    override fun invalidate() {
        if (!isDrawingOutline) super.invalidate()
    }

    override fun invalidate(dirty: Rect) {
        if (!isDrawingOutline) super.invalidate(dirty)
    }

    override fun invalidate(l: Int, t: Int, r: Int, b: Int) {
        if (!isDrawingOutline) super.invalidate(l, t, r, b)
    }

    override fun postInvalidate() {
        if (!isDrawingOutline) super.postInvalidate()
    }

    override fun postInvalidate(left: Int, top: Int, right: Int, bottom: Int) {
        if (!isDrawingOutline) super.postInvalidate(left, top, right, bottom)
    }
}
