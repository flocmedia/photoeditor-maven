package com.flocmedia.photoeditor

import android.graphics.Color
import androidx.annotation.ColorInt
import androidx.core.graphics.ColorUtils
import kotlin.math.ceil

/**
 * The rules that define what a text glyph outline looks like: how thick it is,
 * what colour it takes, and how much room it needs.
 *
 * This is deliberately the ONLY place those three numbers exist. The library
 * draws the outline on the canvas, and the consuming app draws the same outline
 * in its own text-entry preview -- two different view classes in two different
 * repositories. If either one hard-codes a stroke width or a colour rule, the
 * preview starts lying about what the user will get, and nothing fails to
 * compile when it drifts.
 */
object TextOutlines {

    /**
     * Stroke width as a fraction of the text size, NOT an absolute pixel value.
     *
     * This is load-bearing. The editor resizes text by writing `textSize`
     * (see the pinch handler and the post-crop fixup in the consuming app),
     * never by scaling the view, so a textSize-relative stroke scales exactly
     * with the glyphs for free -- through pinch-resize, through a crop
     * round-trip, and through an undo that restores an older size. An absolute
     * width would look correct at one size and wrong at every other.
     *
     * 1/12 is a compromise: thin enough to leave the counters (the enclosed
     * holes in `e`, `a`, `o`) open on the heavier display faces, thick enough
     * to read against a busy photo. Counter fill-in is scale-invariant -- it is
     * a property of the typeface, not of the size -- so if a font ever needs
     * relief, this constant is the dial.
     */
    const val STROKE_FRACTION = 1f / 12f

    /**
     * The relative-luminance value at which black and white are equally
     * readable against the text colour.
     *
     * Solving `(L + 0.05) / 0.05 == 1.05 / (L + 0.05)` for the WCAG contrast
     * ratio gives `L = sqrt(1.05 * 0.05) - 0.05`. Picking black above it and
     * white below it therefore always chooses the higher-contrast option, by
     * construction -- it is arithmetic, not taste.
     *
     * The intuitive 0.5 is meaningfully worse and not just different: against
     * the editor's orange swatch (#FF861F, L = 0.384) a 0.5 threshold picks
     * white at a contrast ratio of 2.4 where black scores 8.7.
     */
    const val LUMINANCE_THRESHOLD = 0.1791287847477920

    /**
     * Black or white, whichever contrasts more with [textColour].
     *
     * Alpha is ignored, matching [ColorUtils.calculateLuminance].
     */
    @ColorInt
    fun contrastingOutlineColour(@ColorInt textColour: Int): Int =
        if (ColorUtils.calculateLuminance(textColour) > LUMINANCE_THRESHOLD) Color.BLACK else Color.WHITE

    /** Stroke width, in pixels, for text drawn at [textSizePx]. */
    fun strokeWidthPx(textSizePx: Float): Float =
        if (textSizePx <= 0f) 0f else textSizePx * STROKE_FRACTION

    /**
     * Padding, in pixels, that a view must reserve on every side so a stroke at
     * [textSizePx] is not clipped.
     *
     * A centred stroke straddles the glyph path, so only half of it lies
     * outside -- hence the /2. The extra pixel absorbs round-join overshoot at
     * sharp corners and float-to-int truncation; it is cheaper than a clipped
     * outline, which is the failure this exists to prevent.
     */
    fun insetPx(textSizePx: Float): Int =
        if (textSizePx <= 0f) 0 else ceil(strokeWidthPx(textSizePx) / 2f).toInt() + 1
}
