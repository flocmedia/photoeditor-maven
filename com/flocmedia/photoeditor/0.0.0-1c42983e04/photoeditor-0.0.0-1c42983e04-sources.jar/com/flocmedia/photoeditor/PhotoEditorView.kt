package com.flocmedia.photoeditor

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.util.AttributeSet
import android.util.Log
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RelativeLayout
import com.flocmedia.photoeditor.FilterImageView.OnImageChangedListener

/**
 *
 *
 * This ViewGroup will have the [DrawingView] to draw paint on it with [ImageView]
 * which our source image
 *
 *
 * @author [Burhanuddin Rashid](https://github.com/burhanrashid52)
 * @version 0.1.1
 * @since 1/18/2018
 */
class PhotoEditorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : ZoomLayout(context, attrs, defStyle) {
    private var mImgSource: FilterImageView = FilterImageView(context)
    var drawingView: DrawingView
        private set
    private var mImageFilterView: ImageFilterView
    private var clipSourceImage = false

    /**
     * Overlay view which you want to edit
     * NOTE(kleyow): This is custom added code diverging from https://github.com/burhanrashid52/PhotoEditor
     *
     * @return source ImageView
     */
    var imageOverlayView: ImageView
        private set

    /**
     * Background view which you want to edit
     * NOTE(kleyow): This is custom added code diverging from https://github.com/burhanrashid52/PhotoEditor
     *
     * @return source ImageView
     */
    var backgroundView: ImageView
        private set

    /**
     * Parent layout which holds all sub views
     * NOTE(kleyow): This is custom added code diverging from https://github.com/burhanrashid52/PhotoEditor
     *
     * @return source RelativeLayout
     */
    lateinit var parentLayout: RelativeLayout
        private set
    lateinit var canvasLayout: FrameLayout
        private set

    /**
     * The transient snapping guide lines drawn during a drag (GAME-702). Sits on
     * top of the canvas; empty except while a snap is active.
     */
    lateinit var alignmentGuideOverlay: AlignmentGuideOverlay
        private set

    /** Whether drag-time snapping/guides are active. Configurable per img.ly. */
    var isSnappingEnabled: Boolean = true

    init {
        //Setup image attributes
        val sourceParam = setupImageSource(attrs)
        //Setup GLSurface attributes
        mImageFilterView = ImageFilterView(context)
        val filterParam = setupFilterView()

        mImgSource.setOnImageChangedListener(object : OnImageChangedListener {
            override fun onBitmapLoaded(sourceBitmap: Bitmap?) {
                mImageFilterView.setFilterEffect(PhotoFilter.NONE)
                mImageFilterView.setSourceBitmap(sourceBitmap)
                Log.d(TAG, "onBitmapLoaded() called with: sourceBitmap = [$sourceBitmap]")

                if (sourceBitmap != null && parentLayout.width > 0 && parentLayout.height > 0) {
                    val imageWidth = sourceBitmap.width
                    val imageHeight = sourceBitmap.height
                    val parentWidth = parentLayout.width
                    val parentHeight = parentLayout.height

                    val parentAspectRatio = parentWidth / parentHeight.toFloat()
                    val imageAspectRatio = imageWidth / imageHeight.toFloat()

                    val canvasImageWidth: Int
                    val canvasImageHeight: Int

                    if (parentAspectRatio < imageAspectRatio) {
                        canvasImageWidth = parentWidth
                        canvasImageHeight = parentWidth * imageHeight / imageWidth
                    } else {
                        canvasImageWidth = parentHeight * imageWidth / imageHeight
                        canvasImageHeight = parentHeight
                    }

                    canvasLayout.layoutParams.width = canvasImageWidth
                    canvasLayout.layoutParams.height = canvasImageHeight
                }
            }
        })

        //Setup drawing view
        drawingView = DrawingView(context)
        val brushParam = setupDrawingView()

        // NOTE(kleyow): This is custom added code diverging from https://github.com/burhanrashid52/PhotoEditor
        imageOverlayView = ImageView(context)
        imageOverlayView!!.id = imgOverlayId
        val imgOverlayParam = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )

        // NOTE(kleyow): This is custom added code diverging from https://github.com/burhanrashid52/PhotoEditor
        // TODO(kleyow): Need to add logic to handle when the image is square.
        backgroundView = ImageView(context)
        backgroundView!!.scaleType = ImageView.ScaleType.FIT_XY
        backgroundView!!.id = imgBackgroundId
        val imgBackgroundParam = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )

        // NOTE(kleyow): Order of addition of views is important.
        // Add background view
        canvasLayout!!.addView(backgroundView, imgBackgroundParam)

        //Add image source
        canvasLayout!!.addView(mImgSource, sourceParam)

        //Add Gl FilterView
        canvasLayout!!.addView(mImageFilterView, filterParam)

        //Add brush view
        canvasLayout!!.addView(drawingView, brushParam)
        val canvasParam = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        canvasParam.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE)
        parentLayout.addView(canvasLayout, canvasParam)

        // Add overlay view
        canvasLayout.addView(imageOverlayView, imgOverlayParam)

        // Snapping guide overlay, on TOP of everything so its lines are visible
        // over graphics; empty except during a snap drag (GAME-702).
        alignmentGuideOverlay = AlignmentGuideOverlay(context)
        val guideParam = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        canvasLayout.addView(alignmentGuideOverlay, guideParam)
    }

    @SuppressLint("Recycle")
    private fun setupImageSource(attrs: AttributeSet?): RelativeLayout.LayoutParams {
        mImgSource.id = imgSrcId
        mImgSource.adjustViewBounds = true
        mImgSource.scaleType = ImageView.ScaleType.FIT_CENTER

        val imgSrcParam = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        imgSrcParam.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE)

        attrs?.let {
            val a = context.obtainStyledAttributes(it, R.styleable.PhotoEditorView)
            val imgSrcDrawable = a.getDrawable(R.styleable.PhotoEditorView_photo_src)
            if (imgSrcDrawable != null) {
                mImgSource.setImageDrawable(imgSrcDrawable)
            }
        }

        var widthParam = ViewGroup.LayoutParams.MATCH_PARENT
        if (clipSourceImage) {
            widthParam = ViewGroup.LayoutParams.WRAP_CONTENT
        }
        val params = RelativeLayout.LayoutParams(
            widthParam, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE)
        return params
    }

    private fun setupDrawingView(): RelativeLayout.LayoutParams {
        drawingView.visibility = GONE
        drawingView.id = shapeSrcId

        // Align drawing view to the size of image view
        val params = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE)
        params.addRule(RelativeLayout.ALIGN_TOP, imgSrcId)
        params.addRule(RelativeLayout.ALIGN_BOTTOM, imgSrcId)
        params.addRule(RelativeLayout.ALIGN_LEFT, imgSrcId)
        params.addRule(RelativeLayout.ALIGN_RIGHT, imgSrcId)
        return params
    }

    private fun setupFilterView(): RelativeLayout.LayoutParams {
        mImageFilterView.visibility = GONE
        mImageFilterView.id = glFilterId

        //Align brush to the size of image view
        val params = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE)
        params.addRule(RelativeLayout.ALIGN_TOP, imgSrcId)
        params.addRule(RelativeLayout.ALIGN_BOTTOM, imgSrcId)

        // NOTE(kleyow): This is custom added code diverging from https://github.com/burhanrashid52/PhotoEditor
        // NOTE(lucianocheng): This should be renamed from 'parent'
        parentLayout = RelativeLayout(context)
        parentLayout!!.id = parentLayoutId
        val parentLayoutParam = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )

        // `ZoomLayout` must have only one child, so this will be the container for all sub-views.
        // NOTE(cheng): This should be moved out of this method
        addView(parentLayout, parentLayoutParam)

        // NOTE(kleyow): Seperate the view into layers so functionality is not fighting over a
        //               view's pivot. Better seperation of layouts here could be an improvement.
        // NOTE(cheng): This should be moved out of this method
        canvasLayout = FrameLayout(context)
        canvasLayout!!.id = canvasLayoutId
        val rotateLayoutParam = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        return params
    }

    /**
     * Source image which you want to edit
     *
     * @return source ImageView
     */
    val source: ImageView
        get() = mImgSource

    fun resetSourceImageSettings() {
        // NOTE(kleyow): Need to reset image after changing the main image because Zooming changes
        //               the settings.
        mImgSource!!.adjustViewBounds = true
        mImgSource!!.scaleType = ImageView.ScaleType.FIT_CENTER
    }

    suspend fun saveFilter(): Bitmap {
        return if (mImageFilterView.visibility == VISIBLE) {
            val saveBitmap = try {
                mImageFilterView.saveBitmap()
            } catch (t: Throwable) {
                throw RuntimeException("Couldn't save bitmap with filter", t)
            }
            mImgSource.setImageBitmap(saveBitmap)
            mImageFilterView.visibility = GONE
            saveBitmap
        } else {
            mImgSource.bitmap!!
        }
    }

    fun setFilterEffect(filterType: PhotoFilter) {
        mImageFilterView.visibility = VISIBLE
        // Ported from upstream 93ef943 ("[ISSUES-522] Fix leak memory while filtering"): the
        // source bitmap is already set once when the view loads (see setImageSource above) --
        // re-setting it on every filter change leaked the previous GL texture/bitmap reference.
        mImageFilterView.setFilterEffect(filterType)
    }

    fun setFilterEffect(customEffect: CustomEffect?) {
        mImageFilterView.visibility = VISIBLE
        mImageFilterView.setFilterEffect(customEffect)
    }

    fun setClipSourceImage(clip: Boolean) {
        clipSourceImage = clip
        val param = setupImageSource(null)
        mImgSource.layoutParams = param
    } // endregion

    companion object {
        private const val TAG = "PhotoEditorView"
        private const val imgSrcId = 1
        private const val shapeSrcId = 2
        private const val glFilterId = 3
        private const val imgOverlayId = 4
        private const val imgBackgroundId = 5
        private const val parentLayoutId = 6
        private const val canvasLayoutId = 7
    }
}