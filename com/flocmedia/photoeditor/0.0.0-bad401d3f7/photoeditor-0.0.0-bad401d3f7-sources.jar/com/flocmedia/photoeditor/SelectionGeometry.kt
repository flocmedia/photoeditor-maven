package com.flocmedia.photoeditor

import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * GAME-840: where a selected graphic's chrome (frame + handles) sits ON SCREEN, so it can
 * be drawn by one overlay that is never transformed, at a constant size in dp at every
 * canvas zoom and every sticker scale.
 *
 * Pure and Android-free (apart from [ViewXform.of], the one reader of a live View), so
 * every geometry decision is a JVM test with mutation evidence -- the ticket's rule for
 * the most dangerous editor change of the year.
 *
 * THE CHAIN. A point on a graphic's artwork reaches the editor's coordinates through
 * every view between them: frmBorder -> graphic root -> canvasLayout (which carries the
 * photo's `rotateImage`) -> parentLayout (the canvas zoom, pivot 0,0). Each view maps its
 * local point into its parent exactly as Android's RenderNode does:
 *
 *   M = T(translation) · R(rotation, about pivot) · S(scale, about pivot)
 *   p_parent = M · p + (left − parent.scrollX, top − parent.scrollY)
 *
 * The artwork rect is a LAYOUT rect in frmBorder's coordinates -- deliberately not the
 * image view's own transform: a flip is `rotationY = 180` on the image view itself
 * (GAME-1040), and a flip must not move or relabel the handles, exactly as the in-view
 * handles (siblings of the image, unflipped) never moved.
 *
 * THE GAME-763 RULE. If any view in the chain is not laid out (width or height 0) or not
 * VISIBLE -- a freshly placed sticker is GONE until Glide decodes -- there is no quad and
 * the overlay draws nothing. Something missing is recoverable; something drawn in the
 * wrong place is a bug report.
 */
object SelectionGeometry {

    /**
     * Maps the four corners of the artwork rect ([artLeft],[artTop])–([artRight],[artBottom]),
     * given in the coordinates of the FIRST view of [chain], through every view of [chain]
     * (innermost first), into the coordinates of the last view's parent.
     *
     * @return the quad, or null under the GAME-763 rule (any view not laid out / not visible,
     *   an empty artwork rect, or a view carrying a 3D rotation this 2D map cannot represent).
     */
    fun artQuad(
        artLeft: Float,
        artTop: Float,
        artRight: Float,
        artBottom: Float,
        chain: List<ViewXform>,
    ): Quad? {
        if (chain.isEmpty()) return null
        if (artRight <= artLeft || artBottom <= artTop) return null
        if (chain.any { !it.isDrawable }) return null
        return Quad(
            topLeft = map(chain, artLeft, artTop),
            topRight = map(chain, artRight, artTop),
            bottomRight = map(chain, artRight, artBottom),
            bottomLeft = map(chain, artLeft, artBottom),
        )
    }

    /** One local point through the whole chain, innermost view first. */
    fun map(chain: List<ViewXform>, x: Float, y: Float): Pt {
        var px = x.toDouble()
        var py = y.toDouble()
        for (v in chain) {
            // S about the pivot.
            var dx = (px - v.pivotX) * v.scaleX
            var dy = (py - v.pivotY) * v.scaleY
            // R about the pivot (clockwise-positive in screen space, as View.rotation is).
            if (v.rotation != 0f) {
                val r = Math.toRadians(v.rotation.toDouble())
                val c = Math.cos(r)
                val s = Math.sin(r)
                val rx = dx * c - dy * s
                val ry = dx * s + dy * c
                dx = rx
                dy = ry
            }
            // T(translation), then the layout offset into the parent.
            px = dx + v.pivotX + v.translationX + v.left - v.parentScrollX
            py = dy + v.pivotY + v.translationY + v.top - v.parentScrollY
        }
        return Pt(px.toFloat(), py.toFloat())
    }

    /**
     * The chrome for [quad]: a frame [outsetPx] outside the artwork on every side (constant on
     * screen, whatever the zoom or sticker scale), and a handle centred on each of the frame's
     * corners and -- when [withEdges] -- its edge midpoints.
     *
     * The outset follows the quad's own axes, so it stays [outsetPx] under rotation and under
     * a mirrored chain; handles are placed from the quad's labelled corners, never re-sorted,
     * so TOP_LEFT is always the corner the in-view TOP_LEFT handle sat at.
     */
    fun chrome(quad: Quad, outsetPx: Float, withEdges: Boolean): Chrome {
        val ux = unit(quad.topRight.x - quad.topLeft.x, quad.topRight.y - quad.topLeft.y)
        val uy = unit(quad.bottomLeft.x - quad.topLeft.x, quad.bottomLeft.y - quad.topLeft.y)
        val o = outsetPx
        val tl = quad.topLeft.plus(-o * ux.x - o * uy.x, -o * ux.y - o * uy.y)
        val tr = quad.topRight.plus(o * ux.x - o * uy.x, o * ux.y - o * uy.y)
        val br = quad.bottomRight.plus(o * ux.x + o * uy.x, o * ux.y + o * uy.y)
        val bl = quad.bottomLeft.plus(-o * ux.x + o * uy.x, -o * ux.y + o * uy.y)
        val frame = Quad(tl, tr, br, bl)

        val handles = LinkedHashMap<SelectionHandle, Pt>()
        handles[SelectionHandle.TOP_LEFT] = tl
        handles[SelectionHandle.TOP_RIGHT] = tr
        handles[SelectionHandle.BOTTOM_RIGHT] = br
        handles[SelectionHandle.BOTTOM_LEFT] = bl
        if (withEdges) {
            handles[SelectionHandle.TOP] = mid(tl, tr)
            handles[SelectionHandle.RIGHT] = mid(tr, br)
            handles[SelectionHandle.BOTTOM] = mid(bl, br)
            handles[SelectionHandle.LEFT] = mid(tl, bl)
        }
        val angle = Math.toDegrees(atan2(ux.y.toDouble(), ux.x.toDouble())).toFloat()
        return Chrome(frame, handles, angle, ux, uy)
    }

    /**
     * Which handle a touch at ([x],[y]) grabs, or null for "not a handle -- let the canvas have
     * it". Each handle's touch target is a [targetPx] square centred on it and aligned with the
     * graphic's own axes (the drawn disc is smaller: the uCrop / GAME-1258 split between drawn
     * size and touch size). Only [visible] handles can be hit. Overlapping targets (a tiny
     * sticker) resolve to the NEAREST centre; an exact tie goes to the handle listed first in
     * [Chrome.handles] -- corners before edges -- so the answer never depends on hash order.
     */
    fun hitTest(
        chrome: Chrome,
        x: Float,
        y: Float,
        targetPx: Float,
        visible: Set<SelectionHandle>,
    ): SelectionHandle? {
        val half = targetPx / 2f
        var best: SelectionHandle? = null
        var bestD2 = Float.MAX_VALUE
        for ((handle, c) in chrome.handles) {
            if (handle !in visible) continue
            val dx = x - c.x
            val dy = y - c.y
            val along = dx * chrome.axisX.x + dy * chrome.axisX.y
            val across = dx * chrome.axisY.x + dy * chrome.axisY.y
            if (abs(along) > half || abs(across) > half) continue
            val d2 = dx * dx + dy * dy
            if (d2 < bestD2) {
                bestD2 = d2
                best = handle
            }
        }
        return best
    }

    private fun unit(x: Float, y: Float): Pt {
        val len = hypot(x.toDouble(), y.toDouble()).toFloat()
        return if (len == 0f) Pt(1f, 0f) else Pt(x / len, y / len)
    }

    private fun mid(a: Pt, b: Pt) = Pt((a.x + b.x) / 2f, (a.y + b.y) / 2f)
}

/** A point in the overlay's (== PhotoEditorView's) coordinates. */
data class Pt(val x: Float, val y: Float) {
    fun plus(dx: Float, dy: Float) = Pt(x + dx, y + dy)
}

/** Four labelled corners. Labels are LOCAL (the artwork's top-left), not screen-sorted. */
data class Quad(val topLeft: Pt, val topRight: Pt, val bottomRight: Pt, val bottomLeft: Pt)

/**
 * The drawn chrome: the [frame], each handle's centre, the graphic's on-screen angle (for
 * rotating the glyphs and the frame's rounded corners), and its unit axes on screen.
 */
data class Chrome(
    val frame: Quad,
    val handles: Map<SelectionHandle, Pt>,
    val angleDegrees: Float,
    val axisX: Pt,
    val axisY: Pt,
)

/** The eight selection handles. Text and emoji graphics have the four corners only. */
enum class SelectionHandle(val corner: CornerHandle?, val edge: EdgeHandle?) {
    TOP_LEFT(CornerHandle.TOP_LEFT, null),
    TOP_RIGHT(CornerHandle.TOP_RIGHT, null),
    BOTTOM_RIGHT(CornerHandle.BOTTOM_RIGHT, null),
    BOTTOM_LEFT(CornerHandle.BOTTOM_LEFT, null),
    TOP(null, EdgeHandle.TOP),
    RIGHT(null, EdgeHandle.RIGHT),
    BOTTOM(null, EdgeHandle.BOTTOM),
    LEFT(null, EdgeHandle.LEFT),
    ;

    val isCorner: Boolean get() = corner != null
}

/**
 * The 2D-relevant state of one view, as it maps into its parent. [parentScrollX]/[parentScrollY]
 * are the PARENT's scroll (Android subtracts it when drawing children).
 */
data class ViewXform(
    val left: Float,
    val top: Float,
    val width: Int,
    val height: Int,
    val pivotX: Float = width / 2f,
    val pivotY: Float = height / 2f,
    val translationX: Float = 0f,
    val translationY: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val rotation: Float = 0f,
    val parentScrollX: Float = 0f,
    val parentScrollY: Float = 0f,
    val visible: Boolean = true,
    /** False when the view carries rotationX/rotationY, which a 2D map cannot represent. */
    val planar: Boolean = true,
) {
    /** Laid out, visible and representable -- the GAME-763 rule. */
    val isDrawable: Boolean get() = visible && planar && width > 0 && height > 0

    companion object {
        /** Snapshot of a live view. The only Android read in the geometry. */
        fun of(view: View): ViewXform {
            val parent = view.parent as? View
            return ViewXform(
                left = view.left.toFloat(),
                top = view.top.toFloat(),
                width = view.width,
                height = view.height,
                pivotX = view.pivotX,
                pivotY = view.pivotY,
                translationX = view.translationX,
                translationY = view.translationY,
                scaleX = view.scaleX,
                scaleY = view.scaleY,
                rotation = view.rotation,
                parentScrollX = (parent?.scrollX ?: 0).toFloat(),
                parentScrollY = (parent?.scrollY ?: 0).toFloat(),
                visible = view.visibility == View.VISIBLE,
                planar = view.rotationX == 0f && view.rotationY == 0f,
            )
        }
    }
}
