package com.flocmedia.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.View
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Date

// ~2000x2000 pixels. This function allocates an ALPHA_8 bitmap of this size plus one
// IntArray pixel buffer of the same pixel count (4 bytes each) for its working set, so the
// real footprint is roughly (1 + 4) bytes/pixel * MAX_TRANSPARENT_CACHE_PIXELS ~= 20MB,
// safely inside the ~268MB growth limit seen in the real OutOfMemoryError this budget fixes
// (a 55MB single allocation against 25MB free, target footprint 241MB / limit 268MB).
internal const val MAX_TRANSPARENT_CACHE_PIXELS = 4_000_000L

// Pure, Android-free so it is testable on the JVM without Robolectric or a real Bitmap
// allocation (Robolectric's shadow bitmap allocator does not enforce real heap limits, so it
// could only validate the decision here, not reproduce the OOM). Long arithmetic is
// deliberate: width/height are already-scaled Ints that can be large enough for their
// product to overflow a 32-bit Int and silently produce a small/negative result, which would
// defeat the whole point of the check.
internal fun exceedsTransparentCacheBudget(width: Int, height: Int): Boolean =
    width.toLong() * height.toLong() > MAX_TRANSPARENT_CACHE_PIXELS

internal class EditorTransparentCache(
    private val photoEditorViewState: PhotoEditorViewState,
    private val lifecycleScope: CoroutineScope,
) {

    // Called by the imageView/textView onTouch callback, to flag that the imageView/textView-relative event clicked on
    // an opaque pixel. This *must* be done from imageView relative coordinates.
    //
    // When the flag (lastImageTouchMouseDownEventWasOpaque) is set to true, the next MOUSE_DOWN
    // event will mark the sticker as selected.
    //
    // TODO(cheng): Might make more sense to just check if there is a click intersection
    //              map here, and move out of MultiTouchListener.
    fun onChildItemActualViewOnTouch(
        itemRootFrameView: View,
        itemActualViewRelativeEventX: Float,
        itemActualViewRelativeEventY: Float
    ) {

        // Only enable click through on unfocused stickers.
        // If the sticker is focused, mark it as "opaque clicked" so it can be moved
        // even if the user doesn't touch the sticker directly.
        if (itemRootFrameView === photoEditorViewState.currentSelectedView) {
            photoEditorViewState.multiTouchListenerByView[itemRootFrameView]?.lastImageTouchMouseDownEventWasOpaque = true
            return
        }

        // If user clicks on an transparent pixel we return but not absorbing the event
        photoEditorViewState.multiTouchListenerByView[itemRootFrameView]?.lastImageTouchMouseDownEventWasOpaque = isOpaquePixelClicked(
            itemRootFrameView,
            photoEditorViewState.multiTouchListenerByView[itemRootFrameView],
            itemActualViewRelativeEventX,
            itemActualViewRelativeEventY
        )
    }

    private val mutex = Mutex()

    /**
     * Everything the main thread has to hand over: the rendered bitmap and the
     * listener to write the result back to.
     */
    private class PreparedCache(
        val multiTouchListener: MultiTouchListener,
        val bitmap: Bitmap,
        val canvas: Canvas,
        val startedAt: Date,
    )

    /**
     * Builds the click-through cache for one graphic.
     *
     * **Split across two dispatchers on purpose (GAME-945).** This used to run
     * entirely inside `withContext(Dispatchers.IO)`, including
     * `itemActualView.draw(...)` — drawing a View that is simultaneously live in
     * the main-thread hierarchy, plus reading its `width`/`height`/`scaleX` off
     * the main thread.
     *
     * That is not a theoretical hazard: it is the mechanism behind GAME-873,
     * where a concurrent off-main draw of an `OutlinedTextView` made it report
     * the stroke colour as its fill and the glyph outline came out white on
     * white. The library now holds a lock across its own two-pass draw
     * (PhotoEditor `bf9f29b`), which makes *that* symptom impossible — but the
     * lock guards one view class, not this pattern, and every other view drawn
     * through here has the same exposure with no such guard.
     *
     * The work separates cleanly, and the split puts LESS on the main thread
     * than the naive fix: only the View read and draw move, while the
     * O(width × height) edge scan — millions of iterations — stays off it. The
     * circle drawing that follows targets an off-screen `Canvas(bitmap)`, not a
     * View, so it is safe where it is.
     *
     * `mutex.withLock` already serialises calls, so main-thread draws cannot
     * pile up behind each other.
     */
    private suspend fun updateTransparentPickerCacheWithCoroutine(
        graphicRootView: View?,
        forceUpdate: Boolean
    ) = mutex.withLock {
        val prepared = withContext(Dispatchers.Main) {
            renderGraphicToBitmap(graphicRootView, forceUpdate)
        } ?: return@withLock

        withContext(Dispatchers.IO) {
            buildIntersectionMap(prepared)
        }
    }

    /**
     * MAIN THREAD ONLY. Reads the live View's geometry and rasterises it.
     *
     * Returns null when there is nothing to do — no view, no listener, an
     * unmeasured view, a still-valid cache, or a size over budget. Every one of
     * those was an early `return@withContext` in the single-block version.
     */
    private fun renderGraphicToBitmap(
        graphicRootView: View?,
        forceUpdate: Boolean,
    ): PreparedCache? {
        if (graphicRootView == null) {
            return null
        }
        val multiTouchListener =
            photoEditorViewState.multiTouchListenerByView[graphicRootView] ?: return null

        val itemActualView: View = findActualView(graphicRootView)
        // Might be a BrushDrawingView, or something else.
            ?: return null

        // We keep a cache of the "screenshot" of the imageView.  If it does not change width or height,
        // or does not exist, we do not need to refresh.
        val currentScaleX = graphicRootView.scaleX
        val currentScaleY = graphicRootView.scaleY
        if (
            itemActualView.width <= 0 ||
            itemActualView.height <= 0 ||
            multiTouchListener.scaledImageIntersectionPixelMap != null &&
            multiTouchListener.scaledImageBitmapWidth == (itemActualView.width * currentScaleX).toInt() &&
            multiTouchListener.scaledImageBitmapHeight == (itemActualView.height * currentScaleY).toInt() &&
            !forceUpdate
        ) {
            return null
        }
        val intersectionPixelMapStartTime = Date()

        // Do NOT null scaledImageIntersectionPixelMap here (GAME-1096). The rebuild below
        // runs asynchronously on IO; nulling the map up front opens a window where
        // isOpaquePixelClicked's null branch treats the whole bounding box as opaque, so a
        // tap on a transparent pixel steals selection mid-rebuild. Instead we keep serving
        // the stale map until the freshly built one is atomically swapped in at the end of
        // buildIntersectionMap (a stale-sized cache is still caught by the dimension check),
        // so there is never an all-opaque window.

        // Guard against allocating a bitmap (plus the IntArray pixel buffer built below)
        // large enough to OOM. A view can reach here with a large base size AND a large
        // pinch-zoom scale at once; each is clamped individually elsewhere
        // (EditImageActivity.stretchSticker, MultiTouchListener's zoom cap), but only this
        // function has both values in hand to bound their product. If the budget is
        // exceeded, skip the cache build and leave the previous cache in place —
        // isOpaquePixelClicked's dimension check treats a stale-sized cache as "clickable"
        // and re-triggers a recompute attempt, so this fails safe.
        val scaledWidth = (itemActualView.width * currentScaleX).toInt()
        val scaledHeight = (itemActualView.height * currentScaleY).toInt()
        if (exceedsTransparentCacheBudget(scaledWidth, scaledHeight)) {
            return null
        }

        // Create a bitmap to render the imageView.  We will scale the imageView to the
        // scale of the root view to make it match the pixel scale on the screen.
        // From there, we can draw a circle of pixels around the click point, and determine
        // if any are opaque.
        val scaledImageViewBitmap = Bitmap.createBitmap(
            scaledWidth,
            scaledHeight,
            Bitmap.Config.ALPHA_8
        )

        // Scale the imageView canvas to match the root view scale (also the pixel scale on the screen).
        // Write the view to a canvas, which writes it to a bitmap.
        // https://stackoverflow.com/a/17501830
        val scaledImageViewCanvas = Canvas(scaledImageViewBitmap)

        // Add a scale translation matrix, and draw the original image.
        // After drawing, restore() the original matrix so drawing the circles
        // happens at the 1:1 canvas resolution.
        //
        // THE reason this function is main-thread-only. Everything above reads
        // the live View; this line draws it.
        scaledImageViewCanvas.save()
        scaledImageViewCanvas.scale(currentScaleX, currentScaleY)
        itemActualView.draw(scaledImageViewCanvas)
        scaledImageViewCanvas.restore()

        return PreparedCache(
            multiTouchListener,
            scaledImageViewBitmap,
            scaledImageViewCanvas,
            intersectionPixelMapStartTime,
        )
    }

    /**
     * Pure pixel work on an already-rendered bitmap. Touches no View, so it is
     * safe anywhere — and it is the expensive half, so it belongs off the main
     * thread.
     */
    private fun buildIntersectionMap(prepared: PreparedCache) {
        val multiTouchListener = prepared.multiTouchListener
        val scaledImageViewBitmap = prepared.bitmap
        val scaledImageViewCanvas = prepared.canvas
        val intersectionPixelMapStartTime = prepared.startedAt

        // Save the whole image as a int array of pixels (greyscale only).
        // This is the array that will be directly checked for opacity.
        // From this, we build the "intersection map", which is a bitmap where black
        // indicates that a given pixel is either opaque in the original image, or
        // is within mTransparentPixelsClickThroughRadius radius of a partially opaque pixel
        // in the original image.
        // https://stackoverflow.com/a/33689433/1015951
        val scaledImageBitmapWidth = scaledImageViewBitmap.width
        val scaledImageBitmapHeight = scaledImageViewBitmap.height
        // One buffer for the whole graphic, reused across both passes (GAME-1096): it first
        // holds the original pixels the edge scan reads, then is overwritten in place with
        // the post-circle pixels that become the stored intersection map. The passes never
        // overlap (the scan loop fully completes before the re-read), so a second
        // full-image IntArray would be pure waste.
        val scaledImageBitmapPixels =
            IntArray(scaledImageViewBitmap.width * scaledImageViewBitmap.height)

        // Copy the pixels from the original scaled bitmap into an array, to use for
        // iterating and building the intersection map.
        scaledImageViewBitmap.getPixels(
            scaledImageBitmapPixels,
            0,
            scaledImageBitmapWidth,
            0,
            0,
            scaledImageBitmapWidth,
            scaledImageBitmapHeight
        )

        // Build the parameters for painting the circles along the "edges"
        // of the main image.
        val circlePaintStyle = Paint()
        circlePaintStyle.color = Color.WHITE
        circlePaintStyle.style = Paint.Style.FILL

        // Build a "selection bitmap", where we pre-bake a bitmap whether each pixel
        // is either a valid selection pixel or not.
        //
        // We mark these pixels by looping through each pixel and determining if it is an "edge",
        // as in, it shared a neighbor with an pixel that is 100% see-through (alpha).
        // If it is an edge pixel, we draw a mTransparentPixelsClickThroughRadius circle around that pixel
        // which marks every pixel within mTransparentPixelsClickThroughRadius as a valid seleciton pixel.
        //
        // NOTE: the original comment here claimed this is hardware-accelerated and
        // therefore cheap. It is not — a Canvas backed by a Bitmap is a software
        // canvas. The loop below is O(width × height) with a drawCircle per edge
        // pixel, and it is the reason this half stays off the main thread.
        // References For Circle research, including alternate to draw a transparent circle:
        //     https://stackoverflow.com/a/12089127/1015951
        //     https://stackoverflow.com/a/35542312/1015951
        //     https://stackoverflow.com/a/27401319
        //     https://developer.android.com/guide/topics/graphics/hardware-accel
        //     https://developer.android.com/reference/android/graphics/PorterDuff.Mode
        for (pixelX in 0 until scaledImageBitmapWidth) {
            for (pixelY in 0 until scaledImageBitmapHeight) {
                if (ClickAreaUtils.isEdgePixel(
                        pixelX,
                        pixelY,
                        scaledImageBitmapWidth,
                        scaledImageBitmapHeight,
                        scaledImageBitmapPixels
                    )
                ) {
                    scaledImageViewCanvas.drawCircle(
                        pixelX.toFloat(),
                        pixelY.toFloat(),
                        CLICKTHROUGH_RADIUS.toFloat(),
                        circlePaintStyle
                    )
                }
            }
        }

        // Re-read the bitmap (now including the drawn circles) into the same buffer; this
        // overwrites the original pixels the edge scan already consumed above.
        scaledImageViewBitmap.getPixels(
            scaledImageBitmapPixels,
            0,
            scaledImageBitmapWidth,
            0,
            0,
            scaledImageBitmapWidth,
            scaledImageBitmapHeight
        )

        // Check our timestamp to make sure we started after the last built intersectionMap,
        // to avoid potential race condition.
        //
        // NOTE(cheng): Makes more sense to test this against the actual dimensions.
        if (multiTouchListener.scaledImageIntersectionPixelMapTimestamp == null ||
            multiTouchListener.scaledImageIntersectionPixelMapTimestamp!!.before(intersectionPixelMapStartTime)
        ) {
            multiTouchListener.scaledImageBitmapWidth = scaledImageBitmapWidth
            multiTouchListener.scaledImageBitmapHeight = scaledImageBitmapHeight
            multiTouchListener.scaledImageIntersectionPixelMap = scaledImageBitmapPixels
            multiTouchListener.scaledImageIntersectionPixelMapTimestamp = intersectionPixelMapStartTime
        }
    }


    fun updateTransparentPickerCacheIfNecessary(graphicRootView: View?, forceUpdate: Boolean = false) {
        lifecycleScope.launch {
            updateTransparentPickerCacheWithCoroutine(graphicRootView, forceUpdate)
        }
    }

    fun updateTransparentPickerCacheOfCurrentSelectedView() {
        val currentSelectedView: View? = photoEditorViewState.currentSelectedView
        updateTransparentPickerCacheIfNecessary(currentSelectedView)
    }

    fun updateTransparentPickerCacheOfAllViews() {
        for (graphicView: View in photoEditorViewState.multiTouchListenerByView.keys) {
            updateTransparentPickerCacheIfNecessary(graphicView)
        }
    }

    /**
     * Calculates if a given event passed to a given view_photo_editor_image view
     * touches a opaque pixel in a given radius.
     *
     * NOTE(cheng): The (x,y) must originate in from the item's outer view (GraphicView), *not* the
     * frameView, imageView, or actual text view, otherwise the scale math will be wrong.
     *
     * TODO(cheng): Explore moving this logic out of MultiTouchListener and into a helper
     * owned by PhotoEditor. This would make sense since
     *
     * @return False if the click is on an fully transparent pixel (and if no
     * opaque pixel is found inside the given radius), true otherwise.
     */
    private fun isOpaquePixelClicked(
        itemRootFrameView: View,
        multiTouchListener: MultiTouchListener?,
        itemActualViewRelativeEventX: Float,
        itemActualViewRelativeEventY: Float
    ): Boolean {

        // Return 'true' by default, so users aren't confused by their ability to select things
        // NOTE(cheng): Change this to have more state.
        if (multiTouchListener == null) {
            return true
        }

        // TODO(cheng): Collapse this with duplicate logic above.
        val itemActualView: View = if (itemRootFrameView.findViewById<View?>(R.id.imgPhotoEditorImage) != null) {
            itemRootFrameView.findViewById(R.id.imgPhotoEditorImage)
        } else if (itemRootFrameView.findViewById<View?>(R.id.tvPhotoEditorText) != null) {
            itemRootFrameView.findViewById<View>(R.id.tvPhotoEditorText)
        } else {
            // Might be a BrushDrawingView, or something else.
            // TODO(cheng): This might make brushDrawingViews effectively unselectable,
            //              Fix this.
            return false
        }

        // Double-check that the incoming imageViewRelative point is within the imageView.
        // NOTE(cheng): After moving this logic out of multiTouchListener, this is unnecessary,
        //              as the event will not be fired unless it is within the imageView.
        val itemActualViewHitRect = Rect(0, 0, itemActualView.width, itemActualView.height)
        if (!itemActualViewHitRect.contains(
                itemActualViewRelativeEventX.toInt(),
                itemActualViewRelativeEventY.toInt()
            )
        ) {
            return false
        }

        // If we do not have a cache, return 'true' to say we hit a opaque sticker.
        // NOTE(cheng): If we do not do this, the sticker is effectively unselectable, which means
        // a user cannot delete it.
        // TODO(cheng): Change the return value of this method to have 3 options: yes, no, unknown.
        if (multiTouchListener.scaledImageIntersectionPixelMap == null) {
            updateTransparentPickerCacheIfNecessary(
                itemRootFrameView
            )
            return true
        }

        // Safety check. If the "intersection image bitmap" does not equal the scaled size
        // of the actual image of the sticker / emoji / text, it means we missed a recalculation
        // of the intersection matrix after a resize. Force select and redraw.
        if (multiTouchListener.scaledImageBitmapWidth != (itemActualView.width * itemRootFrameView.scaleX).toInt() ||
            multiTouchListener.scaledImageBitmapHeight != (itemActualView.height * itemRootFrameView.scaleY).toInt()
        ) {
            updateTransparentPickerCacheIfNecessary(
                itemRootFrameView
            )
            return true
        }

        // Calculate the scaled x,y within the image, using the itemActualViewHitRect (left, top)
        // coordinate to offset it within the image's parent view. This is necessary since
        // it is the parent (GraphicView) that is scaled. The ImageView is always it's original size.
        //
        // We will scale the resulting click event based on the root view's scale, so scale the x,y as well
        // NOTE(cheng): This assumes that the imageViewRelativeEvent point is cartesian and (0,0) based,
        //              so there is no need to offset by left/top.
        // NOTE(cheng): As of this writing, it is not necessary to include the scale of the "parentView"
        //              (background photo). I assume this is because the event's (x,y) is relative to the
        //              GraphicView and the outer scale of the photo is not relevant.
        // The actual click-through decision (click-radius/bitmap intersection, then a
        // fully-transparent-vs-not check on the pixel at its center) is a pure function --
        // see ClickAreaUtils.isOpaquePixelWithinRadius for the extracted logic and its tests.
        return ClickAreaUtils.isOpaquePixelWithinRadius(
            pixelMap = multiTouchListener.scaledImageIntersectionPixelMap!!,
            bitmapWidth = multiTouchListener.scaledImageBitmapWidth,
            bitmapHeight = multiTouchListener.scaledImageBitmapHeight,
            eventX = itemActualViewRelativeEventX,
            eventY = itemActualViewRelativeEventY,
            scaleX = itemRootFrameView.scaleX,
            scaleY = itemRootFrameView.scaleY,
            clickRadius = CLICKTHROUGH_RADIUS
        )
    }

    // The graphic's content view (image or text). GAME-1087: inlined into the
    // library (the app's GraphicHelper.findActualView stays app-side, used widely
    // there); the ids are the library's own.
    private fun findActualView(rootView: View): View? =
        rootView.findViewById<View?>(R.id.imgPhotoEditorImage)
            ?: rootView.findViewById<View?>(R.id.tvPhotoEditorText)

    companion object {
        private const val CLICKTHROUGH_RADIUS = 30
    }

}