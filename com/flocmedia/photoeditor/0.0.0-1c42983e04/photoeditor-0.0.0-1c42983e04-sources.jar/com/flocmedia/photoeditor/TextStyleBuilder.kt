package com.flocmedia.photoeditor

import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.widget.TextView
import java.util.*

/**
 *
 *
 * This class is used to wrap the styles to apply on the TextView on [PhotoEditor.addText] and [PhotoEditor.editText]
 *
 *
 * @author [Christian Caballero](https://github.com/Sulfkain)
 * @since 14/05/2019
 */
open class TextStyleBuilder {
    val values = mutableMapOf<TextStyle, Any>()

    /**
     * Set this textSize style
     *
     * @param size Size to apply on text
     */
    fun withTextSize(size: Float) {
        values[TextStyle.SIZE] = size
    }

    /**
     * Set this textShadow style
     *
     * @param radius Radius of the shadow to apply on text
     * @param dx Horizontal distance of the shadow
     * @param dy Vertical distance of the shadow
     * @param color Color of the shadow
     */
    fun withTextShadow(radius: Float, dx: Float, dy: Float, color: Int) {
        val shadow = TextShadow(radius, dx, dy, color)
        withTextShadow(shadow)
    }

    /**
     * Set this color style
     *
     * @param color Color to apply on text
     */
    fun withTextColor(color: Int) {
        values[TextStyle.COLOR] = color
    }

    /**
     * Set this [Typeface] style
     *
     * @param textTypeface TypeFace to apply on text
     */
    fun withTextFont(textTypeface: Typeface) {
        values[TextStyle.FONT_FAMILY] = textTypeface
    }

    /**
     * Set this gravity style
     *
     * @param gravity Gravity style to apply on text
     */
    fun withGravity(gravity: Int) {
        values[TextStyle.GRAVITY] = gravity
    }

    /**
     * Set this background color
     *
     * @param background Background color to apply on text, this method overrides the preview set on [TextStyleBuilder.withBackgroundDrawable]
     */
    fun withBackgroundColor(background: Int) {
        values[TextStyle.BACKGROUND] = background
    }

    /**
     * Set this background [Drawable], this method overrides the preview set on [TextStyleBuilder.withBackgroundColor]
     *
     * @param bgDrawable Background drawable to apply on text
     */
    fun withBackgroundDrawable(bgDrawable: Drawable) {
        values[TextStyle.BACKGROUND] = bgDrawable
    }

    /**
     * Set this textAppearance style
     *
     * @param textAppearance Text style to apply on text
     */
    fun withTextAppearance(textAppearance: Int) {
        values[TextStyle.TEXT_APPEARANCE] =
            textAppearance
    }

    fun withTextStyle(typeface: Int) {
        values[TextStyle.TEXT_STYLE] = typeface
    }

    fun withTextFlag(paintFlag: Int) {
        values[TextStyle.TEXT_FLAG] = paintFlag
    }

    fun withTextShadow(textShadow: TextShadow) {
        values[TextStyle.SHADOW] = textShadow
    }

    fun withTextBorder(textBorder: TextBorder) {
        values[TextStyle.BORDER] = textBorder
    }

    /**
     * Draw a contrasting outline around the glyphs, so the text stays legible
     * over a busy background.
     *
     * Unlike [withTextBorder], which paints a rectangle behind the whole text
     * block, this follows the shape of the letters themselves. The outline
     * colour is not configurable: it is black or white, whichever contrasts
     * with the text colour, and it re-resolves itself whenever that colour
     * changes.
     *
     * Only takes effect on an [OutlinedTextView]; see [applyTextOutline].
     */
    fun withTextOutline(textOutline: TextOutline) {
        values[TextStyle.OUTLINE] = textOutline
    }

    fun withTextOutline(enabled: Boolean) {
        withTextOutline(TextOutline(enabled))
    }

    /**
     * Method to apply all the style setup on this Builder}
     *
     * @param textView TextView to apply the style
     */
    fun applyStyle(textView: TextView) {
        for ((key, value) in values) {
            when (key) {
                TextStyle.SIZE -> {
                    val size = value as Float
                    applyTextSize(textView, size)
                }
                TextStyle.COLOR -> {
                    val color = value as Int
                    applyTextColor(textView, color)
                }
                TextStyle.FONT_FAMILY -> {
                    val typeface = value as Typeface
                    applyFontFamily(textView, typeface)
                }
                TextStyle.GRAVITY -> {
                    val gravity = value as Int
                    applyGravity(textView, gravity)
                }
                TextStyle.BACKGROUND -> {
                    if (value is Drawable) {
                        applyBackgroundDrawable(textView, value)
                    } else if (value is Int) {
                        applyBackgroundColor(textView, value)
                    }
                }
                TextStyle.TEXT_APPEARANCE -> {
                    if (value is Int) {
                        applyTextAppearance(textView, value)
                    }
                }
                TextStyle.TEXT_STYLE -> {
                    val typeface = value as Int
                    applyTextStyle(textView, typeface)
                }
                TextStyle.TEXT_FLAG -> {
                    val flag = value as Int
                    applyTextFlag(textView, flag)
                }
                TextStyle.SHADOW -> {
                    if (value is TextShadow) {
                        applyTextShadow(textView, value)
                    }
                }
                TextStyle.BORDER -> {
                    if (value is TextBorder) {
                        applyTextBorder(textView, value)
                    }
                }
                TextStyle.OUTLINE -> {
                    if (value is TextOutline) {
                        applyTextOutline(textView, value)
                    }
                }
            }
        }
    }

    protected open fun applyTextSize(textView: TextView, size: Float) {
        textView.textSize = size
    }

    protected fun applyTextShadow(
        textView: TextView,
        radius: Float,
        dx: Float,
        dy: Float,
        color: Int
    ) {
        textView.setShadowLayer(radius, dx, dy, color)
    }

    protected open fun applyTextColor(textView: TextView, color: Int) {
        textView.setTextColor(color)
    }

    protected open fun applyFontFamily(textView: TextView, typeface: Typeface?) {
        textView.typeface = typeface
    }

    protected open fun applyGravity(textView: TextView, gravity: Int) {
        textView.gravity = gravity
    }

    protected open fun applyBackgroundColor(textView: TextView, color: Int) {
        textView.setBackgroundColor(color)
    }

    protected open fun applyBackgroundDrawable(textView: TextView, bg: Drawable?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            textView.background = bg
        } else {
            textView.setBackgroundDrawable(bg)
        }
    }

    // border
    protected open fun applyTextBorder(textView: TextView, textBorder: TextBorder) {
        val gd = GradientDrawable()
        gd.cornerRadius = textBorder.corner
        gd.setStroke(textBorder.strokeWidth, textBorder.strokeColor)
        gd.setColor(textBorder.backGroundColor)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            textView.background = gd
        }
    }

    // glyph outline
    protected open fun applyTextOutline(textView: TextView, textOutline: TextOutline) {
        // Safe cast, not a check-and-throw. The layout that carries an
        // OutlinedTextView is this library's own, but a consumer can inflate
        // its own layout with a plain TextView in it -- and an emoji item
        // reuses the text layout without ever asking for an outline. Silently
        // doing nothing is the correct answer in both cases.
        (textView as? OutlinedTextView)?.isTextOutlineEnabled = textOutline.enabled
    }

    // shadow
    protected open fun applyTextShadow(textView: TextView, textShadow: TextShadow) {
        textView.setShadowLayer(textShadow.radius, textShadow.dx, textShadow.dy, textShadow.color)
    }

    // bold or italic
    protected open fun applyTextStyle(textView: TextView, typeface: Int) {
        textView.setTypeface(textView.typeface, typeface)
    }

    // underline or strike
    protected open fun applyTextFlag(textView: TextView, flag: Int) {
        // OR, not assign. A bare assignment drops every flag the paint already
        // had -- including ANTI_ALIAS_FLAG, which TextView sets when it builds
        // the paint. Aliased text is ugly; an aliased glyph outline is worse,
        // because a stroke is a thin high-contrast edge along its whole length
        // rather than a mostly-solid shape with edges.
        textView.paint.flags = textView.paint.flags or flag
    }

    protected open fun applyTextAppearance(textView: TextView, styleAppearance: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            textView.setTextAppearance(styleAppearance)
        } else {
            textView.setTextAppearance(textView.context, styleAppearance)
        }
    }

    /**
     * Enum to maintain current supported style properties used on on [PhotoEditor.addText] and [PhotoEditor.editText]
     */
    enum class TextStyle(val property: String) {
        SIZE("TextSize"),
        COLOR("TextColor"),
        GRAVITY("Gravity"),
        FONT_FAMILY("FontFamily"),
        BACKGROUND("Background"),
        TEXT_APPEARANCE("TextAppearance"),
        TEXT_STYLE("TextStyle"),
        TEXT_FLAG("TextFlag"),
        SHADOW("Shadow"),
        BORDER("Border"),
        OUTLINE("TextOutline");

    }
}