package com.flocmedia.photoeditor

import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.RelativeLayout

/**
 * Created by Burhanuddin Rashid on 15/05/21.
 *
 * @author <https:></https:>//github.com/burhanrashid52>
 */
internal class GraphicManager(
    private val mCanvasView: ViewGroup,
    private val mViewState: PhotoEditorViewState
) {
    var onPhotoEditorListener: OnPhotoEditorListener? = null
    fun addView(graphic: Graphic) {
        val view = graphic.rootView
        val params = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )

        // NOTE(cheng): Commenting this out since this makes it impossible to resize/move the graphic
        //              after it has been added.
        // params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        mCanvasView.addView(view, params)
        mViewState.addAddedView(view)

        // History entry for the add. pushOperation() also clears the redo
        // branch, which is the reasoning ported from upstream 8648773 ("Fix
        // redo logic") -- a new action makes previously-undone work
        // unreachable.
        mViewState.pushOperation(
            AddViewOperation(
                view = view,
                canvasView = mCanvasView,
                viewState = mViewState,
                index = mViewState.indexOfAddedView(view),
                onChanged = ::notifyViewCountChanged,
            )
        )

        // NOTE(fleissig): we can center the text because we already know its size
        if (graphic is Text) {
            view.x = mCanvasView.width/2f - view.width/2f
            view.y = mCanvasView.height/2f - view.height/2f
        }
        else if (graphic is Sticker) {
            view.viewTreeObserver.addOnGlobalLayoutListener(object :
                ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    val stickerDefSize = graphic.context.resources.getDimension(R.dimen.default_sticker_size)
                    view.layoutParams.width = stickerDefSize.toInt()
                    view.layoutParams.height = stickerDefSize.toInt()

                    view.requestLayout()

                    // Remove listener after being called so it doesn't loop on every change.
                    view.viewTreeObserver.removeOnGlobalLayoutListener(this)
                }
            })
        }

        onPhotoEditorListener?.onAddViewListener(
            graphic.viewType,
            mViewState.addedViewsCount
        )
    }

    fun removeView(graphic: Graphic) {
        val view = graphic.rootView
        if (mViewState.containsAddedView(view)) {
            // Recorded BEFORE the removal, or the index and the listener are
            // already gone by the time we need them.
            val index = mViewState.indexOfAddedView(view)
            val listener = mViewState.multiTouchListenerByView[view]

            mCanvasView.removeView(view)
            mViewState.removeAddedView(view)
            mViewState.multiTouchListenerByView.remove(view)

            // Previously this pushed the view onto the REDO stack, which meant
            // a delete was reversed by pressing Redo rather than Undo -- an
            // inversion nobody would guess. It is an undoable action like any
            // other now.
            mViewState.pushOperation(
                DeleteViewOperation(
                    view = view,
                    canvasView = mCanvasView,
                    viewState = mViewState,
                    index = index,
                    touchListener = listener,
                    onChanged = ::notifyViewCountChanged,
                )
            )

            onPhotoEditorListener?.onRemoveViewListener(
                graphic.viewType,
                mViewState.addedViewsCount
            )
        }
    }

    /**
     * Records a delete performed by a caller that already removed the view.
     *
     * `PhotoEditorImpl.removeInFocusView` does its own removal (it also has to
     * clear the selection), so this records the history entry without touching
     * the canvas a second time.
     */
    fun recordDelete(view: View, index: Int, touchListener: MultiTouchListener?) {
        mViewState.pushOperation(
            DeleteViewOperation(
                view = view,
                canvasView = mCanvasView,
                viewState = mViewState,
                index = index,
                touchListener = touchListener,
                onChanged = ::notifyViewCountChanged,
            )
        )
    }

    /**
     * Records a completed move/resize/rotate. No-op gestures are dropped -- see
     * [TransformOperation].
     */
    fun recordTransform(view: View, before: Transform, after: Transform) {
        val operation = TransformOperation(view, before, after)
        if (operation.isNoOp) {
            return
        }
        mViewState.pushOperation(operation)
    }

    /** Records an operation the editor performed outside the graphic pipeline. */
    fun recordOperation(operation: EditorOperation) {
        mViewState.pushOperation(operation)
    }

    private fun notifyViewCountChanged(added: Boolean, view: View) {
        val viewTag = view.tag
        if (viewTag !is ViewType) {
            return
        }
        if (added) {
            onPhotoEditorListener?.onAddViewListener(viewTag, mViewState.addedViewsCount)
        } else {
            onPhotoEditorListener?.onRemoveViewListener(viewTag, mViewState.addedViewsCount)
        }
    }

    fun updateView(view: View) {
        mCanvasView.updateViewLayout(view, view.layoutParams)
        mViewState.replaceAddedView(view)
    }

    /**
     * Reverses the last thing the user did, whatever kind of thing it was.
     *
     * One ordered stack now, so a move, a delete, an add and a brush stroke
     * come back in the order they happened. The old implementation walked the
     * ADDED-VIEWS list instead, which is why it could only ever undo an add,
     * and why the DrawingView special case had to reason about two stacks at
     * once to answer "is there anything left?".
     *
     * @return whether anything remains to undo after this call.
     */
    fun undoView(): Boolean {
        val operation = mViewState.popUndoOperation()
        if (operation != null) {
            // Guarded: an app-supplied operation normally undoes itself by
            // calling the same app code that performed the action, and that
            // code records. Unguarded, undoing would push a new entry and the
            // stack would grow as the user tried to empty it.
            mViewState.replayingOperation { operation.undo() }
            mViewState.pushRedoOperation(operation)
        }
        return mViewState.undoCount > 0
    }

    /**
     * Re-applies the last undone action.
     *
     * @return whether anything remains to redo after this call.
     */
    fun redoView(): Boolean {
        val operation = mViewState.popRedoOperation()
        if (operation != null) {
            mViewState.replayingOperation { operation.redo() }
            mViewState.pushUndoOperation(operation)
        }
        return mViewState.redoCount > 0
    }
}
