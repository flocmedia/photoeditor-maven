package com.flocmedia.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.os.Build
import kotlin.math.roundToInt

/**
 * Draws a single graphic's bitmap onto an export canvas with its transform.
 *
 * Moved into the library from the app's `CanvasHelper.drawBitmap` (GAME-1087,
 * the HD-export render-core slice). This is the exact per-graphic draw the
 * original-resolution export composites each sticker / text / overlay through,
 * and it is where every live-vs-export coherence fix has landed:
 *  - GAME-703: per-graphic [GraphicBlendMode] against the layers already drawn.
 *  - GAME-692: per-graphic brightness/contrast/saturation, passed here as a
 *    plain [ColorFilter] so the library stays free of the app's `Adjustments`
 *    model -- the app computes `adjustments.toColorFilter()` and hands it over.
 *  - GAME-1040: vertical flip, the Y-axis mirror of the horizontal flip.
 *
 * Keeping it in one library-owned place is the structural guard against those
 * three bugs quietly diverging again between whatever composites an export and
 * whatever the app does live: there is now a single implementation of "draw a
 * graphic with its transform", not a copy per call site.
 *
 * Pure with respect to app state -- it takes primitives, a [Canvas], a [Bitmap],
 * a [GraphicBlendMode] and an optional [ColorFilter], and touches nothing else.
 */
object GraphicCompositor {

    /**
     * @param canvas         the export canvas being composited into
     * @param bitmap         the graphic's source bitmap
     * @param targetWidth    on-canvas width the bitmap is drawn at
     * @param targetHeight   on-canvas height the bitmap is drawn at
     * @param targetLeft     on-canvas left of the (unflipped) draw rect
     * @param targetTop      on-canvas top of the (unflipped) draw rect
     * @param bitmapAlpha    0..1, multiplied into the paint's 0..255 alpha
     * @param rotation       degrees, about the graphic's centre
     * @param flipHorizontal mirror across the vertical centre line
     * @param flipVertical   mirror across the horizontal centre line. The
     *   rotation angle negates when EXACTLY ONE axis is flipped (two flips
     *   restore handedness, so the angle is unchanged) -- an XOR.
     * @param blendMode      per-graphic blend against the backdrop; NORMAL and
     *   anything below API 29 draw as-is.
     * @param colorFilter    per-graphic colour filter (the app's B/C/S
     *   adjustment), or null for none.
     */
    fun drawGraphicBitmap(
        canvas: Canvas,
        bitmap: Bitmap,
        targetWidth: Float,
        targetHeight: Float,
        targetLeft: Float,
        targetTop: Float,
        bitmapAlpha: Float,
        rotation: Float,
        flipHorizontal: Boolean,
        flipVertical: Boolean = false,
        blendMode: GraphicBlendMode = GraphicBlendMode.NORMAL,
        colorFilter: ColorFilter? = null,
    ) {
        val scaleX = targetWidth / bitmap.width
        val scaleY = targetHeight / bitmap.height

        canvas.save()

        canvas.scale(
            if (flipHorizontal) -scaleX else scaleX,
            if (flipVertical) -scaleY else scaleY,
        )

        canvas.rotate(
            if (flipHorizontal != flipVertical) -rotation else rotation,
            if (flipHorizontal) {
                (targetLeft + targetWidth / 2) / -scaleX
            } else {
                (targetLeft + targetWidth / 2) / scaleX
            },
            if (flipVertical) {
                (targetTop + targetHeight / 2) / -scaleY
            } else {
                (targetTop + targetHeight / 2) / scaleY
            }
        )

        canvas.drawBitmap(bitmap,
            if (flipHorizontal) {
                (targetLeft + targetWidth) / -scaleX
            } else {
                targetLeft / scaleX
            },
            if (flipVertical) {
                (targetTop + targetHeight) / -scaleY
            } else {
                targetTop / scaleY
            },
            Paint().apply {
                alpha = (bitmapAlpha * 255).roundToInt()
                // Per-graphic blend against the layers already on the canvas
                // (GAME-703). BlendMode is alpha-aware and API 29+, so a bitmap's
                // transparent surround leaves the backdrop intact; below 29 and
                // for NORMAL the bitmap draws as-is.
                if (blendMode != GraphicBlendMode.NORMAL &&
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                ) {
                    this.blendMode = blendMode.toBlendMode()
                }
                // GAME-692: per-graphic brightness/contrast/saturation, the same
                // ColorMatrix applied live on the sticker view. null = no change.
                this.colorFilter = colorFilter
            }
        )

        canvas.restore()
    }
}
