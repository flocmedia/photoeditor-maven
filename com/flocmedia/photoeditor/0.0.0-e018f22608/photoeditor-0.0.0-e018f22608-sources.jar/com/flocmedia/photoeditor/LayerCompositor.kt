package com.flocmedia.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint

/**
 * One drawable layer in an ordered export composite.
 *
 * GAME-1158 (HD-export layer stack): the app's original-resolution export walks
 * a z-sorted set of graphics and draws each onto the output canvas. That walk is
 * moving into the library so the ordered composite is owned in one place; the
 * app keeps every bit of asset resolution and geometry (Room lookups, crop
 * offsets, relative->absolute coordinates, the source subsampling decision) and
 * hands the library a ready-to-draw, already-ordered list.
 *
 * Two kinds, one per draw idiom the export already used, so the composite is
 * byte-identical to the hand-written loop it replaces:
 *  - [Graphic] draws through [GraphicCompositor.drawGraphicBitmap] -- the same
 *    call the text / sticker / overlay draws already made (scale, flip, rotate,
 *    alpha, blend, colour filter).
 *  - [ScaledBitmap] is the brush idiom: a bitmap laid down under a plain
 *    translate + uniform scale. Kept as its own kind rather than folded into a
 *    [Graphic] dest-rect precisely to preserve byte-identity -- expressing it as
 *    a target width/height would route it through a different matrix
 *    (`left/scale * scale`) and can round differently in the last bit.
 */
sealed class RenderLayer {

    /**
     * A graphic (text / sticker / overlay) drawn with the full per-graphic
     * transform. Mirrors [GraphicCompositor.drawGraphicBitmap]'s parameters.
     */
    data class Graphic(
        val bitmap: Bitmap,
        val targetWidth: Float,
        val targetHeight: Float,
        val targetLeft: Float,
        val targetTop: Float,
        val bitmapAlpha: Float,
        val rotation: Float,
        val flipHorizontal: Boolean,
        val flipVertical: Boolean = false,
        val blendMode: GraphicBlendMode = GraphicBlendMode.NORMAL,
        val colorFilter: ColorFilter? = null,
    ) : RenderLayer()

    /**
     * A bitmap drawn at ([translateX], [translateY]) under a uniform [scale],
     * with a default paint -- the brush layer (live drawShapes rasterised to a
     * bitmap, or the durable worker's pre-rasterised brush). Both are spooled at
     * canvas-image size and scaled into the crop region identically.
     */
    data class ScaledBitmap(
        val bitmap: Bitmap,
        val translateX: Float,
        val translateY: Float,
        val scale: Float,
    ) : RenderLayer()
}

/**
 * Draws an already-ordered list of [RenderLayer]s onto [Canvas], bottom to top.
 *
 * The list is drawn in the order given -- the caller has already sorted by z.
 * The compositor adds no policy of its own beyond dispatching each layer to the
 * draw idiom it names, which is what keeps the output identical to the loop it
 * replaces.
 */
object LayerCompositor {

    fun composite(canvas: Canvas, layers: List<RenderLayer>) {
        for (layer in layers) {
            when (layer) {
                is RenderLayer.Graphic -> GraphicCompositor.drawGraphicBitmap(
                    canvas = canvas,
                    bitmap = layer.bitmap,
                    targetWidth = layer.targetWidth,
                    targetHeight = layer.targetHeight,
                    targetLeft = layer.targetLeft,
                    targetTop = layer.targetTop,
                    bitmapAlpha = layer.bitmapAlpha,
                    rotation = layer.rotation,
                    flipHorizontal = layer.flipHorizontal,
                    flipVertical = layer.flipVertical,
                    blendMode = layer.blendMode,
                    colorFilter = layer.colorFilter,
                )
                is RenderLayer.ScaledBitmap -> {
                    canvas.save()
                    canvas.translate(layer.translateX, layer.translateY)
                    canvas.scale(layer.scale, layer.scale)
                    canvas.drawBitmap(layer.bitmap, 0f, 0f, Paint())
                    canvas.restore()
                }
            }
        }
    }
}
