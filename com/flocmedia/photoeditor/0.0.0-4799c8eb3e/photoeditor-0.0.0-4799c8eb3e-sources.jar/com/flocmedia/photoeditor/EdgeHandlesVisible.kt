package com.flocmedia.photoeditor

/**
 * Which of a graphic's four mid-edge stretch handles (GAME-1259) should be shown,
 * given its on-canvas size and the editor zoom. The host toggles the four edge
 * `ImageView`s from this.
 *
 * Pure and Android-free so it is JVM-testable without Robolectric (GAME-1258): the
 * two thresholds are the whole behaviour and each must fail on purpose.
 *
 * Two reasons an edge handle is hidden:
 *  - **short edge** — a mid-edge handle sits at the midpoint of an edge, between
 *    that edge's two corner handles. Below [MIN_EDGE_TO_HANDLE_RATIO] × the touch
 *    box the three 48 dp handles collide, so the mid handle is dropped and the
 *    slider panel covers that sticker. Top/bottom sit on the horizontal edges
 *    (length = width); left/right on the vertical edges (length = height).
 *  - **zoomed out** — chrome scales with canvas zoom (GAME-256), so below
 *    [MIN_EDITOR_SCALE] the 48 dp target shrinks enough to overlap the corners.
 *    This is a deliberate stopgap: the real relative-scaling fix is owner-lane
 *    (GAME-1261), and S13 only hides the edge handles rather than pretend to fix it.
 */
data class EdgeHandlesVisible(
    val top: Boolean,
    val bottom: Boolean,
    val left: Boolean,
    val right: Boolean,
) {
    companion object {
        /** Screen length an edge needs, as a multiple of the handle touch box, to
         *  hold a mid handle clear of its two corner handles. */
        const val MIN_EDGE_TO_HANDLE_RATIO = 2.5f

        /** Canvas zoom below which all four edge handles hide (see the class doc). */
        const val MIN_EDITOR_SCALE = 0.75f

        /**
         * @param widthPx      the graphic's width in device px (its layoutParams width)
         * @param heightPx     the graphic's height in device px
         * @param editorScale  the canvas zoom (`parentLayout.scaleX`)
         * @param handleSizePx `R.dimen.handle_size` in px
         */
        fun forGraphic(
            widthPx: Float,
            heightPx: Float,
            editorScale: Float,
            handleSizePx: Float,
        ): EdgeHandlesVisible {
            if (editorScale < MIN_EDITOR_SCALE) {
                return EdgeHandlesVisible(top = false, bottom = false, left = false, right = false)
            }
            val minEdgeScreenPx = MIN_EDGE_TO_HANDLE_RATIO * handleSizePx
            // Screen-space edge lengths: the on-canvas size times the editor zoom.
            val horizontalEdgesFit = widthPx * editorScale >= minEdgeScreenPx
            val verticalEdgesFit = heightPx * editorScale >= minEdgeScreenPx
            return EdgeHandlesVisible(
                top = horizontalEdgesFit,
                bottom = horizontalEdgesFit,
                left = verticalEdgesFit,
                right = verticalEdgesFit,
            )
        }
    }
}
