package com.flocmedia.photoeditor

import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

/**
 * Created by Burhanuddin Rashid on 18/05/21.
 *
 * @author <https:></https:>//github.com/burhanrashid52>
 */
internal class BoxHelper(
    private val mCanvasView: ViewGroup,
    private val mViewState: PhotoEditorViewState
) {
    fun clearHelperBox() {
        for (i in 0 until mCanvasView.childCount) {
            val childAt = mCanvasView.getChildAt(i)
            val frmBorder = childAt.findViewById<ViewGroup>(R.id.frmBorder)
            frmBorder?.setBackgroundResource(0)
            val imgClose: ImageView? = null
            imgClose?.visibility = View.GONE
        }
        mViewState.clearCurrentSelectedView()
    }

    fun clearAllViews(drawingView: DrawingView?) {
        for (i in 0 until mViewState.addedViewsCount) {
            mCanvasView.removeView(mViewState.getAddedView(i))
        }
        drawingView?.let {
            if (mViewState.containsAddedView(it)) {
                mCanvasView.addView(it)
            }
        }

        mViewState.clearAddedViews()
        mViewState.clearRedoViews()
        drawingView?.clearAll()
    }
}