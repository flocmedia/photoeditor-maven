package com.flocmedia.photoeditor

import android.view.View

/**
 * Public API for the per-graphic blend mode (GAME-703). The consuming app passes
 * a graphic's ROOT view; the mode is stored on the CONTENT view inside it (the
 * sticker image or the text), which is what [BlendableFrameLayout] wraps and
 * blends. Keeping the tag on the content -- not the root -- is what makes the
 * blend affect only the sticker/text and leave the selection border and handles
 * untouched.
 *
 * Mirrors how alpha is a per-graphic property, except a blend has no native View
 * property, so it lives on a tag.
 */
object GraphicBlend {

    /** The blendable content inside a graphic root: the image, else the text. */
    private fun contentOf(rootView: View?): View? = rootView?.let {
        it.findViewById(R.id.imgPhotoEditorImage) ?: it.findViewById(R.id.tvPhotoEditorText)
    }

    /** Set the blend mode on a placed graphic and re-composite it. */
    fun set(rootView: View, mode: GraphicBlendMode) {
        val content = contentOf(rootView) ?: return
        content.setTag(R.id.blend_mode_tag, mode)
        // The blend runs in the content's PARENT (a BlendableFrameLayout); a tag
        // change invalidates nothing, so that parent must be told to redraw.
        (content.parent as? View)?.invalidate()
        content.invalidate()
    }

    /** The graphic's blend mode, or NORMAL if none was set. */
    fun of(rootView: View?): GraphicBlendMode =
        contentOf(rootView)?.getTag(R.id.blend_mode_tag) as? GraphicBlendMode ?: GraphicBlendMode.NORMAL
}
