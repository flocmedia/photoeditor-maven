package com.flocmedia.photoeditor

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.util.AttributeSet
import android.os.Handler
import android.os.Looper
import android.util.Pair
import androidx.annotation.VisibleForTesting
import android.view.MotionEvent
import android.widget.ImageView
import com.flocmedia.photoeditor.shape.*
import java.lang.ref.WeakReference
import java.util.*

/**
 *
 *
 * This is custom drawing view used to do painting on user touch events it it will paint on canvas
 * as per attributes provided to the paint
 *
 *
 * @author [Burhanuddin Rashid](https://github.com/burhanrashid52)
 * @version 0.1.1
 * @since 12/1/18
 */
class DrawingView @JvmOverloads constructor(
    context: Context?,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : ImageView(context, attrs, defStyle) {
    private val drawShapes = Stack<ShapeAndPaint?>()
    private val redoShapes = Stack<ShapeAndPaint?>()
    internal var currentShape: ShapeAndPaint? = null
    var isDrawingEnabled = false
        private set
    private var viewChangeListener: BrushViewChangeListener? = null
    var currentShapeBuilder: ShapeBuilder

    /**
     * Committed strokes, rasterized.
     *
     * TWO REASONS, and the first is the one that motivated it. A plain View
     * carries no drawable, and PostHog's wireframe replay only captures an
     * ImageView's `drawable` -- so brush strokes were invisible in every
     * replay. Not "masked": absent. Verified against the SDK: `getBackground()`
     * is read only through `toRGBColor()`, so a bitmap BACKGROUND would have
     * rendered as a flat colour; it has to be the image drawable.
     *
     * Second, onDraw used to replay the whole Stack every frame, so a long
     * brush session got progressively more expensive to draw.
     *
     * The stack remains the source of truth. This is a cache. A committed
     * stroke is APPENDED to it ([appendToStrokeCache]); it is rebuilt from the
     * whole stack only when an append cannot describe the change -- undo, redo,
     * clear, resize, restore, and a stroke moved in place by adjustCanvas
     * (GAME-1852).
     */
    private var strokeCache: Bitmap? = null
    private var strokeCanvas: Canvas? = null

    /**
     * True between ACTION_DOWN and the stroke ending.
     *
     * Needed because `createShape()` pushes the in-progress shape onto
     * `drawShapes` at ACTION_DOWN, so "the stack" and "what is committed" are
     * not the same thing mid-stroke. While this is true, the cache holds
     * everything EXCEPT `currentShape`, and onDraw paints that shape live on
     * top.
     *
     * A separate flag rather than nulling `currentShape` at stroke end:
     * DrawingViewApiTest reads `currentShape.paint` after drawing to assert
     * brush colour/size/opacity, and nulling it would break 13 tests for a
     * reason unrelated to what they check.
     */
    private var strokeInProgress = false

    /**
     * GAME-1852: set on every shape that enters the stack, so a shape whose
     * geometry changes in place (BrushShape.adjustCanvas, called by the app
     * after a crop or reset) makes the cache rebuild. Without it the cache,
     * which is only APPENDED to on finger-up, would keep the stroke at its old
     * position whenever the crop leaves this view's size unchanged (a resize
     * rebuilds anyway).
     *
     * Holds the view WEAKLY: the app keeps the stroke list in its ViewModel's
     * EditorState, which outlives the Activity on a config change, and a strong
     * capture would leak the view (and the Activity) through every stroke.
     */
    private val geometryListener: () -> Unit = WeakReference(this).let { ref ->
        { ref.get()?.scheduleStrokeCacheRebuild() }
    }

    /**
     * One rebuild per burst of geometry changes. The app adjusts every stroke
     * in a loop, so rebuilding per call would be O(strokes^2) on the main
     * thread -- the cost this ticket removes from finger-up. Posted to the main
     * looper rather than View.post so it runs even while the view is detached,
     * and so a caller on another thread cannot touch the bitmap directly.
     */
    @Volatile
    private var rebuildPosted = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun scheduleStrokeCacheRebuild() {
        if (rebuildPosted) return
        rebuildPosted = true
        mainHandler.post {
            rebuildPosted = false
            rebuildStrokeCache()
        }
    }

    private fun track(shape: ShapeAndPaint?) {
        shape?.shape?.geometryListener = geometryListener
    }

    // eraser parameters
    private var isErasing = false
    var eraserSize = DEFAULT_ERASER_SIZE

    // endregion
    private fun createPaint(): Paint {
        val paint = Paint()
        paint.isAntiAlias = true
        paint.isDither = true
        paint.style = Paint.Style.STROKE
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeCap = Paint.Cap.ROUND
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_OVER)

        // apply shape builder parameters
        currentShapeBuilder?.apply {
            paint.strokeWidth = this.shapeSize
            // 'paint.color' must be called before 'paint.alpha',
            // otherwise 'paint.alpha' value will be overwritten.
            paint.color = this.shapeColor
            shapeOpacity?.also { paint.alpha = it }
        }

        return paint
    }

    private fun createEraserPaint(): Paint {
        val paint = createPaint()
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        // Ported from upstream 76f1b03 ("using eraser size when in erasing mode"): without this,
        // the eraser always erased at createPaint()'s stroke width (from the current shape
        // builder), ignoring whatever eraserSize the user actually selected.
        paint.strokeWidth = eraserSize
        return paint
    }

    private fun setupBrushDrawing() {
        //Caution: This line is to disable hardware acceleration to make eraser feature work properly
        setLayerType(LAYER_TYPE_HARDWARE, null)
        visibility = GONE
        // The stroke cache is a view-sized bitmap set as our image drawable, so
        // FIT_XY blits it 1:1 with no matrix. adjustViewBounds MUST stay false:
        // with it true, ImageView resizes to the drawable's aspect ratio and,
        // combined with onMeasure below, is another way the drawable could drive
        // our bounds. See onMeasure for why that is fatal here (GAME-796).
        scaleType = ScaleType.FIT_XY
        adjustViewBounds = false
        currentShapeBuilder = ShapeBuilder()
    }

    /**
     * Measure exactly as the plain `View` this used to be — NOT as an ImageView.
     *
     * GAME-796: this view sits under four RelativeLayout ALIGN_TOP/BOTTOM/LEFT/
     * RIGHT rules to the photo (PhotoEditorView.setupDrawingView), which resolve
     * its rect to the photo's bounds. `ImageView.onMeasure` instead derives its
     * size from the drawable's intrinsic size, and with our WRAP_CONTENT height
     * and no drawable yet it collapsed the view to **height 0** — measured on
     * device as `onSizeChanged w=1028 h=0`. A zero-height view receives no touch
     * events, so no stroke was ever committed (0.000% export, blank canvas).
     *
     * `getDefaultSize` honours the EXACTLY spec the align rules hand down and
     * ignores the drawable entirely, which is precisely what the superclass
     * `View` did before this became an `ImageView`. Do not delete without an
     * on-device brush check — the JVM/Robolectric suite cannot see this.
     */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            getDefaultSize(suggestedMinimumWidth, widthMeasureSpec),
            getDefaultSize(suggestedMinimumHeight, heightMeasureSpec),
        )
    }

    fun clearAll() {
        drawShapes.clear()
        redoShapes.clear()
        rebuildStrokeCache()
    }

    fun setBrushViewChangeListener(brushViewChangeListener: BrushViewChangeListener?) {
        viewChangeListener = brushViewChangeListener
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        allocateStrokeCache(w, h)
    }

    /**
     * (Re)allocate the cache to match the view, and repopulate it.
     *
     * ARGB_8888 because the eraser composites with PorterDuff.CLEAR and needs a
     * real alpha channel to clear TO. On a surface without one, erasing would
     * paint black rather than remove ink.
     */
    private fun allocateStrokeCache(w: Int, h: Int) {
        if (w <= 0 || h <= 0) {
            strokeCache = null
            strokeCanvas = null
            setImageDrawable(null)
            return
        }
        if (strokeCache?.width == w && strokeCache?.height == h) return

        strokeCache?.recycle()
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        strokeCache = bitmap
        strokeCanvas = Canvas(bitmap)

        // rebuildStrokeCache() re-asserts the drawable via setImageBitmap on
        // every stroke (see its comment) so PostHog re-encodes the wireframe;
        // this initial set just makes the drawable non-null before the first
        // rebuild. onMeasure keeps the resulting requestLayout from resizing us.
        setImageBitmap(bitmap)
        rebuildStrokeCache()
    }

    /**
     * Replay the committed stack into the cache.
     *
     * O(strokes): every stroke is redrawn. Called for the changes an append
     * cannot describe -- undo, redo, clear, resize, restore, and (posted, once
     * per burst) a stroke whose geometry changed in place. NOT on finger-up
     * any more: that redraw ran on the main thread and grew with the stroke
     * count, and it was every editor touch ANR in 90 days (GAME-1852).
     * A committed stroke goes through [appendToStrokeCache] instead.
     */
    @VisibleForTesting
    internal fun rebuildStrokeCache() {
        val canvas = strokeCanvas ?: return
        canvas.drawColor(android.graphics.Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        for (shape in drawShapes) {
            // GAME-1852: covers shapes pushed through the public drawingPath
            // stack too, not only createShape/addRestoredStroke.
            track(shape)
            // Skip the live stroke: it is already on the stack from ACTION_DOWN
            // but is not committed until endShape, and onDraw paints it
            // separately so the user sees it move.
            if (strokeInProgress && shape === currentShape) continue
            shape?.shape?.draw(canvas, shape.paint)
        }
        // Re-assert the drawable, NOT just invalidate(). PostHog's wireframe
        // capture caches an ImageView's base64 by drawable identity and does not
        // re-encode when the SAME bitmap is mutated in place -- so an invalidate()
        // alone leaves the replay holding the blank bitmap this cache was first
        // set with, and the stroke never reaches a replay (measured: the captured
        // DrawingView node was 0% non-transparent while the stroke was on screen).
        // setImageBitmap swaps in a fresh BitmapDrawable, which posthog re-encodes.
        //
        // Safe to do per stroke ONLY because onMeasure ignores the drawable, so
        // the requestLayout this triggers cannot resize us (see onMeasure). That
        // is the invariant the original "set once" comment was protecting; the
        // measurement fix removes the need for it. GAME-796.
        strokeCache?.let { setImageBitmap(it) }
    }

    /**
     * Fold ONE newly committed stroke into the cache, without replaying the rest.
     *
     * GAME-1852. Pixel-identical to [rebuildStrokeCache], not an approximation:
     * a rebuild is "clear, then draw every stroke in stack order onto this one
     * canvas", so when the cache already holds every stroke below [shape] and
     * [shape] is the top of the stack, drawing just [shape] on top performs the
     * exact same sequence of operations on the exact same bitmap. That holds for
     * an eraser stroke too: its PorterDuff.CLEAR acts on the cache's pixels as
     * they are at that point in the sequence, which is precisely what a replay
     * would have handed it. DrawingViewIncrementalCacheTest proves it with real
     * pixels (NATIVE graphics) for paint, eraser, and undo-then-stroke.
     *
     * If [shape] is not the top of the stack, the precondition does not hold
     * (e.g. undo() popped the in-progress stroke mid-gesture), so fall back to a
     * full rebuild rather than guess.
     */
    private fun appendToStrokeCache(shape: ShapeAndPaint) {
        val canvas = strokeCanvas ?: return
        if (drawShapes.isEmpty() || drawShapes.peek() !== shape) {
            rebuildStrokeCache()
            return
        }
        shape.shape.draw(canvas, shape.paint)
        // Same drawable re-assert as rebuildStrokeCache, for the same PostHog
        // reason (see its comment).
        strokeCache?.let { setImageBitmap(it) }
    }

    public override fun onDraw(canvas: Canvas) {
        if (strokeCanvas == null) {
            // No cache yet -- the view has not been sized, so onSizeChanged has
            // not run. Replay the stack directly, exactly as this did before
            // the cache existed.
            //
            // NOT a defensive nicety. Without it an unsized view drops every
            // committed stroke and renders only the live one, because the
            // committed ones live in a bitmap that does not exist. Caught by
            // testCanvasIsDrawingCorrectlyOnDraw, which drives four ACTION_DOWNs
            // at a view that was never laid out and expects four draws.
            for (shape in drawShapes) {
                shape?.shape?.draw(canvas, shape.paint)
            }
            return
        }

        // The committed strokes, as a bitmap. This is what PostHog's wireframe
        // replay can actually see, and it replaces replaying the whole Stack
        // every frame.
        super.onDraw(canvas)

        // The live stroke on top. Still drawn straight onto the view canvas, so
        // an in-progress ERASER stroke composites against the hardware layer
        // set up in setupBrushDrawing() -- which is the reason that layer type
        // exists and why it is left alone.
        if (strokeInProgress) {
            currentShape?.let { it.shape.draw(canvas, it.paint) }
        }
    }

    /**
     * Handle touch event to draw paint on canvas i.e brush drawing
     *
     * @param event points having touch info
     * @return true if handling touch events
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        return if (isDrawingEnabled) {
            val touchX = event.x
            val touchY = event.y
            // GAME-1133: actionMasked, not action, so a pointer index packed into
            // the high byte of a multi-touch event cannot slip past the when.
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> onTouchEventDown(touchX, touchY, event.eventTime)
                MotionEvent.ACTION_MOVE -> {
                    // GAME-1133: a single ACTION_MOVE carries every touch sample
                    // coalesced since the last one -- getHistorical*(0..historySize)
                    // then the final event.x/y. Reading only event.x/y drew the
                    // stroke from synthetic end points and discarded the real
                    // curve between them (jagged fast strokes; 35% of brush
                    // entries producing nothing). Feed the history in order first.
                    // GAME-1132: carry each sample's event time too, so the stroke
                    // can taper by draw speed (getHistoricalEventTime for the
                    // coalesced samples, eventTime for the final one).
                    for (i in 0 until event.historySize) {
                        onTouchEventMove(
                            event.getHistoricalX(i),
                            event.getHistoricalY(i),
                            event.getHistoricalEventTime(i),
                        )
                    }
                    onTouchEventMove(touchX, touchY, event.eventTime)
                }
                MotionEvent.ACTION_UP -> onTouchEventUp(touchX, touchY)
                // GAME-1133: a cancelled gesture (a parent intercepting, a palm
                // rejection) previously left the in-progress stroke un-finished on
                // the stack. Close it out like an UP so it is a complete shape.
                MotionEvent.ACTION_CANCEL -> onTouchEventUp(touchX, touchY)
            }
            invalidate()
            true
        } else {
            false
        }
    }

    private fun onTouchEventDown(touchX: Float, touchY: Float, eventTime: Long) {
        createShape()
        currentShape?.shape?.apply {
            startShape(touchX, touchY)
            // GAME-1035: record the raw point so the stroke can later be serialized
            // and replayed as an editable vector (see addRestoredStroke). Recorded
            // here, not inside the shape, so drawing behaviour is untouched.
            // GAME-1132: with its event time, for velocity-based width.
            recordPoint(touchX, touchY, eventTime)
        }
    }

    private fun onTouchEventMove(touchX: Float, touchY: Float, eventTime: Long) {
        currentShape?.shape?.apply {
            moveShape(touchX, touchY)
            recordPoint(touchX, touchY, eventTime)
        }
    }

    private fun onTouchEventUp(touchX: Float, touchY: Float) {
        currentShape?.apply {
            shape.stopShape()
            endShape(touchX, touchY)
        }
    }

    private fun createShape() {
        // GAME-1852: an ACTION_DOWN while a stroke is still open (a DOWN with no
        // UP/CANCEL before it) orphans the open stroke on the stack, below the new
        // one. The full rebuild used to sweep it into the cache at the next
        // finger-up; with appends it must go in now, while it is still the top of
        // the stack, or it would never reach the cache.
        if (strokeInProgress) {
            strokeInProgress = false
            currentShape?.let { appendToStrokeCache(it) }
        }
        var paint = createPaint()
        var shape: AbstractShape = BrushShape()

        if (isErasing) {
            paint = createEraserPaint()
        } else {
            when (val shapeType = currentShapeBuilder.shapeType) {
                ShapeType.Oval -> {
                    shape = OvalShape()
                }
                ShapeType.Brush -> {
                    shape = BrushShape()
                }
                ShapeType.Rectangle -> {
                    shape = RectangleShape()
                }
                ShapeType.Line -> {
                    shape = LineShape(context)
                }
                is ShapeType.Arrow -> {
                    shape = LineShape(context, shapeType.pointerLocation)
                }
            }
        }

        // GAME-1035: tag the shape as an eraser so a restore can rebuild its CLEAR
        // paint (a Paint's xfermode mode is not reliably readable back).
        shape.isEraser = isErasing

        // GAME-1210: stamp the current taper mode onto the new brush stroke so it
        // keeps that look even if the toggle flips later.
        (shape as? BrushShape)?.taperEnabled = currentShapeBuilder.taperEnabled

        currentShape = ShapeAndPaint(shape, paint)
        track(currentShape)
        drawShapes.push(currentShape)
        strokeInProgress = true
        viewChangeListener?.onStartDrawing()
    }

    /**
     * GAME-1035: re-add a previously captured stroke as an EDITABLE vector shape.
     *
     * A restored draft's brush strokes come back as real stack entries -- undoable,
     * erasable, extendable, and picked up by the normal export path -- not a flat
     * raster. The recorded [points] are replayed through the same
     * startShape/moveShape/stopShape the touch handler uses, so the reconstructed
     * Path (including its TOUCH_TOLERANCE thinning) is identical to the original.
     * The paint is rebuilt from primitives exactly as createPaint/createEraserPaint
     * do. [offsetX]/[offsetY]/[canvasScaleX]/[canvasScaleY] restore a BrushShape's
     * post-crop adjustCanvas transform (identity for a stroke drawn on an uncropped
     * image); they are ignored for non-brush shapes, which have no such transform.
     */
    fun addRestoredStroke(
        points: List<PointF>,
        color: Int,
        strokeWidth: Float,
        shapeName: String,
        isEraser: Boolean,
        offsetX: Float = 0f,
        offsetY: Float = 0f,
        canvasScaleX: Float = 1f,
        canvasScaleY: Float = 1f,
        // GAME-1132: per-point event times, parallel to [points], so a restored
        // brush stroke re-derives its velocity taper. Empty (or shorter) for a
        // draft written before times were recorded -- recordPoint then stores 0
        // and BrushShape falls back to constant width.
        times: List<Long> = emptyList(),
        // GAME-1210: whether this stroke tapered by draw speed when it was drawn.
        // Defaults true (a draft written before the toggle tapered); restored
        // per-stroke so an old stroke keeps its look regardless of the mode.
        taperEnabled: Boolean = true,
    ) {
        // THE RECONSTRUCTION LIVES IN StrokeFactory, and this delegates to it.
        //
        // Not a tidy-up: it is the whole point. Every line above the push used to
        // live here, needing nothing from the View but `context` -- so the only
        // thing standing between a headless caller and an editable stroke was that
        // this is an instance method on a View. The app's durable HD-export worker
        // is headless, could not call it, and therefore could not render vector
        // brushes at all; it composited a pre-flattened raster instead, whose size
        // was chosen at spool time and silently capped every exported brush's
        // resolution (thug-life GAME-1279 / GAME-1310).
        //
        // Delegating rather than copying is what keeps the editor's strokes and the
        // worker's strokes provably identical. A second implementation would be a
        // second place for them to diverge, and the divergence would be invisible:
        // both would look correct in isolation and produce a plausible stroke.
        val restored = StrokeFactory.restore(
            context = context,
            points = points,
            color = color,
            strokeWidth = strokeWidth,
            shapeName = shapeName,
            isEraser = isEraser,
            offsetX = offsetX,
            offsetY = offsetY,
            canvasScaleX = canvasScaleX,
            canvasScaleY = canvasScaleY,
            times = times,
            taperEnabled = taperEnabled,
        ) ?: return

        track(restored)
        drawShapes.push(restored)
        rebuildStrokeCache()
    }

    /**
     * GAME-1035: register this DrawingView in the editor's view-state ONCE after a
     * bulk [addRestoredStroke] restore, so the strokes are discoverable by the host
     * (findDrawingView / export read the view-state, not the canvas children).
     *
     * Fires the SAME onViewAdd that a live stroke's endShape does -- the addAddedView
     * half -- but only once (a per-stroke notify would spam the host's add listener),
     * and deliberately NOT onStopDrawing: restored strokes are already-present draft
     * content, not fresh edits, so they stay off the global undo/redo history. The
     * DrawingView's own [undo]/[redo] still edit them. No-op if nothing was restored.
     */
    fun commitRestoredStrokes() {
        if (drawShapes.isNotEmpty()) {
            viewChangeListener?.onViewAdd(this)
        }
    }

    private fun endShape(touchX: Float, touchY: Float) {
        val wasInProgress = strokeInProgress
        strokeInProgress = false
        val shape = currentShape
        if (shape?.shape?.hasBeenTapped() == true) {
            // just a tap, this is not a shape, so remove it
            drawShapes.remove(shape)
            //handleTap(touchX, touchY);
            // The cache never held it (onDraw painted it live), so it is
            // already right; just re-assert the drawable as before.
            strokeCache?.let { setImageBitmap(it) }
        } else if (shape != null && wasInProgress) {
            // Committed: fold it into the cache before notifying anyone, so a
            // listener that reads the view mid-callback sees a consistent state.
            // GAME-1852: append ONLY this stroke. The full rebuild here redrew
            // every stroke on the main thread on every finger-up.
            appendToStrokeCache(shape)
        } else {
            // A second UP/CANCEL for a stroke already committed: appending it
            // again would double-draw it (visible on a translucent stroke), so
            // replay the stack, which is what this always did.
            rebuildStrokeCache()
        }
        viewChangeListener?.apply {
            onStopDrawing()
            // Ported from upstream 8648773 ("Fix redo logic"): a new stroke starts a new branch
            // of history, same reasoning as GraphicManager.addView()'s companion fix in this
            // same commit -- a previously-undone stroke sitting on this DrawingView's OWN redo
            // stack should no longer be redoable once a new stroke has been drawn.
            if (redoShapes.isNotEmpty()) {
                redoShapes.clear()
            }
            onViewAdd(this@DrawingView)
        }
    }

    fun undo(): Boolean {
        if (!drawShapes.empty()) {
            redoShapes.push(drawShapes.pop())
            rebuildStrokeCache()
        }
        viewChangeListener?.onViewRemoved(this)
        return !drawShapes.empty()
    }

    fun redo(): Boolean {
        if (!redoShapes.empty()) {
            drawShapes.push(redoShapes.pop())
            rebuildStrokeCache()
        }
        viewChangeListener?.onViewAdd(this)
        return !redoShapes.empty()
    }

    // region eraser
    fun brushEraser() {
        isDrawingEnabled = true
        isErasing = true
    }

    // endregion
    // region Setters/Getters

    fun enableDrawing(brushDrawMode: Boolean) {
        isDrawingEnabled = brushDrawMode
        isErasing = !brushDrawMode
        if (brushDrawMode) {
            visibility = VISIBLE
        }
    }

    // endregion
    val drawingPath: Pair<Stack<ShapeAndPaint?>, Stack<ShapeAndPaint?>>
        get() = Pair(drawShapes, redoShapes)

    companion object {
        const val DEFAULT_ERASER_SIZE = 50.0f
    }

    // region constructors
    init {
        //Caution: This line is to disable hardware acceleration to make eraser feature work properly
        setLayerType(LAYER_TYPE_HARDWARE, null)
        visibility = GONE
        currentShapeBuilder = ShapeBuilder()
        setupBrushDrawing()
    }
}