package com.flocmedia.photoeditor

import android.view.MotionEvent
import android.view.View

/**
 * @author [Burhanuddin Rashid](https://github.com/burhanrashid52)
 * @version 0.1.1
 * @since 18/01/2017
 *
 *
 * This are the callbacks when any changes happens while editing the photo to make and custimization
 * on client side
 *
 */
interface OnPhotoEditorListener {
    /**
     * When user long press the existing text this event will trigger implying that user want to
     * edit the current [android.widget.TextView]
     *
     * @param rootView  view on which the long press occurs
     * @param text      current text set on the view
     * @param colorCode current color value set on view
     */
    fun onEditTextChangeListener(rootView: View, text: String, colorCode: Int)

    /**
     * This is a callback when user adds any view on the [PhotoEditorView] it can be
     * brush,text or sticker i.e bitmap on parent view
     *
     * @param viewType           enum which define type of view is added
     * @param numberOfAddedViews number of views currently added
     * @see ViewType
     */
    fun onAddViewListener(viewType: ViewType, numberOfAddedViews: Int)

    /**
     * This is a callback when user remove any view on the [PhotoEditorView] it happens when usually
     * undo and redo happens or text is removed
     *
     * @param viewType           enum which define type of view is added
     * @param numberOfAddedViews number of views currently added
     */
    fun onRemoveViewListener(viewType: ViewType, numberOfAddedViews: Int)

    /**
     * A callback when user start dragging a view which can be
     * any of [ViewType]
     *
     * @param viewType enum which define type of view is added
     */
    fun onStartViewChangeListener(viewType: ViewType)

    /**
     * A callback when a user moves *or* resizes a view which can be
     * any of [ViewType]
     *
     * @param viewType
     */
    fun onMoveViewChangeListener(viewType: ViewType?)

    /**
     * A callback when user stop/up touching a view which can be
     * any of [ViewType]
     *
     * @param viewType enum which define type of view is added
     */
    fun onStopViewChangeListener(viewType: ViewType)

    /**
     * A callback when the user touches the screen.
     *
     * @param event the MotionEvent associated to the touch.
     */
    fun onTouchSourceImage(event: MotionEvent)

    /**
     * This is a callback when user rotates all views on the [PhotoEditorView]
     *
     */
    fun onRotateViewListener()

    /**
     * This is a callback when user mirrors any view on the [PhotoEditorView]
     */
    fun onMirrorViewListener()

    /**
     * A callback when user focusing on a sticker
     *
     * @param view view that is in focus.
     */
    fun onInFocusViewChangeListener(view: View?)

    fun onGraphicActionDown(view: View)

    /**
     * A tap (one finger, down then up, no drag past touch slop) that hit no graphic: it landed
     * on empty canvas, or passed through a transparent pixel of an unselected sticker. Fires on
     * ACTION_UP. Not called for taps on a graphic (including the selected graphic's handles and
     * grab area), drags, or multi-finger gestures. Note [onGraphicActionDown] can fire for a tap
     * that this reports as no-hit only for the selected graphic's own touch, never for a
     * pass-through. Default no-op so existing implementers compile unchanged.
     */
    fun onCanvasTapNoHit() {}

    fun onGraphicMove(
        view: View,
        info: MultiTouchListener.TransformInfo,
        editorScaleX: Float,
        initialStickerScale: Float,
        initialStickerRotation: Float
    )
}