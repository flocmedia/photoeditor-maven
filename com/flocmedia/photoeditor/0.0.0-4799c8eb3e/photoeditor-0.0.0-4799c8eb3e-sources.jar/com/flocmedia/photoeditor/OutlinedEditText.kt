package com.flocmedia.photoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import kotlin.math.ceil

/**
 * The text-entry field in the add/edit text dialog, drawing the same glyph
 * outline the placed graphic will have.
 *
 * This exists because the preview is an [android.widget.EditText] and the thing
 * it is previewing is a `TextView` inside the photo editor library, so they
 * cannot be the same class. Every number that decides what the outline LOOKS
 * like is taken from the library's [TextOutlines] rather than restated here --
 * the stroke width, the contrast rule, the reserved inset. A preview that
 * computes its own would drift from the real thing silently, and the user would
 * only find out after tapping Done.
 *
 * See [OutlinedTextView] for the shared mechanics. This class MUST keep its
 * outline machinery in lock-step with that one, because a placed graphic is an
 * [OutlinedTextView] and this field is the promise of what it will look like:
 *  - the two-pass draw guards its colour swap behind [fillColourDuringDraw] and
 *    a lock, because the editor draws these views on a background thread
 *    ([EditorTransparentCache], every time the dialog opens) and a race that
 *    reads `currentTextColor` mid-swap resolves the outline to the SAME colour
 *    as the text and it vanishes (GAME-873);
 *  - [syncOutlinePadding] ADDS the inset to the background drawable's own
 *    padding instead of replacing it, so a speech-bubble nine-patch's
 *    content-padding still centres the text in the bubble (GAME-826).
 * The one thing this adds over [OutlinedTextView] is suppressing the selection
 * highlight on the fill pass; an EditText paints it from a separate paint the
 * stroke/fill split does not touch, so a two-pass draw would paint it twice.
 */
class OutlinedEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = androidx.appcompat.R.attr.editTextStyle,
) : AppCompatEditText(context, attrs, defStyleAttr) {

    var isTextOutlineEnabled: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            requestLayout()
            invalidate()
        }

    /**
     * The thread currently inside [onDraw]'s two-pass block, or null. A thread
     * reference rather than a shared Boolean for the reason spelled out in
     * [OutlinedTextView]: a background draw must not swallow the main thread's
     * invalidate/requestLayout.
     */
    @Volatile
    private var outlineDrawingThread: Thread? = null

    private var isDrawingOutline: Boolean
        get() = outlineDrawingThread === Thread.currentThread()
        set(value) {
            outlineDrawingThread = if (value) Thread.currentThread() else null
        }

    /** Set only for the duration of [onDraw]; see [fillColour]. */
    private var fillColourDuringDraw: Int? = null

    /**
     * The text's FILL colour, correct even while [onDraw] is mid-pass. The
     * stroke pass installs the outline colour through setTextColor (the only
     * public door into the paint), so `currentTextColor` cannot be trusted here.
     */
    private val fillColour: Int
        get() = fillColourDuringDraw ?: currentTextColor

    /** Serialises the two-pass draw against the background-thread cache draw. */
    private val outlineDrawLock = Any()

    /** Scratch for reading the background drawable's padding in [onMeasure]. */
    private val tempPaddingRect = Rect()

    /** Scratch for measuring a line's glyph ink bounds in [horizontalInkOverhang]. */
    private val tempInkBounds = Rect()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        syncOutlinePadding()
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    /**
     * Reserves room for the stroke on all four sides, ON TOP of the background
     * drawable's own padding and the glyph ink overhang. Mirrors
     * [OutlinedTextView.syncOutlinePadding]; see the notes there.
     *
     * GAME-826: ADD the inset to the background's padding, never replace it, or
     * a speech-bubble nine-patch's content padding is clobbered and the text
     * spills off-centre onto the tail instead of sitting in the bubble body.
     */
    private fun syncOutlinePadding() {
        val inset = if (isTextOutlineEnabled) TextOutlines.insetPx(paint) else 0
        val bg = tempPaddingRect
        val hasBgPadding = background?.getPadding(bg) == true
        val (inkLeft, inkRight) = horizontalInkOverhang()
        val l = (if (hasBgPadding) bg.left else 0) + inset + inkLeft
        val t = (if (hasBgPadding) bg.top else 0) + inset
        val r = (if (hasBgPadding) bg.right else 0) + inset + inkRight
        val b = (if (hasBgPadding) bg.bottom else 0) + inset
        if (l != paddingLeft || t != paddingTop || r != paddingRight || b != paddingBottom) {
            setPadding(l, t, r, b)
        }
    }

    /**
     * How far the glyph ink of the current text spills past its advance-width
     * box on the left and right, in pixels (never negative). Mirrors
     * [OutlinedTextView.horizontalInkOverhang].
     */
    private fun horizontalInkOverhang(): Pair<Int, Int> {
        val content = text?.toString()
        if (content.isNullOrEmpty()) return 0 to 0
        var left = 0
        var right = 0
        for (line in content.split('\n')) {
            if (line.isEmpty()) continue
            paint.getTextBounds(line, 0, line.length, tempInkBounds)
            val leftPx = ceil(maxOf(0f, -tempInkBounds.left.toFloat())).toInt()
            val rightPx = ceil(maxOf(0f, tempInkBounds.right - paint.measureText(line))).toInt()
            left = maxOf(left, leftPx)
            right = maxOf(right, rightPx)
        }
        return left to right
    }

    /**
     * The colour this field will stroke with, for its current text colour.
     * Reads [fillColour], NOT `currentTextColor` -- deriving from the property
     * the stroke pass mutates is what made the outline invisible (GAME-873).
     */
    fun resolveOutlineColour(): Int =
        TextOutlines.contrastingOutlineColour(fillColour)

    override fun onDraw(canvas: Canvas) {
        if (!isTextOutlineEnabled || length() == 0) {
            super.onDraw(canvas)
            return
        }

        // An EditText paints its selection highlight from a SEPARATE paint,
        // which the stroke/fill split does not touch -- so a two-pass draw
        // paints the highlight twice, and two coats of a translucent colour
        // read as a darker one. Only the fill pass needs it.
        val savedHighlight = highlightColor

        synchronized(outlineDrawLock) {
            isDrawingOutline = true
            // Capture the fill FIRST: resolveOutlineColour reads it, and so does
            // anything on another thread asking this view its colour mid-draw.
            fillColourDuringDraw = currentTextColor
            val outlineColour = resolveOutlineColour()
            try {
                val saved = GlyphOutlinePainter.beginStrokePass(this, outlineColour)
                try {
                    highlightColor = Color.TRANSPARENT
                    super.onDraw(canvas)

                    GlyphOutlinePainter.switchToFillPass(this, saved)
                    highlightColor = savedHighlight
                    super.onDraw(canvas)
                } finally {
                    GlyphOutlinePainter.restore(this, saved)
                    highlightColor = savedHighlight
                }
            } finally {
                isDrawingOutline = false
                fillColourDuringDraw = null
            }
        }
    }

    override fun invalidate() {
        if (!isDrawingOutline) super.invalidate()
    }

    override fun invalidate(dirty: Rect) {
        if (!isDrawingOutline) super.invalidate(dirty)
    }

    override fun invalidate(l: Int, t: Int, r: Int, b: Int) {
        if (!isDrawingOutline) super.invalidate(l, t, r, b)
    }

    override fun postInvalidate() {
        if (!isDrawingOutline) super.postInvalidate()
    }

    override fun postInvalidate(left: Int, top: Int, right: Int, bottom: Int) {
        if (!isDrawingOutline) super.postInvalidate(left, top, right, bottom)
    }
}
