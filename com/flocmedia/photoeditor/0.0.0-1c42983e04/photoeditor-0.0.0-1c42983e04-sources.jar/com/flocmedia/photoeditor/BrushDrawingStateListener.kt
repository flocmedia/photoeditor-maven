package com.flocmedia.photoeditor

/**
 * Created by Burhanuddin Rashid on 17/05/21.
 *
 * @author <https:></https:>//github.com/burhanrashid52>
 */
class BrushDrawingStateListener internal constructor(
    private val mPhotoEditorView: PhotoEditorView,
    private val mViewState: PhotoEditorViewState
) : BrushViewChangeListener {
    private var mOnPhotoEditorListener: OnPhotoEditorListener? = null

    fun setOnPhotoEditorListener(onPhotoEditorListener: OnPhotoEditorListener?) {
        mOnPhotoEditorListener = onPhotoEditorListener
    }

    override fun onViewAdd(drawingView: DrawingView) {
        mViewState.addAddedView(drawingView)
        mOnPhotoEditorListener?.onAddViewListener(
            ViewType.BRUSH_DRAWING,
            mViewState.addedViewsCount
        )
    }

    override fun onViewRemoved(drawingView: DrawingView) {
        if (mViewState.addedViewsCount > 0) {
            val removeView = mViewState.removeAddedView(
                mViewState.addedViewsCount - 1
            )
            if (removeView !is DrawingView) {
                mPhotoEditorView.removeView(removeView)
            }
            mViewState.pushRedoView(removeView)
        }
        mOnPhotoEditorListener?.onRemoveViewListener(
            ViewType.BRUSH_DRAWING,
            mViewState.addedViewsCount
        )
    }

    override fun onStartDrawing() {
        mOnPhotoEditorListener?.onStartViewChangeListener(ViewType.BRUSH_DRAWING)

    }

    override fun onStopDrawing() {
        // A finished stroke is one history entry, in the SAME ordered stack as
        // stickers, moves and deletes. Previously strokes lived only inside the
        // DrawingView's private list, reachable only through a special case at
        // the top of the added-views stack in GraphicManager.undoView -- which
        // is why that special case needed two upstream fixes to get "is there
        // anything left to undo?" right. It had to reason about two stacks at
        // once; there is one now.
        //
        // Read from the view rather than from a field set in onViewAdd. That
        // ordering does not hold: DrawingView.endShape calls onStopDrawing
        // BEFORE onViewAdd, so on the very first stroke of a session such a
        // field is still null and the stroke silently records nothing -- and
        // every stroke after it lands one entry out of step. PhotoEditorView
        // owns its DrawingView for the whole of its life, so there is nothing
        // to track.
        mViewState.pushOperation(BrushStrokeOperation(mPhotoEditorView.drawingView))

        mOnPhotoEditorListener?.onStopViewChangeListener(ViewType.BRUSH_DRAWING)
    }
}