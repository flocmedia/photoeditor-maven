package com.flocmedia.photoeditor

import android.view.MotionEvent

/**
 * Decides whether a touch stream was a TAP: one finger, down then up, never past the slop.
 *
 * Used to report "this tap hit no graphic" ([OnPhotoEditorListener.onCanvasTapNoHit]). It only
 * ever sees streams that no graphic consumed, so a tap that survives it is by definition a
 * no-hit tap. It never consumes or alters events.
 */
internal class TapTracker(private val touchSlop: Float) {
    private var downX = 0f
    private var downY = 0f
    private var candidate = false

    /** Feed every event of the stream; returns true exactly once, on the UP that ends a tap. */
    fun onEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                candidate = true
                downX = event.rawX
                downY = event.rawY
            }
            MotionEvent.ACTION_MOVE -> if (candidate &&
                Math.hypot((event.rawX - downX).toDouble(), (event.rawY - downY).toDouble()) > touchSlop
            ) candidate = false
            // A second finger is a pinch/rotate, not a tap.
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL -> candidate = false
            MotionEvent.ACTION_UP -> {
                val tap = candidate
                candidate = false
                return tap
            }
        }
        return false
    }
}
