package com.flocmedia.photoeditor.shape

/**
 * GAME-1132: maps a brush stroke's local draw SPEED to a stroke width, so a
 * stroke tapers like a real pen -- thinner where the hand moved fast, thicker
 * where it slowed or paused.
 *
 * This is the pressure SUBSTITUTE the epic settled on: touch pressure is a
 * broken instrument on capacitive panels (AOSP hard-codes it to 1.0 and you
 * cannot detect that case), whereas velocity is free on 100% of devices from
 * the per-point event times [AbstractShape.pointTimes] already records.
 *
 * Pure and side-effect free so it is unit-testable off-device (the on-device
 * gates can only see that a stroke draws at all, not its width curve).
 */
object VelocityWidth {

    /** Speed (px/ms) at which the stroke draws at its nominal [baseWidth]. */
    private const val REF_VELOCITY = 2.0f

    /** Slowest strokes are at most this multiple of the base width. */
    private const val MAX_FACTOR = 1.6f

    /** Fastest strokes are at least this multiple of the base width. */
    private const val MIN_FACTOR = 0.6f

    /**
     * Exponential-moving-average weight for the new segment's width. Damps the
     * width jitter that raw per-segment velocity would produce (touch sampling
     * is noisy) without lagging the taper. 1.0 = no smoothing.
     */
    private const val EMA_ALPHA = 0.5f

    /**
     * The width for a segment drawn at [velocityPxPerMs], eased from
     * [prevWidth] (the previous segment's width, or [baseWidth] for the first).
     *
     * Slower than [REF_VELOCITY] widens toward [MAX_FACTOR]*base; faster narrows
     * toward [MIN_FACTOR]*base. Velocity 0 (no time base, or a pause) yields the
     * widest allowed width, so a stroke with no recorded times decays to a
     * constant [baseWidth]*[MAX_FACTOR]-bounded line -- callers pass a
     * degenerate path (see BrushShape) rather than relying on that.
     */
    fun widthFor(baseWidth: Float, velocityPxPerMs: Float, prevWidth: Float): Float {
        val v = velocityPxPerMs.coerceAtLeast(0f)
        // Linear in velocity, pinned so v=0 -> MAX_FACTOR and v=REF_VELOCITY ->
        // exactly the nominal 1.0x, clamped to [MIN_FACTOR, MAX_FACTOR].
        val factor = (MAX_FACTOR - (MAX_FACTOR - 1f) * (v / REF_VELOCITY))
            .coerceIn(MIN_FACTOR, MAX_FACTOR)
        val raw = baseWidth * factor
        return EMA_ALPHA * raw + (1f - EMA_ALPHA) * prevWidth
    }
}
