package com.flocmedia.photoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Draws the transient alignment guide lines during a snap drag (GAME-702). Sits
 * on top of the canvas, full-bleed, in the same coordinate space as the graphics
 * (both are children of `canvasLayout`), so a guide at canvas-x `gx` draws at
 * `gx`.
 *
 * It holds at most one vertical and one horizontal line and only has content
 * while a drag is snapping -- [MultiTouchListener] calls [clear] on
 * ACTION_UP/CANCEL, so the overlay is empty whenever the editor is captured for
 * export and never appears in the saved image. Not clickable, so it never eats a
 * touch meant for a graphic beneath it.
 */
class AlignmentGuideOverlay(context: Context) : View(context) {

    private var guideX: Float? = null
    private var guideY: Float? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF00E5FF") // bright cyan, reads over most photos
        strokeWidth = SnapGuides.strokeWidthPx(resources)
        style = Paint.Style.STROKE
    }

    /** Show these guide lines (null on an axis = no line there). No-op if unchanged. */
    fun show(x: Float?, y: Float?) {
        if (x == guideX && y == guideY) return
        guideX = x
        guideY = y
        invalidate()
    }

    fun clear() = show(null, null)

    override fun onDraw(canvas: Canvas) {
        guideX?.let { canvas.drawLine(it, 0f, it, height.toFloat(), paint) }
        guideY?.let { canvas.drawLine(0f, it, width.toFloat(), it, paint) }
    }
}
