package com.flocmedia.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.view.View
import com.flocmedia.photoeditor.BitmapUtil.removeTransparency
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Created by Burhanuddin Rashid on 18/05/21.
 *
 * @author <https:></https:>//github.com/burhanrashid52>
 */
internal class PhotoSaverTask(
    private val photoEditorView: PhotoEditorView,
    private val boxHelper: BoxHelper,
    private var saveSettings: SaveSettings
) {

    private val drawingView: DrawingView = photoEditorView.drawingView

    private fun onBeforeSaveImage() {
        boxHelper.clearHelperBox()
        drawingView.destroyDrawingCache()
    }

    suspend fun saveImageAsBitmap(): Bitmap? {
        onBeforeSaveImage()
        val bitmap = buildBitmap()
        if (saveSettings.isClearViewsEnabled) {
            boxHelper.clearAllViews(drawingView)
        }
        return bitmap
    }

    suspend fun saveImageAsFile(imagePath: String): SaveFileResult {
        onBeforeSaveImage()
        val capturedBitmap = buildBitmap()
            ?: return SaveFileResult.Failure(IOException("Failed to load the bitmap"))

        val result = withContext(Dispatchers.IO) {
            val file = File(imagePath)
            try {
                photoEditorView.context.contentResolver.openOutputStream(
                    Uri.fromFile(file)
                )?.use { outputStream ->
                    capturedBitmap.compress(
                        saveSettings.compressFormat,
                        saveSettings.compressQuality,
                        outputStream
                    )
                    outputStream.flush()
                    outputStream.close()
                }
                // Log.d(TAG, "Filed Saved Successfully")
                SaveFileResult.Success
            } catch (e: IOException) {
                SaveFileResult.Failure(e)
            }
        }

        if (result is SaveFileResult.Success) {
            // Clear all views if it's enabled in save settings
            if (saveSettings.isClearViewsEnabled) {
                boxHelper.clearAllViews(drawingView)
            }
        }

        return result
    }

    private suspend fun buildBitmap(): Bitmap? {
        // captureView() touches the View hierarchy (View.draw()), so it stays
        // on whatever dispatcher the caller is already on (Main). Everything
        // after that is plain bitmap/pixel-array work with no View access, so
        // it does not need to be on Main -- removeTransparency() in particular
        // is a manual four-pass pixel scan over the full captured bitmap
        // (getPixels/setPixels plus a per-pixel bounding-box search), which
        // ran on Main for every export before this change.
        val captured = captureView(photoEditorView)
        return if (saveSettings.isTransparencyEnabled) {
            withContext(Dispatchers.Default) {
                removeTransparency(captured)
            }
        } else {
            captured
        }
    }

    private fun captureView(view: View): Bitmap {
        val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)
        return bitmap
    }

    companion object {
        const val TAG = "PhotoSaverTask"
    }
}