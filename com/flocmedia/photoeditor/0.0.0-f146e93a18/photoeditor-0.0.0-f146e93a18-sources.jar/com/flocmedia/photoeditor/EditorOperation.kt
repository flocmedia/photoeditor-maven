package com.flocmedia.photoeditor

import android.graphics.Typeface
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * One reversible thing the user did.
 *
 * WHY THIS EXISTS. Undo used to be a stack of *views*, not actions, and that
 * shape cannot express most of what a user does. It could only ever mean "take
 * the last added view off the canvas", so:
 *
 *  * moving, resizing or rotating a sticker left no trace at all -- undo would
 *    silently delete the sticker you had just nudged;
 *  * deleting was not undoable. The two delete paths did not even agree with
 *    each other: [GraphicManager.removeView] (the X button on a graphic) pushed
 *    the view onto the REDO stack, so a delete was reversed by pressing Redo,
 *    while `PhotoEditorImpl.removeInFocusView` (the editor's Delete control)
 *    recorded nothing whatsoever and lost the view for good;
 *  * brush strokes worked only through a special case inside `undoView`, which
 *    had already needed two upstream fixes to stop it reporting the wrong
 *    "anything left to undo?" answer.
 *
 * Modelling the ACTION rather than the view makes each of those a plain
 * implementation of this interface, and makes the ordering between them
 * automatic.
 *
 * The live scene graph stays where it was: [PhotoEditorViewState.addedViews] is
 * still what is currently on the canvas, and is what save/export read. This
 * interface owns *history*, which is a different thing and was previously
 * conflated with it.
 *
 * ## Implementing this from outside the library
 *
 * Public because a good deal of what the user does to a graphic is implemented
 * by the app, not here -- opacity, send-to-back and the stretch seek bars all
 * live in thug-life-app, and two of them (stretch especially) reach for app
 * resources and helpers that have no business being moved across this boundary.
 * Rather than drag that code in, the app describes its own actions and hands
 * them over via [PhotoEditor.recordOperation]; ordering between library actions
 * and app actions then falls out of the single shared stack.
 *
 * Three things an implementation has to honour:
 *
 *  1. **[undo] and [redo] must be exact inverses.** They can be called any
 *     number of times, alternately, in any order the user's taps produce.
 *  2. **Capture the "before" state BEFORE mutating anything.** By the time
 *     [undo] runs, the value it needs to restore is long gone; snapshot it when
 *     the operation is constructed, not when it is undone.
 *  3. **Record the finished action, not each step of it.** A seek bar emits a
 *     value per pixel of travel. Record once when the gesture ends
 *     (`onStopTrackingTouch`), exactly as a drag records once on finger-up --
 *     otherwise one adjustment costs the user fifty taps of undo.
 *
 * Calls to [PhotoEditor.recordOperation] made *during* an undo or redo are
 * ignored, so an implementation is free to reuse the ordinary app code path
 * that records -- replaying history is not itself a new action.
 */
interface EditorOperation {
    /** Puts the editor back the way it was before this operation. */
    fun undo()

    /** Re-applies the operation after an [undo]. */
    fun redo()
}

/**
 * A sticker, text or emoji was added to the canvas.
 *
 * Restores at [index] rather than appending, because the index IS the layer
 * order -- appending an undone-then-redone view would silently move it to the
 * front, which is a different picture from the one the user had.
 */
internal class AddViewOperation(
    private val view: View,
    private val canvasView: ViewGroup,
    private val viewState: PhotoEditorViewState,
    private val index: Int,
    private val onChanged: (added: Boolean, view: View) -> Unit,
) : EditorOperation {

    override fun undo() {
        canvasView.removeView(view)
        viewState.removeAddedView(view)
        onChanged(false, view)
    }

    override fun redo() {
        canvasView.addView(view)
        viewState.addAddedView(view, index)
        onChanged(true, view)
    }
}

/**
 * A sticker, text or emoji was deleted.
 *
 * Exactly [AddViewOperation] inverted, with one addition that is easy to miss
 * and produces a baffling bug: the multi-touch listener has to be put back too.
 * `removeInFocusView` drops the view's entry from
 * [PhotoEditorViewState.multiTouchListenerByView], so a view restored without
 * it reappears in the right place, at the right size, and cannot be dragged.
 */
internal class DeleteViewOperation(
    private val view: View,
    private val canvasView: ViewGroup,
    private val viewState: PhotoEditorViewState,
    private val index: Int,
    private val touchListener: MultiTouchListener?,
    private val onChanged: (added: Boolean, view: View) -> Unit,
) : EditorOperation {

    override fun undo() {
        canvasView.addView(view)
        viewState.addAddedView(view, index)
        touchListener?.let { viewState.multiTouchListenerByView[view] = it }
        onChanged(true, view)
    }

    override fun redo() {
        canvasView.removeView(view)
        viewState.removeAddedView(view)
        viewState.multiTouchListenerByView.remove(view)
        onChanged(false, view)
    }
}

/**
 * Where a graphic sat, and how big it was, at one instant.
 *
 * Deliberately a value snapshot of the view's own properties rather than a
 * delta. A delta would have to be inverted exactly, and rotation combined with
 * non-uniform scale does not invert cleanly enough to trust over a long history.
 *
 * SIZE IS IN HERE, and it is not decoration. A pinch does not resize anything in
 * this library: [MultiTouchListener]'s scale gesture hands off to
 * [OnPhotoEditorListener.onGraphicMove], and thug-life-app's implementation
 * resizes an image sticker by writing `layoutParams.width/height` on the root
 * view and a text sticker by calling `setTextSize`. Neither touches scaleX or
 * scaleY, so a snapshot of position and scale alone sees a resize as nothing at
 * all.
 *
 * Which would be a plain gap, except that the same app code re-centres the
 * graphic afterwards, so it DOES move x and y. Snapshotting position without
 * size therefore recorded an entry whose only content was the side effect --
 * undo shoved the sticker back to where it started and left it at its new size.
 * A partial undo reads as a broken one.
 *
 * The root view is the view the gesture already brackets, so capturing this
 * costs nothing extra and keeps one gesture to one history entry.
 *
 * NOT covered here: the app stores its own scale factors in view TAGS
 * (`sticker_resource_scale_x_tag_key`) and computes the next stretch from them.
 * Those are app state this library cannot see, so the app has to resync them
 * after an undo or its next stretch will jump.
 */
internal data class Transform(
    val x: Float,
    val y: Float,
    val scaleX: Float,
    val scaleY: Float,
    val rotation: Float,
    val width: Int,
    val height: Int,
    val textSizePx: Float?,
) {
    fun applyTo(view: View) {
        view.x = x
        view.y = y
        view.scaleX = scaleX
        view.scaleY = scaleY
        view.rotation = rotation

        var relayout = false
        view.layoutParams?.let { params ->
            if (params.width != width || params.height != height) {
                params.width = width
                params.height = height
                relayout = true
            }
        }
        textSizePx?.let { size ->
            val textView = view.findViewById<TextView?>(R.id.tvPhotoEditorText)
            if (textView != null && textView.textSize != size) {
                textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, size)
                relayout = true
            }
        }
        if (relayout) {
            view.requestLayout()
        }
    }

    companion object {
        fun of(view: View) = Transform(
            x = view.x,
            y = view.y,
            scaleX = view.scaleX,
            scaleY = view.scaleY,
            rotation = view.rotation,
            width = view.layoutParams?.width ?: ViewGroup.LayoutParams.WRAP_CONTENT,
            height = view.layoutParams?.height ?: ViewGroup.LayoutParams.WRAP_CONTENT,
            textSizePx = view.findViewById<TextView?>(R.id.tvPhotoEditorText)?.textSize,
        )
    }
}

/**
 * One completed move, resize or rotate.
 *
 * "Completed" is the whole point. A drag emits a continuous stream of updates,
 * and one history entry per frame would make undo useless -- fifty taps to walk
 * back one gesture. [MultiTouchListener] snapshots on ACTION_DOWN and commits
 * here on ACTION_UP, so the unit of history is the gesture the user actually
 * performed.
 *
 * Gestures that changed nothing are never committed: see [isNoOp]. A tap to
 * select a sticker passes through the same DOWN/UP pair as a drag, and would
 * otherwise push an entry that makes undo appear broken -- the user presses it
 * and the picture does not change.
 */
internal class TransformOperation(
    private val view: View,
    private val before: Transform,
    private val after: Transform,
) : EditorOperation {

    val isNoOp: Boolean get() = before == after

    override fun undo() = before.applyTo(view)

    override fun redo() = after.applyTo(view)
}

/**
 * One brush stroke on a [DrawingView].
 *
 * Delegates rather than snapshotting: the DrawingView already keeps its own
 * ordered path list with working undo/redo, and duplicating that here would
 * give two sources of truth for the same strokes.
 *
 * What changes is that a stroke is now an entry in the SAME ordered history as
 * everything else. Previously `undoView` special-cased DrawingView at the top
 * of the view stack, which is why it kept getting the "is there anything left
 * to undo?" answer wrong -- it had to reason about two stacks at once.
 */
internal class BrushStrokeOperation(
    private val drawingView: DrawingView,
) : EditorOperation {

    override fun undo() {
        drawingView.undo()
    }

    override fun redo() {
        drawingView.redo()
    }
}

/**
 * An [EditorOperation] built from two lambdas.
 *
 * Exists so a consumer does not have to declare a type for every small action.
 * The lambdas are what they capture, so an operation holding a view keeps that
 * view alive for as long as it is reachable from the history stack -- the same
 * bargain the library's own operations make.
 */
internal class LambdaOperation(
    private val undoAction: () -> Unit,
    private val redoAction: () -> Unit,
) : EditorOperation {

    override fun undo() = undoAction()

    override fun redo() = redoAction()
}

/**
 * A graphic was flipped horizontally.
 *
 * Records the target view's rotationY rather than "toggle it back", because a
 * toggle is only its own inverse while nothing else touches the value. Undo and
 * redo have to be exact inverses under any interleaving, and a value snapshot
 * is that unconditionally.
 */
internal class MirrorOperation(
    private val target: View,
    private val before: Float,
    private val after: Float,
) : EditorOperation {

    override fun undo() { target.rotationY = before }

    override fun redo() { target.rotationY = after }
}

/**
 * A graphic was moved to the front of the canvas.
 *
 * Undo puts it back at the child index it held before, which is what layer
 * order actually is. `View.bringToFront()` reorders the parent's children, so
 * nothing about the graphic itself records where it used to sit -- the index has
 * to be captured before the call.
 *
 * Detach and re-attach is how the app's own send-to-back works, so this is the
 * same mechanism rather than a second one.
 */
internal class ReorderOperation(
    private val view: View,
    private val parent: ViewGroup,
    private val fromIndex: Int,
) : EditorOperation {

    override fun undo() {
        if (view.parent === parent) {
            parent.removeView(view)
        }
        parent.addView(view, fromIndex.coerceIn(0, parent.childCount))
    }

    override fun redo() {
        view.bringToFront()
    }
}

/**
 * A text graphic's content or styling changed.
 *
 * Captures the properties [TextStyleBuilder] can write rather than the builder
 * itself: a builder describes an intent to change some subset of the styling,
 * so replaying one does not restore what it did not set. The resulting values
 * do.
 */
internal data class TextState(
    val text: CharSequence?,
    val colour: Int,
    val sizePx: Float,
    val typeface: Typeface?,
    /**
     * Whether the glyph outline is on. Only the switch is recorded, never the
     * outline's colour: that colour is a pure function of [colour], so storing
     * it as well would be a second copy of the same fact -- one that could come
     * back from an undo disagreeing with the text colour beside it.
     */
    val outlineEnabled: Boolean,
) {
    fun applyTo(textView: TextView) {
        textView.text = text
        textView.setTextColor(colour)
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx)
        textView.typeface = typeface
        // Last, because it requests a layout and so does setTextSize above --
        // this way the two coalesce into one pass.
        (textView as? OutlinedTextView)?.isTextOutlineEnabled = outlineEnabled
    }

    companion object {
        fun of(textView: TextView) = TextState(
            text = textView.text?.toString(),
            colour = textView.currentTextColor,
            sizePx = textView.textSize,
            typeface = textView.typeface,
            outlineEnabled = (textView as? OutlinedTextView)?.isTextOutlineEnabled ?: false,
        )
    }
}

internal class EditTextOperation(
    private val textView: TextView,
    private val before: TextState,
    private val after: TextState,
) : EditorOperation {

    val isNoOp: Boolean get() = before == after

    override fun undo() = before.applyTo(textView)

    override fun redo() = after.applyTo(textView)
}
