package com.flocmedia.photoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Rect
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView

/**
 * A [android.widget.TextView] that can draw a contrasting outline around its
 * glyphs, so text stays readable over a busy photo.
 *
 * Disabled by default. With [isTextOutlineEnabled] false this class is
 * byte-for-byte the same as a plain `AppCompatTextView`: [onDraw] hands
 * straight to `super` and [onMeasure] reserves no padding. That default is
 * load-bearing -- the layout this view lives in is shared with emoji items,
 * which must never be outlined.
 *
 * Drawing here is inherited by every raster the editor produces. Export, draft
 * thumbnails and the post-crop snapshot are all `View.draw(canvas)` over the
 * live hierarchy rather than a re-render from the text, so there is no second
 * code path to teach about outlines -- and equally, no second code path that
 * can disagree with this one.
 */
open class OutlinedTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle,
) : AppCompatTextView(context, attrs, defStyleAttr) {

    /**
     * Whether to draw an outline behind the glyphs. The colour is derived from
     * the current text colour at draw time; there is nothing else to configure.
     */
    var isTextOutlineEnabled: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            // The outline needs room reserved for it, so this is a measure
            // change and not just a repaint.
            requestLayout()
            invalidate()
        }

    /**
     * True while [onDraw] is mid-pass.
     *
     * The two passes are driven by swapping the view's text colour and shadow,
     * and both of those setters call `invalidate()`. Left unchecked, that
     * re-dirties the view every time it finishes drawing and it repaints
     * forever. Suppressing self-invalidation for the duration is what makes the
     * swap safe; it costs nothing, because a draw that is already in progress
     * has nothing to gain from being scheduled again.
     */
    private var isDrawingOutline = false

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Before super, so THIS pass measures with the padding it will draw
        // with. The alternative -- inflating the result of
        // setMeasuredDimension afterwards -- does not work: super.onMeasure
        // builds the text Layout against the pre-inflation width, so the text
        // would render flush against one edge of a box that is too wide for it
        // instead of centred in it.
        syncOutlinePadding()
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    /**
     * Reserves exactly enough padding on all four sides for the stroke.
     *
     * A stroke straddles the glyph path, so half of it falls outside the
     * bounds a plain `wrap_content` TextView would claim -- and three separate
     * things would clip it there: the parent's child clip, and the two places
     * the editor rasterises this view into a bitmap sized from its own
     * width/height. Padding is the one fix that covers all three at once,
     * because it grows the measured box itself; disabling the parent clip would
     * only address the first.
     *
     * Called from [onMeasure] rather than from each setter because that catches
     * every writer of `textSize` without having to know them: the style
     * builder, the pinch-resize handler, the post-crop fixup and an undo that
     * restores an older size. In practice it changes the padding rarely -- the
     * inset only moves when the ceiling crosses a pixel -- so the extra layout
     * request it triggers is not a per-frame cost during a pinch.
     */
    private fun syncOutlinePadding() {
        // Same stroke the painter will use, or this reserves room for one
        // outline and draws another. See GAME-786.
        val inset =
            if (isTextOutlineEnabled) TextOutlines.insetPx(textSize, GlyphStem.stemPxFor(paint))
            else 0
        if (inset != paddingLeft || inset != paddingTop ||
            inset != paddingRight || inset != paddingBottom
        ) {
            setPadding(inset, inset, inset, inset)
        }
    }

    /**
     * The colour this view will stroke with, for its current text colour.
     *
     * Resolved on demand and never cached. A cached value would need a
     * recompute hook on `setTextColor` -- and that hook would also fire on the
     * two-pass swap in [onDraw], deriving the outline colour from the outline
     * colour. Resolving it fresh keeps this view's entire mutable state to one
     * boolean.
     *
     * Public because it is otherwise unobservable. The colour only ever reaches
     * a canvas, so nothing outside a real frame can see whether the contrast
     * rule is being applied correctly -- and the consuming app has its own
     * preview widget that must reach the same answer for the same text.
     */
    open fun resolveOutlineColour(): Int =
        TextOutlines.contrastingOutlineColour(currentTextColor)

    override fun onDraw(canvas: Canvas) {
        if (!isTextOutlineEnabled || length() == 0) {
            super.onDraw(canvas)
            return
        }

        // Read BEFORE the swap below: once the stroke colour is installed,
        // deriving from the view would be deriving from the outline colour.
        val outlineColour = resolveOutlineColour()

        isDrawingOutline = true
        try {
            val saved = GlyphOutlinePainter.beginStrokePass(this, outlineColour)
            try {
                super.onDraw(canvas)
                GlyphOutlinePainter.switchToFillPass(this, saved)
                super.onDraw(canvas)
            } finally {
                // Must stay in a finally. `currentTextColor` is read back out
                // of this view to build the undo snapshot and to notify the
                // host app of edits; a pass that threw partway would otherwise
                // leave black or white sitting there, and the next snapshot
                // would record it as the user's chosen colour.
                GlyphOutlinePainter.restore(this, saved)
            }
        } finally {
            isDrawingOutline = false
        }
    }

    override fun invalidate() {
        if (!isDrawingOutline) super.invalidate()
    }

    override fun invalidate(dirty: Rect) {
        if (!isDrawingOutline) super.invalidate(dirty)
    }

    override fun invalidate(l: Int, t: Int, r: Int, b: Int) {
        if (!isDrawingOutline) super.invalidate(l, t, r, b)
    }

    override fun postInvalidate() {
        if (!isDrawingOutline) super.postInvalidate()
    }

    override fun postInvalidate(left: Int, top: Int, right: Int, bottom: Int) {
        if (!isDrawingOutline) super.postInvalidate(left, top, right, bottom)
    }
}
