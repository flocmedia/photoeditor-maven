package com.flocmedia.photoeditor.shape

enum class ArrowPointerLocation { START, END, BOTH }