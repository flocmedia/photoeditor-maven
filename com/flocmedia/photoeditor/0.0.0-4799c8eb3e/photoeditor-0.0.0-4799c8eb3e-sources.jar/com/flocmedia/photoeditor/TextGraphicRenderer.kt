package com.flocmedia.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.widget.TextView

/**
 * GAME-1087 (Slice B1): the export snapshot of a TEXT graphic.
 *
 * The host app builds its export model by rasterising each text graphic and
 * reading a handful of its geometry, and it did that by reaching THROUGH the
 * library's view tree -- `findViewById(R.id.tvPhotoEditorText)` /
 * `R.id.imgHandleTopLeft` (internal ids), then `.draw()` and property reads on
 * the library's own views. That couples the app to the text layout's internals
 * and races the engine's own draw. [render] moves the whole snapshot behind a
 * public boundary: pass the graphic's rootView, get a bitmap plus the numbers
 * the host needs, and never touch a library id.
 *
 * A public DTO, not the internal [Text]/[Graphic] type -- the host stays in terms
 * of `View` + this data class.
 */
data class RenderedTextGraphic(
    /** The text view rendered 1:1 (ARGB_8888). */
    val bitmap: Bitmap,
    /** imgHandleTopLeft.width -- the host offsets the graphic origin by this. */
    val handleSizePx: Int,
    val flippedHorizontally: Boolean,
    val flippedVertically: Boolean,
    val alpha: Float,
    val textSizePx: Float,
    /**
     * The multiple of on-screen size this bitmap was rasterised at (1f = 1:1).
     * The host divides the ratio it would otherwise upscale by, so a scaled bitmap
     * is composited at its natural size rather than blown up a second time.
     */
    val renderedScale: Float = 1f,
)

object TextGraphicRenderer {

    /**
     * Renders a text graphic's [graphicRootView] to a [RenderedTextGraphic], or
     * null when it is not a text graphic (no inner text view / handle) or has not
     * been laid out yet (zero size).
     *
     * [scale] rasterises the text at that multiple of its on-screen size, SHARPLY.
     * This is not an upscale of the 1:1 snapshot -- the text view is drawn under a
     * scaled canvas, so `TextView.onDraw` -> `Layout.draw` -> `Canvas.drawText`
     * rasterises the glyphs from the font at the scaled matrix, and the outline's
     * two-pass `onDraw` and the shadow and the nine-patch bubble background all
     * draw at the scaled size too. At `scale = 1f` (the default) it is byte-for-byte
     * the 1:1 snapshot the host used to build by hand.
     *
     * WHY THIS EXISTS. The host exports a ~1080px screenshot of the editor and then
     * upscales each text layer over the full-size photo (thug-life GAME-1279): a
     * 200px text raster stretched to 740px on a 12MP source is the blurriest thing
     * in the export. Rendering the view at the source/canvas ratio here produces the
     * text at the resolution the photo is exported at, from the same styled view --
     * no text model to serialize, no styling to replicate headlessly, because the
     * fully-styled view already exists in-process at capture time.
     *
     * The returned [RenderedTextGraphic.renderedScale] tells the host what multiple
     * it got, so the compositor can draw the bitmap at its natural size instead of
     * re-applying the ratio (which would upscale it a second time).
     */
    @JvmOverloads
    fun render(graphicRootView: View, scale: Float = 1f): RenderedTextGraphic? {
        val textView = graphicRootView.findViewById<TextView>(R.id.tvPhotoEditorText) ?: return null
        val handle = graphicRootView.findViewById<View>(R.id.imgHandleTopLeft) ?: return null
        if (textView.width <= 0 || textView.height <= 0) return null

        // A non-positive or unset scale means "1:1", never a zero-area bitmap.
        val s = if (scale > 0f) scale else 1f
        val w = Math.max(1, Math.round(textView.width * s))
        val h = Math.max(1, Math.round(textView.height * s))

        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        // Draw the SAME styled view under a scaled matrix. Not a post-hoc bitmap
        // stretch -- the glyphs re-rasterise from the font at the scaled size.
        canvas.scale(s, s)
        textView.draw(canvas)

        return RenderedTextGraphic(
            bitmap = bitmap,
            handleSizePx = handle.width,
            flippedHorizontally = textView.rotationY == 180f,
            flippedVertically = textView.rotationX == 180f,
            alpha = textView.alpha,
            textSizePx = textView.textSize,
            renderedScale = s,
        )
    }
}
