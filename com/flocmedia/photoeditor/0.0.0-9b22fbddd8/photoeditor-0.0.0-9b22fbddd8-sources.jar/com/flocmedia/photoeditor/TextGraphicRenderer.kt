package com.flocmedia.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.widget.TextView

/**
 * GAME-1087 (Slice B1): the export snapshot of a TEXT graphic.
 *
 * The host app builds its export model by rasterising each text graphic and
 * reading a handful of its geometry, and it did that by reaching THROUGH the
 * library's view tree -- `findViewById(R.id.tvPhotoEditorText)` /
 * `R.id.imgHandleTopLeft` (internal ids), then `.draw()` and property reads on
 * the library's own views. That couples the app to the text layout's internals
 * and races the engine's own draw. [render] moves the whole snapshot behind a
 * public boundary: pass the graphic's rootView, get a bitmap plus the numbers
 * the host needs, and never touch a library id.
 *
 * A public DTO, not the internal [Text]/[Graphic] type -- the host stays in terms
 * of `View` + this data class.
 */
data class RenderedTextGraphic(
    /** The text view rendered 1:1 (ARGB_8888). */
    val bitmap: Bitmap,
    /** imgHandleTopLeft.width -- the host offsets the graphic origin by this. */
    val handleSizePx: Int,
    val flippedHorizontally: Boolean,
    val flippedVertically: Boolean,
    val alpha: Float,
    val textSizePx: Float,
)

object TextGraphicRenderer {

    /**
     * Renders a text graphic's [graphicRootView] to a [RenderedTextGraphic], or
     * null when it is not a text graphic (no inner text view / handle) or has not
     * been laid out yet (zero size). Byte-for-byte the snapshot the host used to
     * build by hand.
     */
    fun render(graphicRootView: View): RenderedTextGraphic? {
        val textView = graphicRootView.findViewById<TextView>(R.id.tvPhotoEditorText) ?: return null
        val handle = graphicRootView.findViewById<View>(R.id.imgHandleTopLeft) ?: return null
        if (textView.width <= 0 || textView.height <= 0) return null

        val bitmap = Bitmap.createBitmap(textView.width, textView.height, Bitmap.Config.ARGB_8888)
        textView.draw(Canvas(bitmap))

        return RenderedTextGraphic(
            bitmap = bitmap,
            handleSizePx = handle.width,
            flippedHorizontally = textView.rotationY == 180f,
            flippedVertically = textView.rotationX == 180f,
            alpha = textView.alpha,
            textSizePx = textView.textSize,
        )
    }
}
