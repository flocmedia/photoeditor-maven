package com.flocmedia.photoeditor

/**
 * Where a graphic's top-left has to go so that its CENTRE stays put when its
 * size changes.
 *
 * ## Why this is needed at all
 *
 * A graphic on the canvas is positioned by `view.x` / `view.y` -- its top-left.
 * Its size is `wrap_content` over content that can change underneath it: a
 * longer string, a different font, or the padding an outline reserves for its
 * stroke. Every one of those grows the box symmetrically, and with the
 * top-left pinned, symmetric growth moves the visible centre. The user placed
 * the object by where it LOOKS, so that is what has to hold still.
 *
 * ## Why it is a pure function
 *
 * The arithmetic existed in three places with two different behaviours --
 * `onGraphicMove` unclamped, `adjustEditorStateAfterCrop` clamped,
 * `ensureStickersOnCanvas` clamping without recentring -- all inside
 * `EditImageActivity`, which does not start under Robolectric. Pulled out, the
 * off-by-one that a `/ 2` invites is reachable from a JVM test.
 */
object GraphicRecentre {

    /**
     * The (x, y) that puts a [width] x [height] graphic's centre at
     * ([centreX], [centreY]), clamped so it cannot be pushed out of reach.
     *
     * The clamp allows a graphic to hang half-way off any edge and no further,
     * which is the same bound `ensureStickersOnCanvas` applies -- so at least
     * half of it stays on canvas and it can always be grabbed again. Growing a
     * text from one word to a sentence right at the edge is exactly the case
     * that would otherwise put it somewhere the user cannot reach.
     *
     * A canvas of zero width or height (measured before layout) would make the
     * clamp's lower bound exceed its upper and throw from `coerceIn`. That is a
     * real ordering hazard rather than a hypothetical -- callers here run
     * inside layout listeners -- so it degrades to the unclamped position.
     */
    fun position(
        centreX: Float,
        centreY: Float,
        width: Int,
        height: Int,
        canvasWidth: Int,
        canvasHeight: Int,
    ): Pair<Float, Float> {
        val (x, y) = unclampedPosition(centreX, centreY, width, height)

        if (canvasWidth <= 0 || canvasHeight <= 0) return x to y

        return x.coerceIn(-width / 2f, canvasWidth - width / 2f) to
            y.coerceIn(-height / 2f, canvasHeight - height / 2f)
    }

    /**
     * [position] without the clamp: the (x, y) that puts a [width] x [height]
     * graphic's centre exactly at ([centreX], [centreY]), wherever that is.
     *
     * Split out rather than expressed as `position(..., canvasWidth = 0)`,
     * which happens to work today by hitting the zero-guard above and would
     * stop working the day someone "fixes" that guard. Two named policies over
     * one arithmetic definition, so the two can never disagree about where a
     * centre is.
     *
     * The resize path wants this one. `GraphicRecentre`'s own history records
     * that `onGraphicMove` is unclamped, and adding a clamp there would change
     * where a half-off-canvas graphic sits -- a second behaviour change riding
     * in on a bug fix.
     */
    fun unclampedPosition(
        centreX: Float,
        centreY: Float,
        width: Int,
        height: Int,
    ): Pair<Float, Float> {
        // Float division deliberately. The existing call sites compute
        // `view.x + view.width / 2` in INT arithmetic, which truncates by up to
        // a pixel before the result is ever used as a Float -- so a graphic of
        // odd width drifts by 1px every time it is recentred. Half a pixel is
        // not worth reproducing for compatibility's sake.
        return (centreX - width / 2f) to (centreY - height / 2f)
    }
}
