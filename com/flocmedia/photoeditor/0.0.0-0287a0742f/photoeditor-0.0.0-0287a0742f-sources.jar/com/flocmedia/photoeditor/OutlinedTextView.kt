package com.flocmedia.photoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Rect
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import kotlin.math.ceil

/**
 * A [android.widget.TextView] that can draw a contrasting outline around its
 * glyphs, so text stays readable over a busy photo.
 *
 * Disabled by default. With [isTextOutlineEnabled] false this class is
 * byte-for-byte the same as a plain `AppCompatTextView`: [onDraw] hands
 * straight to `super` and [onMeasure] reserves no padding. That default is
 * load-bearing -- the layout this view lives in is shared with emoji items,
 * which must never be outlined.
 *
 * Drawing here is inherited by every raster the editor produces. Export, draft
 * thumbnails and the post-crop snapshot are all `View.draw(canvas)` over the
 * live hierarchy rather than a re-render from the text, so there is no second
 * code path to teach about outlines -- and equally, no second code path that
 * can disagree with this one.
 */
open class OutlinedTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle,
) : AppCompatTextView(context, attrs, defStyleAttr) {

    /**
     * Whether to draw an outline behind the glyphs. The colour is derived from
     * the current text colour at draw time; there is nothing else to configure.
     */
    var isTextOutlineEnabled: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            // The outline needs room reserved for it, so this is a measure
            // change and not just a repaint.
            requestLayout()
            invalidate()
        }

    /**
     * True while [onDraw] is mid-pass.
     *
     * The two passes are driven by swapping the view's text colour and shadow,
     * and both of those setters call `invalidate()`. Left unchecked, that
     * re-dirties the view every time it finishes drawing and it repaints
     * forever. Suppressing self-invalidation for the duration is what makes the
     * swap safe; it costs nothing, because a draw that is already in progress
     * has nothing to gain from being scheduled again.
     */
    /**
     * The thread currently inside [onDraw]'s two-pass block, or null.
     *
     * A THREAD REFERENCE, not a shared Boolean and not a ThreadLocal:
     *  - A shared Boolean makes the invalidate-suppression below apply to
     *    EVERY thread, so a background draw swallows the main thread's
     *    requestLayout/invalidate, [syncOutlinePadding] never runs, and the
     *    stroke -- which paints outside the glyph box -- is clipped away.
     *  - A ThreadLocal field NPEs during construction: AppCompatTextView's
     *    constructor calls invalidate() before this class's initialisers run.
     *    It surfaces as "Error inflating class <unknown>".
     * Null reads as "not drawing", exactly like the old boolean.
     */
    @Volatile
    private var outlineDrawingThread: Thread? = null

    private var isDrawingOutline: Boolean
        get() = outlineDrawingThread === Thread.currentThread()
        set(value) {
            outlineDrawingThread = if (value) Thread.currentThread() else null
        }

    /** Set only for the duration of [onDraw]; see [fillColour]. */
    private var fillColourDuringDraw: Int? = null

    /**
     * The text's FILL colour, correct even while [onDraw] is mid-pass.
     *
     * `currentTextColor` cannot be trusted here and cannot be fixed in place:
     * the stroke pass installs the outline colour through setTextColor because
     * that is the only public door into the paint, and getCurrentTextColor is
     * final. Anything reading this view's colour must read THIS.
     */
    val fillColour: Int
        get() = fillColourDuringDraw ?: currentTextColor

    /**
     * Serialises the two-pass draw.
     *
     * The passes swap state that lives on the VIEW, so two draws at once are
     * not independent: the second saves what the first installed, treats
     * STROKE as the fill to return to, and restores that permanently.
     * EditorTransparentCache draws these views on Dispatchers.IO every time
     * the text dialog opens, so a real session races this on every edit.
     */
    private val outlineDrawLock = Any()

    /** Scratch for reading the background drawable's padding in [onMeasure]. */
    private val tempPaddingRect = Rect()

    /** Scratch for measuring a line's glyph ink bounds in [horizontalInkOverhang]. */
    private val tempInkBounds = Rect()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Before super, so THIS pass measures with the padding it will draw
        // with. The alternative -- inflating the result of
        // setMeasuredDimension afterwards -- does not work: super.onMeasure
        // builds the text Layout against the pre-inflation width, so the text
        // would render flush against one edge of a box that is too wide for it
        // instead of centred in it.
        syncOutlinePadding()
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    /**
     * Reserves exactly enough padding on all four sides for the stroke.
     *
     * A stroke straddles the glyph path, so half of it falls outside the
     * bounds a plain `wrap_content` TextView would claim -- and three separate
     * things would clip it there: the parent's child clip, and the two places
     * the editor rasterises this view into a bitmap sized from its own
     * width/height. Padding is the one fix that covers all three at once,
     * because it grows the measured box itself; disabling the parent clip would
     * only address the first.
     *
     * Called from [onMeasure] rather than from each setter because that catches
     * every writer of `textSize` without having to know them: the style
     * builder, the pinch-resize handler, the post-crop fixup and an undo that
     * restores an older size. In practice it changes the padding rarely -- the
     * inset only moves when the ceiling crosses a pixel -- so the extra layout
     * request it triggers is not a per-frame cost during a pinch.
     */
    private fun syncOutlinePadding() {
        // Same stroke the painter will use, or this reserves room for one
        // outline and draws another. See GAME-786.
        val inset = if (isTextOutlineEnabled) TextOutlines.insetPx(paint) else 0
        // ADD the outline inset to the BACKGROUND drawable's own padding, never
        // replace it (GAME-826). A speech-bubble background is a nine-patch whose
        // content-padding markers reserve the room the tail and rounded body need
        // around the glyphs; a bare setPadding(inset...) here would clobber that
        // to zero and the text would spill onto the tail. When there is no
        // background, bgPad is 0 and this is exactly the old behaviour.
        val bg = tempPaddingRect
        val hasBgPadding = background?.getPadding(bg) == true
        // Glyph INK can spill past the advance-width box the text is measured
        // into -- a slanted/decorative face's first and last glyphs overhang
        // sideways -- and the view is only as wide as those advances, so the
        // overhanging ink (and its stroke) is clipped at the side edges. The
        // stroke inset alone does not cover it. Reserve the measured overhang on
        // top of the inset, horizontally only (ascent/descent already give the
        // vertical room). See GAME-826 follow-up.
        val (inkLeft, inkRight) = horizontalInkOverhang()
        val l = (if (hasBgPadding) bg.left else 0) + inset + inkLeft
        val t = (if (hasBgPadding) bg.top else 0) + inset
        val r = (if (hasBgPadding) bg.right else 0) + inset + inkRight
        val b = (if (hasBgPadding) bg.bottom else 0) + inset
        if (l != paddingLeft || t != paddingTop || r != paddingRight || b != paddingBottom) {
            setPadding(l, t, r, b)
        }
    }

    /**
     * How far the glyph ink of the current text spills past its advance-width
     * box on the left and right, in pixels (never negative).
     *
     * TextView sizes its content box from advance widths, but a glyph's ink can
     * start left of the pen (negative left side bearing) or end right of the
     * advance (right overhang) -- pronounced on slanted display faces. Measured
     * per line with the FILL paint (the stroke is covered separately by the
     * inset); the widest overhang on either side wins.
     */
    private fun horizontalInkOverhang(): Pair<Int, Int> {
        val content = text?.toString()
        if (content.isNullOrEmpty()) return 0 to 0
        var left = 0
        var right = 0
        for (line in content.split('\n')) {
            if (line.isEmpty()) continue
            paint.getTextBounds(line, 0, line.length, tempInkBounds)
            val (l, r) = overhangPx(tempInkBounds.left, tempInkBounds.right, paint.measureText(line))
            left = maxOf(left, l)
            right = maxOf(right, r)
        }
        return left to right
    }

    companion object {
        /**
         * The horizontal ink overhang of one line, from its ink bounds and its
         * advance width (all in pixels): how far the ink reaches left of the pen
         * origin ([inkLeft] < 0) and right of the advance box ([inkRight] >
         * [advanceWidth]). Never negative; rounded up so a fractional pixel of
         * ink is not shaved off. Pure arithmetic, split out so it is testable
         * without rasterising a font (Robolectric's getTextBounds cannot).
         */
        internal fun overhangPx(inkLeft: Int, inkRight: Int, advanceWidth: Float): Pair<Int, Int> {
            val left = ceil(maxOf(0f, -inkLeft.toFloat())).toInt()
            val right = ceil(maxOf(0f, inkRight - advanceWidth)).toInt()
            return left to right
        }
    }

    /**
     * The colour this view will stroke with, for its current text colour.
     *
     * Resolved on demand and never cached. A cached value would need a
     * recompute hook on `setTextColor` -- and that hook would also fire on the
     * two-pass swap in [onDraw], deriving the outline colour from the outline
     * colour. Resolving it fresh keeps this view's entire mutable state to one
     * boolean.
     *
     * Public because it is otherwise unobservable. The colour only ever reaches
     * a canvas, so nothing outside a real frame can see whether the contrast
     * rule is being applied correctly -- and the consuming app has its own
     * preview widget that must reach the same answer for the same text.
     */
    open fun resolveOutlineColour(): Int =
        // fillColour, NOT currentTextColor. Deriving from the property the
        // stroke pass mutates is what made the outline INVISIBLE: a concurrent
        // draw leaves it black, contrast then returns a WHITE outline, and a
        // white stroke under white text shows nothing -- the "fully white, no
        // outline" symptom of GAME-873.
        TextOutlines.contrastingOutlineColour(fillColour)

    override fun onDraw(canvas: Canvas) {
        if (!isTextOutlineEnabled || length() == 0) {
            super.onDraw(canvas)
            return
        }

        synchronized(outlineDrawLock) {
        isDrawingOutline = true
        // Capture the fill FIRST: resolveOutlineColour reads it, and so does
        // anything on another thread asking this view its colour mid-draw.
        fillColourDuringDraw = currentTextColor
        // INSIDE the lock. Resolving outside it reads a colour another thread
        // may be part-way through swapping -- the lock is worthless if the
        // value it protects is sampled before it is taken.
        val outlineColour = resolveOutlineColour()
        try {
            val saved = GlyphOutlinePainter.beginStrokePass(this, outlineColour)
            try {
                super.onDraw(canvas)
                GlyphOutlinePainter.switchToFillPass(this, saved)
                super.onDraw(canvas)
            } finally {
                // Must stay in a finally. `currentTextColor` is read back out
                // of this view to build the undo snapshot and to notify the
                // host app of edits; a pass that threw partway would otherwise
                // leave black or white sitting there, and the next snapshot
                // would record it as the user's chosen colour.
                GlyphOutlinePainter.restore(this, saved)
            }
        } finally {
            isDrawingOutline = false
            fillColourDuringDraw = null
        }
        }
    }

    override fun invalidate() {
        if (!isDrawingOutline) super.invalidate()
    }

    override fun invalidate(dirty: Rect) {
        if (!isDrawingOutline) super.invalidate(dirty)
    }

    override fun invalidate(l: Int, t: Int, r: Int, b: Int) {
        if (!isDrawingOutline) super.invalidate(l, t, r, b)
    }

    override fun postInvalidate() {
        if (!isDrawingOutline) super.postInvalidate()
    }

    override fun postInvalidate(left: Int, top: Int, right: Int, bottom: Int) {
        if (!isDrawingOutline) super.postInvalidate(left, top, right, bottom)
    }
}
