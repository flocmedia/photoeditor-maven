package com.flocmedia.photoeditor

import kotlin.math.abs

/**
 * Pure geometry for GAME-702 snapping/alignment guides: given where a dragged
 * graphic WOULD land, nudge it so a salient feature (an edge or its centre)
 * lines up with the canvas centre/edges or another graphic's edge/centre, and
 * report which guide line to draw.
 *
 * Deliberately free of any Android type -- boxes are plain floats -- so the whole
 * thing is unit-testable on the JVM without a view, a Paint, or Robolectric. The
 * [MultiTouchListener] builds the boxes from live views and applies the result.
 */
object AlignmentSnapper {

    /** An axis-aligned box in canvas pixels. */
    data class Box(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val centerX get() = (left + right) / 2f
        val centerY get() = (top + bottom) / 2f
    }

    /**
     * The correction to add to the dragged graphic's proposed position, plus the
     * canvas-space coordinate of each active guide line (null = no snap on that
     * axis, so no line to draw).
     */
    data class SnapResult(
        val dx: Float,
        val dy: Float,
        val verticalGuideX: Float?,
        val horizontalGuideY: Float?,
    ) {
        val snapped get() = verticalGuideX != null || horizontalGuideY != null
    }

    val NONE = SnapResult(0f, 0f, null, null)

    /**
     * @param dragged   where the graphic would land with no snapping.
     * @param canvasW/H the canvas (photo) bounds the graphic aligns to.
     * @param others    every OTHER graphic's box (already filtered to live ones).
     * @param threshold how close, in px, a feature must be to snap (exclusive).
     */
    fun snap(
        dragged: Box,
        canvasW: Float,
        canvasH: Float,
        others: List<Box>,
        threshold: Float,
    ): SnapResult {
        // Candidate lines per axis: canvas near edge, centre, far edge, plus each
        // other graphic's near edge / centre / far edge.
        val xLines = ArrayList<Float>(3 + others.size * 3).apply {
            add(0f); add(canvasW / 2f); add(canvasW)
            for (o in others) { add(o.left); add(o.centerX); add(o.right) }
        }
        val yLines = ArrayList<Float>(3 + others.size * 3).apply {
            add(0f); add(canvasH / 2f); add(canvasH)
            for (o in others) { add(o.top); add(o.centerY); add(o.bottom) }
        }
        val (dx, vGuide) = snapAxis(listOf(dragged.left, dragged.centerX, dragged.right), xLines, threshold)
        val (dy, hGuide) = snapAxis(listOf(dragged.top, dragged.centerY, dragged.bottom), yLines, threshold)
        return SnapResult(dx, dy, vGuide, hGuide)
    }

    /**
     * The closest (feature, line) pair within [threshold] on one axis, as the
     * shift that lands the feature on the line and the line itself (the guide).
     * Ties resolve to the first-seen line, which orders canvas guides before
     * graphic guides -- the canvas centre wins over a coincident graphic edge.
     */
    private fun snapAxis(
        features: List<Float>,
        lines: List<Float>,
        threshold: Float,
    ): Pair<Float, Float?> {
        var bestGap = threshold
        var bestShift = 0f
        var bestGuide: Float? = null
        for (line in lines) {
            for (f in features) {
                val gap = abs(line - f)
                if (gap < bestGap) {
                    bestGap = gap
                    bestShift = line - f
                    bestGuide = line
                }
            }
        }
        return bestShift to bestGuide
    }
}
