package com.flocmedia.photoeditor

import android.graphics.ColorMatrixColorFilter
import android.view.View

/**
 * GAME-692: per-graphic brightness/contrast/saturation, stored as a
 * [ColorMatrixColorFilter] tag on a graphic's CONTENT view and applied by
 * [BlendableFrameLayout.drawChild].
 *
 * This exists in the library specifically for TEXT: a TextView does not render a
 * ColorMatrixColorFilter on its own in the `View.draw` export, so the adjustment
 * has to be applied in drawChild (which reaches both the live screen and the
 * View.draw export, exactly like blend). Stickers apply their adjustment
 * app-side via `ImageView.setColorFilter`, so the app does not need this for
 * them -- but [of]/[set] work for either content view.
 *
 * Unlike blend, a ColorMatrixColorFilter has no API floor (ColorMatrix is API 1),
 * so drawChild applies the adjustment on every API level.
 */
object GraphicAdjust {

    private fun contentOf(rootView: View?): View? = rootView?.let {
        it.findViewById(R.id.imgPhotoEditorImage) ?: it.findViewById(R.id.tvPhotoEditorText)
    }

    /** Set (or clear, with null) the adjustment filter on a placed graphic. */
    fun set(rootView: View, colorFilter: ColorMatrixColorFilter?) {
        val content = contentOf(rootView) ?: return
        content.setTag(R.id.adjust_filter_tag, colorFilter)
        // The filter is applied in the content's PARENT (a BlendableFrameLayout)
        // on layer restore; a tag change invalidates nothing, so tell it to redraw.
        (content.parent as? View)?.invalidate()
        content.invalidate()
    }

    /** The graphic's adjustment filter, or null if none was set. */
    fun of(rootView: View?): ColorMatrixColorFilter? =
        contentOf(rootView)?.getTag(R.id.adjust_filter_tag) as? ColorMatrixColorFilter
}
