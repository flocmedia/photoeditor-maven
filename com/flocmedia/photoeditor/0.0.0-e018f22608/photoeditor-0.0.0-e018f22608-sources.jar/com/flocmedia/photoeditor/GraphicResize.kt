package com.flocmedia.photoeditor

import android.view.View
import android.view.View.MeasureSpec
import android.widget.TextView
import android.util.TypedValue

/**
 * Resizing a graphic about its own centre, in one step rather than two.
 *
 * ## The invariant these functions exist to hold
 *
 * **`view.x`/`view.y` and `view.layoutParams.width`/`height` must be a
 * consistent pair at every instant.**
 *
 * That reads like tidiness and is not. `Transform.of` in the photoeditor
 * library snapshots both together for the undo stack, and it is called from
 * `endExternalGesture` on ACTION_UP -- synchronously, in the same input
 * dispatch that just wrote the new size. If position and size are only
 * consistent after the next layout pass, then every snapshot taken between a
 * resize and that pass records the NEW size beside the OLD position, and undo
 * or redo faithfully replays that impossible pair.
 *
 * That was GAME-764: redo of a corner resize restored the right size in the
 * wrong place, offset equally in x and y, on roughly one CI run in three.
 * Intermittent because whether a layout traversal lands between the last
 * ACTION_MOVE and the ACTION_UP is a scheduling question, and a loaded emulator
 * batches input differently from an idle one.
 *
 * ## Why the size is read from layoutParams, not from the view
 *
 * This is the part that is easy to get wrong, and getting it wrong is worse
 * than the bug being fixed.
 *
 * A drag delivers many ACTION_MOVE frames with no layout pass in between. Read
 * the centre from the MEASURED size and it is stale from the second frame
 * onward, so the centre drifts by `(w_prev - w_new) / 2` every frame and the
 * graphic crawls across the canvas while the user drags. The intended size --
 * `layoutParams` -- is written by the previous frame, so it is always current.
 *
 *   measured: frame2 centre = x1 + w0/2 = C - w1/2 + w0/2  != C     drifts
 *   intended: frame2 centre = x1 + w1/2 = C                         exact
 *
 * The deferred listener this replaced did not drift, but only by accident: all
 * the pending listeners computed the same stale value and the last one won.
 *
 * `view.width == layoutParams.width` after layout is exact rather than
 * approximate here: the canvas is a `FrameLayout`, and `getChildMeasureSpec`
 * returns `EXACTLY(childDimension)` for a fixed `lp.width`. So the synchronous
 * value is the number the layout pass would have produced, not an estimate.
 */
object GraphicResize {

    /**
     * Resize [view] to [width] x [height], keeping its centre where it is.
     *
     * Writes position and size together and returns with both already correct,
     * so a snapshot taken immediately afterwards is coherent.
     */
    fun resizeGraphicAboutItsCentre(view: View, width: Int, height: Int) {
        val params = view.layoutParams ?: return

        // The INTENDED size, falling back to the measured one only when
        // layoutParams carries a wrap_content/match_parent sentinel (negative)
        // rather than a pixel value -- i.e. the first resize of a graphic that
        // has never been given an explicit size.
        val currentWidth = params.width.takeIf { it > 0 } ?: view.width
        val currentHeight = params.height.takeIf { it > 0 } ?: view.height

        val (x, y) = GraphicRecentre.unclampedPosition(
            centreX = view.x + currentWidth / 2f,
            centreY = view.y + currentHeight / 2f,
            width = width,
            height = height,
        )

        params.width = width
        params.height = height
        view.x = x
        view.y = y
        view.requestLayout()
    }

    /**
     * Set [textView]'s size to [textSizePx] and keep [view]'s centre where it
     * is, [view] being the graphic root that wraps it.
     *
     * Text needs its own function because it has no target size to be told:
     * these roots are `wrap_content`, so `layoutParams.width` is a sentinel and
     * the new size is whatever the string measures to at the new text size.
     * Hence an eager `measure` rather than arithmetic.
     *
     * The specs are the ones a `FrameLayout` parent would hand this child
     * anyway, so the real layout pass recomputes the same numbers and does not
     * fight what is written here.
     */
    fun resizeTextAboutItsCentre(
        view: View,
        textView: TextView,
        textSizePx: Float,
        canvasWidth: Int,
        canvasHeight: Int,
    ) {
        val centreX = view.x + view.width / 2f
        val centreY = view.y + view.height / 2f

        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSizePx)

        // AT_MOST, not UNSPECIFIED: an unbounded spec lets a long string
        // measure to a single line wider than the canvas, which is not what it
        // will actually get and would centre it from the wrong width.
        //
        // A zero-sized canvas means this is running before the editor has been
        // laid out. Measuring against zero would collapse the graphic, so fall
        // back to UNSPECIFIED and accept the single-line width -- still better
        // than zero, and the following layout pass corrects it.
        val widthSpec = if (canvasWidth > 0) {
            MeasureSpec.makeMeasureSpec(canvasWidth, MeasureSpec.AT_MOST)
        } else {
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        }
        val heightSpec = if (canvasHeight > 0) {
            MeasureSpec.makeMeasureSpec(canvasHeight, MeasureSpec.AT_MOST)
        } else {
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        }
        view.measure(widthSpec, heightSpec)

        val (x, y) = GraphicRecentre.unclampedPosition(
            centreX = centreX,
            centreY = centreY,
            width = view.measuredWidth,
            height = view.measuredHeight,
        )

        view.x = x
        view.y = y
        view.requestLayout()
    }
}
